/*
 * CivicPulse algorithm engine (C, compiled to WebAssembly).
 *
 * Modules:
 *   - cp_distance_m        : location distance (equirectangular approximation, accurate at city scale)
 *   - cp_severity          : severity level 1..5 from category risk, hazard flags and support count
 *   - cp_priority          : priority score 0..100 (safety, vulnerable groups, population, location, age)
 *   - cp_find_duplicates   : location + category based duplicate candidates
 *   - cp_hamming64         : perceptual-hash distance between two images (64-bit dHash split in 2x32)
 *
 * Build (WebAssembly, no libc):
 *   clang --target=wasm32 -O2 -nostdlib -Wl,--no-entry -Wl,--export-dynamic -o civic_engine.wasm civic_engine.c
 * Build (native shared library for Python ctypes):
 *   gcc -O2 -shared -fPIC -o libcivic_engine.so civic_engine.c
 */

#define EXPORT __attribute__((visibility("default")))
#define PI 3.14159265358979323846
#define EARTH_R 6371000.0

static double cp_sqrt(double x) { return __builtin_sqrt(x); }

/* cos(x) by Taylor series after range reduction; enough precision for latitudes. */
static double cp_cos(double x) {
    while (x > PI) x -= 2 * PI;
    while (x < -PI) x += 2 * PI;
    double x2 = x * x, term = 1.0, sum = 1.0;
    for (int i = 1; i < 12; i++) {
        term *= -x2 / ((2 * i - 1) * (2 * i));
        sum += term;
    }
    return sum;
}

EXPORT double cp_distance_m(double lat1, double lon1, double lat2, double lon2) {
    double p1 = lat1 * PI / 180.0, p2 = lat2 * PI / 180.0;
    double dx = (lon2 - lon1) * PI / 180.0 * cp_cos((p1 + p2) / 2.0);
    double dy = p2 - p1;
    return EARTH_R * cp_sqrt(dx * dx + dy * dy);
}

/* hazard flags bitmask */
#define HZ_ELECTRICAL 1
#define HZ_OPEN_PIT   2
#define HZ_FLOODING   4
#define HZ_TRAFFIC    8
#define HZ_HEALTH     16

static int popcount(unsigned int v) { int c = 0; while (v) { c += v & 1u; v >>= 1; } return c; }

/* category_risk 1..5 (from category table), user_severity 1..5 (citizen estimate, 0 = none) */
EXPORT int cp_severity(int category_risk, int hazard_flags, int supports, int user_severity) {
    double s = category_risk;
    if (hazard_flags & HZ_ELECTRICAL) s += 1.5;
    if (hazard_flags & HZ_OPEN_PIT) s += 1.0;
    if (hazard_flags & HZ_FLOODING) s += 0.8;
    s += 0.3 * popcount((unsigned)(hazard_flags & (HZ_TRAFFIC | HZ_HEALTH)));
    if (supports >= 10) s += 1.0; else if (supports >= 3) s += 0.5;
    if (user_severity > 0) s = 0.7 * s + 0.3 * user_severity;
    int r = (int)(s + 0.5);
    if (r < 1) r = 1;
    if (r > 5) r = 5;
    return r;
}

/* vulnerable flags: 1 seniors, 2 children/school, 4 disabled, 8 pedestrians, 16 emergency access */
/* population band 0..3 (street, block, neighbourhood, arterial); location sensitivity 0..3
   (none, market/transit, school/hospital, emergency route) */
EXPORT double cp_priority(int severity, int vulnerable_flags, int population_band,
                          int location_sensitivity, double age_days, int supports, int reopen_count) {
    double score = 0;
    score += severity * 9.0;                                   /* up to 45: safety risk   */
    score += popcount((unsigned)vulnerable_flags) * 4.0;       /* up to 20: vulnerable    */
    if (vulnerable_flags & 16) score += 3.0;                   /* emergency access bonus  */
    score += population_band * 3.0;                            /* up to 9                 */
    score += location_sensitivity * 3.0;                       /* up to 9                 */
    double age = age_days > 30 ? 30 : (age_days < 0 ? 0 : age_days);
    score += age * 0.2;                                        /* up to 6: waiting time   */
    double sup = supports > 20 ? 20 : supports;
    score += sup * 0.25;                                       /* up to 5                 */
    score += (reopen_count > 3 ? 3 : reopen_count) * 2.0;      /* up to 6: failed repairs */
    if (score > 100) score = 100;
    return score;
}

/* Shared buffers so JavaScript can pass arrays without an allocator. */
#define MAXN 4096
EXPORT double cp_lat[MAXN];
EXPORT double cp_lon[MAXN];
EXPORT int cp_cat[MAXN];
EXPORT int cp_out[MAXN];
EXPORT double cp_dist[MAXN];

EXPORT double *cp_lat_ptr(void) { return cp_lat; }
EXPORT double *cp_lon_ptr(void) { return cp_lon; }
EXPORT int *cp_cat_ptr(void) { return cp_cat; }
EXPORT int *cp_out_ptr(void) { return cp_out; }
EXPORT double *cp_dist_ptr(void) { return cp_dist; }

/* Returns how many of the first n stored points are within radius_m and share category (cat<0 = any). */
EXPORT int cp_find_duplicates(int n, double lat, double lon, int cat, double radius_m) {
    int k = 0;
    if (n > MAXN) n = MAXN;
    for (int i = 0; i < n; i++) {
        if (cat >= 0 && cp_cat[i] != cat) continue;
        double d = cp_distance_m(lat, lon, cp_lat[i], cp_lon[i]);
        if (d <= radius_m) { cp_out[k] = i; cp_dist[k] = d; k++; }
    }
    return k;
}

EXPORT int cp_hamming64(unsigned int a_hi, unsigned int a_lo, unsigned int b_hi, unsigned int b_lo) {
    return popcount(a_hi ^ b_hi) + popcount(a_lo ^ b_lo);
}

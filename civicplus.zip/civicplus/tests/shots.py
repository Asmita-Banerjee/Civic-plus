import asyncio
from playwright.async_api import async_playwright
import os
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))+'/'; OUT=ROOT+'docs/screenshots/'
import os, json; os.makedirs(OUT,exist_ok=True)
_seed={o['path']:o['data'] for o in json.load(open(ROOT+'data/seed.json'))}
open(ROOT+'tests/mock_seed.js','w').write(open(ROOT+'tests/mock.js').read().replace('window.__store=store;','window.__store=store;const SEED='+json.dumps(_seed)+';for(const k in SEED) store.set(k,SEED[k]);'))
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path=os.environ.get('CHROME') or None,args=['--no-sandbox'])
    pg=await b.new_page(viewport={'width':1600,'height':790},device_scale_factor=1.5)
    async def rt(route):
      u=route.request.url
      if 'leaflet.js' in u: await route.fulfill(path=ROOT+'node_modules/leaflet/dist/leaflet-src.js',content_type='application/javascript')
      elif 'chart.umd' in u: await route.fulfill(path=ROOT+'node_modules/chart.js/dist/chart.umd.js',content_type='application/javascript')
      elif u.startswith('file:'): await route.continue_()
      else: await route.fulfill(body='',status=200)
    await pg.route('**/*',rt)
    await pg.add_init_script(path=ROOT+'tests/mock_seed.js')
    await pg.add_init_script(script="Date.now=(()=>{const o=Date.now;return()=>o()})()")
    U='file://'+ROOT+'index.html'
    async def go(h,name,scroll=0,wait=900):
      await pg.goto(U+'#'+h); await pg.wait_for_timeout(wait)
      if scroll: await pg.evaluate(f"window.scrollTo(0,{scroll})"); await pg.wait_for_timeout(300)
      await pg.screenshot(path=OUT+name+'.png')
    await pg.goto(U); await pg.wait_for_timeout(1200)
    await go('home','home')
    await go('map','map',scroll=0,wait=1400)
    # make a real complaint with photos as citizen, run to awaiting
    await pg.evaluate("S.preview={role:'citizen'};render(true)")
    await pg.goto(U+'#report'); await pg.wait_for_timeout(700)
    await pg.screenshot(path=OUT+'report.png')
    await pg.fill('#rfTitle','Deep pothole near Forum bus stop')
    await pg.fill('#rfDesc','Large pothole near the bus stop, two-wheelers swerving into traffic.')
    await pg.select_option('#rfCat','pothole'); await pg.click('#rfSev button[data-v="4"]'); await pg.click('#rfVul button[data-b="8"]')
    await pg.set_input_files('#rfFiles',files=[ROOT+'tests/fixtures/before.jpg'])
    await pg.evaluate("const l=LOC.find(x=>x.name==='Indiranagar');DRAFT.lat=l.lat+0.004;DRAFT.lng=l.lng-0.003;DRAFT.locality=l.id;render(true)")
    await pg.wait_for_timeout(600)
    await pg.screenshot(path=OUT+'report_filled.png')
    await pg.click('#rfSubmit'); await pg.wait_for_timeout(1500)
    cid=(await pg.evaluate('location.hash')).split('complaint-')[1]
    dept=await pg.evaluate(f"S.complaints.get('{cid}').dept")
    await pg.evaluate(f"S.preview={{role:'official',dept:'{dept}'}};render(true)"); await pg.wait_for_timeout(500)
    await pg.click('[data-s="review"]'); await pg.wait_for_timeout(500)
    await pg.click('#sAssign'); await pg.wait_for_timeout(500)
    await pg.click('[data-s="progress"]'); await pg.wait_for_timeout(500)
    await pg.screenshot(path=OUT+'official_detail.png')
    await pg.fill('#sResNote','Pothole cut, compacted and resurfaced with hot-mix asphalt.')
    await pg.set_input_files('#sResFiles',files=[ROOT+'tests/fixtures/after.jpg'])
    await pg.click('#sResolve'); await pg.wait_for_timeout(900)
    await pg.evaluate("GF.tab='awaiting'"); await pg.wait_for_timeout(3500)
    await go('gov','gov',wait=1200)
    await pg.evaluate("S.preview={role:'citizen'};render(true)")
    await pg.goto(U+'#complaint-'+cid); await pg.wait_for_timeout(900)
    # scroll to verification card
    y=await pg.evaluate("document.querySelector('#vYes').getBoundingClientRect().top+window.scrollY-260")
    await pg.evaluate(f"window.scrollTo(0,{y})"); await pg.wait_for_timeout(300)
    await pg.screenshot(path=OUT+'verify.png')
    await pg.evaluate("S.preview=null;IF.tab='health';render(true)")
    await go('insights','insights',wait=900)
    await b.close()
asyncio.run(main())

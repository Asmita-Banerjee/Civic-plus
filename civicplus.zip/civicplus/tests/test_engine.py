"""Unit tests for the C engine, loaded natively through ctypes.
Build first:  gcc -O2 -shared -fPIC -o c/libcivic_engine.so c/civic_engine.c
Run:          python3 tests/test_engine.py
"""
import ctypes, os, unittest
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
lib = ctypes.CDLL(os.path.join(ROOT, "c", "libcivic_engine.so"))
lib.cp_distance_m.restype = ctypes.c_double
lib.cp_distance_m.argtypes = [ctypes.c_double] * 4
lib.cp_severity.argtypes = [ctypes.c_int] * 4
lib.cp_priority.restype = ctypes.c_double
lib.cp_priority.argtypes = [ctypes.c_int] * 4 + [ctypes.c_double, ctypes.c_int, ctypes.c_int]
lib.cp_find_duplicates.argtypes = [ctypes.c_int, ctypes.c_double, ctypes.c_double, ctypes.c_int, ctypes.c_double]
lib.cp_hamming64.argtypes = [ctypes.c_uint] * 4

class Engine(unittest.TestCase):
    def test_distance_koramangala_indiranagar(self):
        d = lib.cp_distance_m(12.9352, 77.6245, 12.9784, 77.6408)
        self.assertAlmostEqual(d, 5100, delta=150)

    def test_severity_bounds_and_hazards(self):
        self.assertEqual(lib.cp_severity(1, 0, 0, 0), 1)
        self.assertEqual(lib.cp_severity(5, 1 | 2, 20, 5), 5)
        self.assertGreater(lib.cp_severity(3, 1, 0, 0), lib.cp_severity(3, 0, 0, 0))

    def test_priority_vulnerable_raises_score(self):
        base = lib.cp_priority(3, 0, 1, 0, 2.0, 0, 0)
        vul = lib.cp_priority(3, 2 | 4 | 16, 1, 0, 2.0, 0, 0)
        self.assertGreater(vul, base)
        self.assertLessEqual(lib.cp_priority(5, 31, 3, 3, 99.0, 99, 9), 100)

    def test_duplicates_by_radius_and_category(self):
        lat = (ctypes.c_double * 3).in_dll(lib, "cp_lat"); lon = (ctypes.c_double * 3).in_dll(lib, "cp_lon"); cat = (ctypes.c_int * 3).in_dll(lib, "cp_cat")
        pts = [(12.9352, 77.6245, 0), (12.9355, 77.6247, 0), (12.9784, 77.6408, 0)]
        for i, (a, b, c) in enumerate(pts): lat[i], lon[i], cat[i] = a, b, c
        self.assertEqual(lib.cp_find_duplicates(3, 12.9353, 77.6246, 0, 75.0), 2)
        self.assertEqual(lib.cp_find_duplicates(3, 12.9353, 77.6246, 1, 75.0), 0)

    def test_hamming(self):
        self.assertEqual(lib.cp_hamming64(0, 0, 0, 0), 0)
        self.assertEqual(lib.cp_hamming64(0xFFFFFFFF, 0, 0, 0), 32)

if __name__ == "__main__":
    unittest.main()

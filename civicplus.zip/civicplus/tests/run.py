import asyncio, sys, json, base64
from playwright.async_api import async_playwright
import os
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))+'/'
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAJklEQVR4nGP8z4AfMBGQZhhVMKpgVMGoglEFowpGFYwqGFUwqgAAvJ8BH3+vMtAAAAAASUVORK5CYII=')
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path=os.environ.get('CHROME') or None,args=['--no-sandbox'])
    pg=await b.new_page(viewport={'width':1280,'height':900})
    errs=[]
    pg.on('pageerror',lambda e: errs.append('PAGEERR '+str(e)))
    pg.on('console',lambda m: errs.append('CONSOLE '+m.text) if m.type=='error' else None)
    async def rt(route):
      u=route.request.url
      if 'leaflet.js' in u: await route.fulfill(path=ROOT+'node_modules/leaflet/dist/leaflet-src.js',content_type='application/javascript')
      elif 'chart.umd' in u: await route.fulfill(path=ROOT+'node_modules/chart.js/dist/chart.umd.js',content_type='application/javascript')
      elif u.startswith('file:'): await route.continue_()
      else: await route.fulfill(body='',status=200)
    await pg.route('**/*',rt)
    await pg.add_init_script(path=ROOT+'tests/mock.js')
    await pg.goto('file://'+ROOT+'index.html')
    await pg.wait_for_timeout(1200)
    await pg.screenshot(path='home.png',full_page=True)
    # admin init config
    await pg.goto('file://'+ROOT+'index.html#admin'); await pg.wait_for_timeout(500)
    await pg.click('#initCfg'); await pg.wait_for_timeout(500)
    # preview as citizen
    await pg.evaluate("S.preview={role:'citizen'};render(true)")
    await pg.goto('file://'+ROOT+'index.html#report'); await pg.wait_for_timeout(600)
    await pg.fill('#rfTitle','Deep pothole near bus stop')
    await pg.fill('#rfDesc','Large pothole near the Forum bus stop, two-wheelers swerving dangerously.')
    await pg.select_option('#rfCat','pothole')
    await pg.click('#rfSev button[data-v="4"]')
    await pg.click('#rfVul button[data-b="8"]')
    await pg.set_input_files('#rfFiles',files=[''+ROOT+'tests/fixtures/a.jpg'])
    await pg.wait_for_timeout(300)
    await pg.locator('#rfMap').scroll_into_view_if_needed()
    bb=await pg.locator('#rfMap').bounding_box()
    await pg.locator('#rfMap').click(position={'x':bb['width']*0.52,'y':bb['height']*0.72})
    await pg.wait_for_timeout(300)
    await pg.screenshot(path='report.png',full_page=True)
    await pg.click("#rfSubmit"); await pg.wait_for_timeout(1500)
    print("ERR:", await pg.evaluate("document.querySelector('#rfErr')?.innerText"), await pg.evaluate("document.querySelector('#toast')?.innerText"), errs)
    h=await pg.evaluate('location.hash'); print('after submit',h)
    cid=h.split('complaint-')[1]
    st=lambda: pg.evaluate(f"S.complaints.get('{cid}').status")
    # official
    dept=await pg.evaluate(f"S.complaints.get('{cid}').dept")
    await pg.evaluate(f"S.preview={{role:'official',dept:'{dept}'}};render(true)"); await pg.wait_for_timeout(400)
    await pg.click('[data-s="review"]'); await pg.wait_for_timeout(500); print('->',await st())
    await pg.click('#sAssign'); await pg.wait_for_timeout(500); print('->',await st())
    await pg.click('[data-s="progress"]'); await pg.wait_for_timeout(500); print('->',await st())
    await pg.fill('#sResNote','Cut, compacted and resurfaced with hot-mix asphalt.')
    await pg.set_input_files('#sResFiles',files=[''+ROOT+'tests/fixtures/b.jpg'])
    await pg.click('#sResolve'); await pg.wait_for_timeout(800); print('->',await st())
    # citizen disputes
    await pg.evaluate("S.preview={role:'citizen'};render(true)"); await pg.wait_for_timeout(400)
    await pg.click('#vNo'); await pg.fill('#vReason','Gravel only, it opened again after rain.'); await pg.click('#vNoSend'); await pg.wait_for_timeout(800); print('->',await st())
    # official again
    await pg.evaluate(f"S.preview={{role:'official',dept:'{dept}'}};render(true)"); await pg.wait_for_timeout(400)
    await pg.fill('#sDisp','Sending crew B with hot mix tomorrow.'); await pg.click('#sDispSend'); await pg.wait_for_timeout(500)
    await pg.click('#sAssign'); await pg.wait_for_timeout(500)
    await pg.click('[data-s="progress"]'); await pg.wait_for_timeout(500)
    await pg.fill('#sResNote','Properly resurfaced, second attempt.')
    await pg.set_input_files('#sResFiles',files=[''+ROOT+'tests/fixtures/c.jpg'])
    await pg.click('#sResolve'); await pg.wait_for_timeout(800); print('->',await st())
    await pg.evaluate("S.preview={role:'citizen'};render(true)"); await pg.wait_for_timeout(400)
    await pg.click('#vYes'); await pg.wait_for_timeout(300); await pg.click('#okb'); await pg.wait_for_timeout(800); print('->',await st())
    await pg.screenshot(path='detail.png',full_page=True)
    c=await pg.evaluate(f"S.complaints.get('{cid}')")
    print('reopen',c['reopenCount'],'resolutions',[r['outcome'] for r in c['resolutions']],'timeline',[e['type'] for e in c['timeline']])
    await pg.evaluate("S.preview=null;render(true)")
    for v in ['home','map','my','gov','admin','insights','community','access','sos','transparency','notif','about']:
      await pg.goto('file://'+ROOT+'index.html#'+v); await pg.wait_for_timeout(500)
      t=await pg.evaluate("document.querySelector('#view').innerText.slice(0,80).replace(/\\n/g,' | ')"); print(v,'::',t)
    for tab in ['predict','repeat','unheard','perf']:
      await pg.evaluate(f"IF.tab='{tab}';location.hash='insights';render(true)"); await pg.wait_for_timeout(300)
    for tab in ['people','depts','cats','settings','projects','alerts','ngos','audit']:
      await pg.evaluate(f"AF.tab='{tab}';location.hash='admin';render(true)"); await pg.wait_for_timeout(200)
    for tab in ['challenge','resources','verify']:
      await pg.evaluate(f"CF.tab='{tab}';location.hash='community';render(true)"); await pg.wait_for_timeout(200)
    await pg.set_viewport_size({'width':390,'height':844})
    await pg.goto('file://'+ROOT+'index.html#home'); await pg.wait_for_timeout(600)
    await pg.screenshot(path='mobile.png',full_page=False)
    print('\n'.join(errs) or 'no errors')
    await b.close()
asyncio.run(main())

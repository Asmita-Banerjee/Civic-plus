(function(){
const store=new Map(); const subs=[];
const parentOf=p=>p.split('/').slice(0,-1).join('/');
const snapDoc=(p)=>({id:p.split('/').pop(),exists:store.has(p),data:()=>store.has(p)?JSON.parse(JSON.stringify(store.get(p))):undefined,metadata:{fromCache:false,hasPendingWrites:false}});
function notify(){ for(const s of subs) setTimeout(()=>s.fire(),0); }
function query(path,ord,lim){ return {
  where(){return query(path,ord,lim)}, orderBy(f,d){return query(path,[f,d||'asc'],lim)}, limit(n){return query(path,ord,n)},
  async get(){ return build(); },
  onSnapshot(next,err){ const s={fire:()=>next(build())}; subs.push(s); setTimeout(s.fire,0); return ()=>{subs.splice(subs.indexOf(s),1)}; } };
  function build(){ let docs=[...store.keys()].filter(k=>parentOf(k)===path).map(snapDoc); if(ord) docs.sort((a,b)=>(a.data()[ord[0]]>b.data()[ord[0]]?1:-1)*(ord[1]==='desc'?-1:1)); if(lim) docs=docs.slice(0,lim); return {docs,size:docs.length,empty:!docs.length,docChanges:()=>[],metadata:{fromCache:false}}; }
}
function docRef(p){ return { id:p.split('/').pop(), path:p,
  async get(){return snapDoc(p)}, async set(d){ if(JSON.stringify(d).length>256*1024) throw {code:'invalid_argument',message:'too big'}; store.set(p,JSON.parse(JSON.stringify(d))); notify(); },
  async update(d){ if(!store.has(p)) throw {code:'invalid_argument'}; store.set(p,{...store.get(p),...JSON.parse(JSON.stringify(d))}); notify(); },
  async delete(){ store.delete(p); notify(); },
  onSnapshot(next){ const s={fire:()=>next(snapDoc(p))}; subs.push(s); setTimeout(s.fire,0); return ()=>{}; },
  collection(c){ return colRef(p+'/'+c); } }; }
function colRef(p){ const q=query(p); return Object.assign(q,{path:p, doc(id){ return docRef(p+'/'+(id||Math.random().toString(36).slice(2,12))); }, async add(d){ const r=this.doc(); await r.set(d); return r; } }); }
const db={doc:docRef,collection:colRef};
window.__store=store;
const user={ isOwner:()=>true, canEdit:()=>true, can:()=>true, id:async()=>'owner-uid', me:async()=>({id:'owner-uid'}), profiles:async(ids)=>Object.fromEntries(ids.map(i=>[i,{name:i==='owner-uid'?'Asmita B':'Person '+i.slice(0,4)}])) };
const assets={ upload: async (b)=>({id:'a'+Math.random(), url: URL.createObjectURL(b), sizeBytes:b.size}) };
window.claude={ use: async (n)=>({db,user,assets}[n]||null) };
})();

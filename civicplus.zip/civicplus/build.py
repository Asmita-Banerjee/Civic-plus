import json,base64,re,os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
src='src/'
css=open(src+'app.css').read()
lcss=open('node_modules/leaflet/dist/leaflet.css').read()
lcss=re.sub(r'url\([^)]*\)','none',lcss)
js=''.join(open(src+f).read()+'\n' for f in ['core.js','ui.js','analysis.js','views1.js','views2.js','views3.js','views4.js'])
js=js.replace('__LOCALITIES__',open(src+'localities.json').read())
js=js.replace('__C_SOURCE__',json.dumps(open('c/civic_engine.c').read()))
js=js.replace('__WASM__',base64.b64encode(open('c/civic_engine.wasm','rb').read()).decode())
html=f'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CivicPulse</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500..700&family=Figtree:wght@400;500;600;700&family=Noto+Sans+Kannada:wght@400;500;600;700&display=swap">
<style>{css}
/* Leaflet 1.9.4 */
{lcss}</style>
</head><body>
<div id="chrome"></div>
<main id="view"><div class="skeleton">Loading CivicPulse…</div></main>
<nav class="tabbar" id="tabbar" aria-label="Quick navigation"></nav>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
{js}
</script></body></html>'''
open('index.html','w').write(html)
print(len(html))

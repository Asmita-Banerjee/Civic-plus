/* ============ Complaint detail: tracking, government actions, citizen verification ============ */
const TL_LABEL = { submitted: "Complaint filed", review: "Accepted for review", assigned: "Assigned to team", progress: "Work started", awaiting: "Repair reported by department", confirmed: "Reporter confirmed the fix",
  disputed: "Reporter disputed the repair", rejected: "Rejected by department", reopened: "Reopened", escalated: "Escalated", lapsed: "Closed without citizen confirmation", note: "Update", dispute_reply: "Department replied to dispute",
  support: "Support added", community: "Community verification", dept: "Department changed", ai_check: "AI review of repair evidence" };
const TL_TONE = { disputed: "red", escalated: "red", rejected: "red", reopened: "red", awaiting: "amber", lapsed: "amber" };
VIEWS.complaint = {
  html(r) {
    const c = S.complaints.get(r.id);
    if (!c) return `<div class="wrap section">${S.loaded.has("complaints") ? empty(`Complaint ${esc(r.id)} wasn't found. It may have been removed. <a href="#map">Back to the map</a>`) : '<div class="skeleton">Loading complaint…</div>'}</div>`;
    const sc = scores(c); const mine = isMine(c); const cat = catOf(c.cat);
    const stepIdx = c.status === "reopened" ? 3 : STEPS.indexOf(c.status);
    const canAct = canActOn(c);
    const lastRes = (c.resolutions || [])[c.resolutions?.length - 1];
    const before = (c.media || []).find((m) => m.kind === "image");
    const after = lastRes && (lastRes.media || []).find((m) => m.kind === "image");
    const master = c.groupId && S.complaints.get(c.groupId);
    const vul = VUL.filter(([, b]) => (c.vulnerable || 0) & b).map(([k]) => t(k));
    return `<div class="wrap section"><div class="side">
    <div class="stack-lg">
      <div class="stack">
        <div class="row"><a href="javascript:history.back()" class="small">← Back</a></div>
        <div class="row">${statusPill(c)} ${prioPill(c)} ${sampleTag(c)} ${c.sos ? '<span class="pill t-red">Civic SOS</span>' : ""} ${overdue(c) ? '<span class="pill t-red">Overdue</span>' : ""}</div>
        <h2>${esc(c.title)}</h2>
        <div class="small muted num">${esc(cid(c))} · ${esc(L2(cat))} · ${esc(locName(c.locality))} · filed ${fmtDate(c.createdAt, true)} by ${esc(reporterLabel(c))}</div>
        ${master ? `<div class="banner info">This report is linked to <a href="#complaint-${esc(master._id)}">${esc(cid(master))}</a> as a duplicate. Both records are kept; the department works on the main report.</div>` : ""}
        ${(c.duplicates || []).length ? `<div class="banner info">${c.duplicates.length} other citizen report${c.duplicates.length > 1 ? "s are" : " is"} linked to this one: ${c.duplicates.map((id) => `<a href="#complaint-${esc(id)}">${esc(id)}</a>`).join(", ")}</div>` : ""}
      </div>
      <div class="card stack">
        <div class="stepper" aria-label="Progress">${STEPS.map((s, i) => `<div class="step ${i < stepIdx || c.status === "confirmed" ? "done" : i === stepIdx ? "cur" : ""}"><div class="bar"></div>${esc(L2(STATUS[s]).replace("Citizen confirmed resolved", "Confirmed").replace("Awaiting citizen verification", "Your check"))}</div>`).join("")}</div>
        ${c.status === "reopened" ? `<div class="banner danger">Reopened after the reporter said the repair did not fix the problem (${c.reopenCount} time${c.reopenCount > 1 ? "s" : ""}). The department must act again.</div>` : ""}
        ${c.status === "lapsed" ? `<div class="banner warn">The department reported a repair but the reporter did not respond before the deadline. This complaint is closed without citizen confirmation and is not counted as resolved by citizens.</div>` : ""}
        ${c.status === "rejected" ? `<div class="banner warn">Rejected: ${esc(lastOf(c, "rejected")?.note || "no reason recorded")}</div>` : ""}
        <p style="white-space:pre-wrap">${esc(c.desc)}</p>
        <div class="row"><button class="btn sm" id="ttsBtn">${icon("speaker", 16)}${esc(t("readAloud"))}</button></div>
        ${(c.media || []).length ? `<div class="gallery">${c.media.map(mediaEl).join("")}</div>` : '<p class="small muted">No photos were attached.</p>'}
        <dl class="kv">
          <dt>Department</dt><dd>${esc(deptOf(c.dept).name)}</dd>
          <dt>Team</dt><dd>${esc(c.team || "Not assigned yet")}</dd>
          <dt>Location</dt><dd>${esc([c.address, c.landmark && "near " + c.landmark, locName(c.locality)].filter(Boolean).join(", "))}</dd>
          <dt>Severity</dt><dd class="num">${sc.severity} / 5${c.sev ? ` (reporter's estimate ${c.sev})` : ""}</dd>
          <dt>Affects</dt><dd>${vul.length ? esc(vul.join(", ")) : "No vulnerable group noted"} · ${esc(POP[c.popBand || 0][0])}</dd>
          <dt>Service target</dt><dd>${c.dueAt ? fmtDate(c.dueAt) : "—"}${overdue(c) ? ` <span class="pill plain t-red">${Math.ceil((now() - c.dueAt) / DAY)} d overdue</span>` : ""}</dd>
          ${c.ai ? `<dt>AI suggestion</dt><dd>${esc(catOf(c.ai.category).en)} (${Math.round((c.ai.confidence || 0) * 100)}%)${c.ai.accepted ? ", accepted by reporter" : ", reporter chose differently"}</dd>` : ""}
        </dl>
      </div>
      ${mine ? citizenPanel(c, lastRes) : ""}
      ${canAct ? staffPanel(c, lastRes) : ""}
      ${lastRes ? `<div class="card stack"><h3>Before and after</h3>
        <div class="ba"><figure>${before ? `<img src="${esc(before.src)}" alt="Before repair">` : '<div class="ph">No before photo</div>'}<figcaption class="tiny muted">Before · reported ${fmtDate(c.createdAt)}</figcaption></figure>
        <figure>${after ? `<img src="${esc(after.src)}" alt="After repair">` : '<div class="ph">No after photo</div>'}<figcaption class="tiny muted">After · department, ${fmtDate(lastRes.at)}</figcaption></figure></div>
        <p class="small"><strong>Department's note:</strong> ${esc(lastRes.note)}</p>
        ${lastRes.aiCheck ? `<div class="ai small"><strong>${icon("sparkle", 14)} AI review of the evidence (advisory):</strong> ${esc(lastRes.aiCheck.verdict)} · ${Math.round((lastRes.aiCheck.confidence || 0) * 100)}% · ${esc(lastRes.aiCheck.notes || "")}</div>` : (before && after && S.sample && S.sampleImages && S.uid ? `<button class="btn sm" id="aiCheck">${icon("sparkle", 16)}Ask AI to compare the photos</button>` : "")}
        ${lastRes.outcome === "disputed" ? `<div class="banner danger"><div><strong>Reporter disputed this repair</strong> on ${fmtDate(lastRes.respondedAt)}: ${esc(lastRes.citizenNote)}${(lastRes.citizenMedia || []).length ? `<div class="gallery" style="margin-top:8px">${lastRes.citizenMedia.map(mediaEl).join("")}</div>` : ""}</div></div>` : ""}
        ${(c.resolutions || []).length > 1 ? `<details class="method"><summary>Earlier repair attempts (${c.resolutions.length - 1})</summary><div class="stack" style="margin-top:10px">${c.resolutions.slice(0, -1).map((r, i) => `<div class="small"><strong>Attempt ${i + 1}</strong>, ${fmtDate(r.at)}: ${esc(r.note)}<br><span class="muted">Outcome: ${esc(r.outcome)}${r.citizenNote ? ". Reporter said: " + esc(r.citizenNote) : ""}</span></div>`).join("")}</div></details>` : ""}
      </div>` : ""}
      ${communityPanel(c, mine)}
      <div class="card stack"><h3>Activity timeline</h3><div class="timeline">${[...(c.timeline || [])].reverse().map((e) => `<div class="tl ${TL_TONE[e.type] || ""}"><div class="when">${fmtDate(e.at, true)} · ${esc(e.auto ? "CivicPulse automation" : e.byRole === "citizen" ? (e.by && !c.anonymous ? nameOf(e.by) : "Citizen") : e.byRole === "admin" ? "Administrator" : "Department official")}</div><div><strong>${esc(TL_LABEL[e.type] || e.type)}</strong>${e.team ? " · " + esc(e.team) : ""}</div>${e.note ? `<div class="small">${esc(e.note)}</div>` : ""}</div>`).join("")}</div></div>
    </div>
    <aside class="stack">
      <div class="card stack"><div class="row between"><h3>${c.supportCount || 0} affected</h3>${S.uid && !mine && isOpen(c) ? `<button class="btn sm" id="supBtn">I'm affected too</button>` : ""}</div><p class="small muted">Support raises priority and helps the department see how many people this affects.</p></div>
      <div class="card stack"><h3>Where</h3><div class="map mini" id="cMap"></div></div>
      <div class="card stack"><h3>Civic memory of this spot</h3>${civicMemory(c)}</div>
    </aside></div></div>`;
  },
  after(r) {
    const c = S.complaints.get(r.id); if (!c) return;
    const m = makeMap($("#cMap"), { center: [c.lat, c.lng], zoom: 14 }); if (m) issueMarker(c).addTo(m);
    $("#ttsBtn").onclick = () => speak(`${c.title}. ${c.desc}. Status: ${L2(STATUS[c.status])}.`);
    const sb = $("#supBtn"); if (sb) sb.onclick = () => busy(sb, () => toggleSupport(c));
    bindCitizen(c); bindStaff(c); bindCommunity(c);
    const ai = $("#aiCheck"); if (ai) ai.onclick = () => busy(ai, () => aiCompare(c), "Comparing photos…");
  },
};
const lastOf = (c, type) => [...(c.timeline || [])].reverse().find((e) => e.type === type);
function mediaEl(m) { return m.kind === "video" ? `<video src="${esc(m.src)}" controls preload="metadata"></video>` : `<a href="${esc(m.src)}" target="_blank" rel="noopener"><img src="${esc(m.src)}" alt="Evidence photo" loading="lazy"></a>`; }
function canActOn(c) { const r = role(); return isAdmin() || (isOfficial() && r.dept === c.dept); }
async function toggleSupport(c) {
  if (!guardWrite()) return; const k = await myKey(c._id, "s:");
  const has = (c.supports || []).includes(k);
  await patchComplaint(c._id, (x) => { x.supports = has ? x.supports.filter((y) => y !== k) : [...(x.supports || []), k]; x.supportCount = x.supports.length + (x.duplicates || []).length; }, has ? null : { type: "support", note: "Another resident is affected" });
  toast(has ? "Support removed." : "Thanks. Your support was added.");
}
async function speak(text) {
  if (S.tts) { try { await S.tts.speak(text.slice(0, 1900), S.lang === "kn" ? {} : { language: "en" }); return; } catch (e) { if (e?.code === "viewer_stopped") return; } }
  try { const u = new SpeechSynthesisUtterance(text); u.lang = S.lang === "kn" ? "kn-IN" : "en-IN"; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch { toast("Read-aloud isn't available in this browser."); }
}
function civicMemory(c) {
  const near = allC().filter((x) => x._id !== c._id && x.lat != null && E.distance(c.lat, c.lng, x.lat, x.lng) < 120).sort((a, b) => b.createdAt - a.createdAt);
  if (!near.length) return '<p class="small muted">No other reports within 120 m. This is the first record for this spot.</p>';
  const repairs = near.filter((x) => (x.resolutions || []).length).length, reop = near.reduce((s, x) => s + (x.reopenCount || 0), 0);
  return `<p class="small muted">${near.length} earlier or nearby report${near.length > 1 ? "s" : ""} within 120 m · ${repairs} with repair records · ${reop} reopening${reop === 1 ? "" : "s"}</p>
    ${repeatLocations().some((r) => r.base._id === c._id || r.later.some((l) => l._id === c._id) || near.some((n) => n._id === r.base._id)) ? '<div class="banner warn small">Repeat location: problems here have come back after earlier repairs. A temporary fix is likely.</div>' : ""}
    <div class="clist">${near.slice(0, 6).map((x) => citem(x)).join("")}</div>`;
}
async function aiCompare(c) {
  const lastRes = c.resolutions[c.resolutions.length - 1];
  const b = (c.media || []).find((m) => m.kind === "image"), a = (lastRes.media || []).find((m) => m.kind === "image");
  const [bb, ab] = await Promise.all([fetch(b.src).then((r) => r.blob()), fetch(a.src).then((r) => r.blob())]);
  let res;
  try {
    res = await S.sample.json(`CivicPulse repair-evidence review. Image 1 is the citizen's photo of a reported problem: "${c.title}" (${catOf(c.cat).en}). Image 2 is the department's after-repair photo. Judge only from the images whether image 2 shows the same place with the problem fixed. Reply with only JSON: {"verdict": "Looks fixed" | "Not clearly fixed" | "Different location or unclear", "confidence": 0-1, "notes": "one or two short sentences"}`, { images: [bb, ab], modelTier: "default" });
  } catch (e) { throw new Error(sampleErr(e)); }
  await patchComplaint(c._id, (x) => { x.resolutions[x.resolutions.length - 1].aiCheck = { ...res, at: now() }; }, { type: "ai_check", note: `${res.verdict} (advisory, does not change status)` });
}

/* ----- citizen verification panel ----- */
function citizenPanel(c, lastRes) {
  if (c.status === "awaiting") {
    const left = c.verifyDeadline ? Math.max(0, Math.ceil((c.verifyDeadline - now()) / DAY)) : null;
    return `<div class="card stack" style="border-color:var(--amber);border-width:2px"><div class="eyebrow" style="color:var(--amber)">Your confirmation is needed</div>
      <h3>The department says this is fixed. Is it?</h3><p class="small muted">Look at the after-repair photo below and, if you can, check the spot yourself. Only you, the original reporter, can close this complaint.${left != null ? ` ${left} day${left === 1 ? "" : "s"} left to respond.` : ""}</p>
      <div class="row"><button class="btn primary lg" id="vYes">${icon("check", 18)}${esc(t("yes"))}</button><button class="btn danger lg" id="vNo">${icon("x", 18)}${esc(t("no"))}</button></div>
      <div id="vNoForm" class="stack hidden">
        <label class="f">What is still wrong? *<textarea class="input" id="vReason" maxlength="1000" placeholder="e.g. The pothole was filled with loose gravel and has opened again."></textarea></label>
        <label class="f">Fresh photos (optional)<input type="file" id="vFiles" accept="image/*" multiple class="input"></label>
        <button class="btn danger" id="vNoSend">Reopen complaint</button>
      </div></div>`;
  }
  if (c.status === "rejected") return `<div class="card stack"><h3>Disagree with the rejection?</h3><label class="f">Explain why this needs action<textarea class="input" id="cReason" maxlength="1000"></textarea></label><button class="btn" id="cContest">Ask for it to be reopened</button></div>`;
  if (c.status === "lapsed" || (c.status === "confirmed" && now() - (c.closedAt || 0) < 60 * DAY)) return `<div class="card stack"><h3>Has the problem come back?</h3><label class="f">What's wrong now?<textarea class="input" id="cReason" maxlength="1000"></textarea></label><button class="btn" id="cContest">Reopen complaint</button></div>`;
  if (c.status === "confirmed") return `<div class="banner ok">${icon("check")}<div>You confirmed this was fixed on ${fmtDate(c.closedAt)}. Thank you.</div></div>`;
  return `<div class="banner info">${icon("info")}<div>This is your complaint. You'll be asked to confirm the repair when the department reports it fixed.</div></div>`;
}
function bindCitizen(c) {
  const y = $("#vYes"), n = $("#vNo");
  if (y) y.onclick = async () => {
    if (!guardWrite() || !(await confirmBox("Confirm the repair?", "This closes the complaint as fixed and records your confirmation with today's date.", "Yes, it's fixed"))) return;
    busy(y, async () => { await patchComplaint(c._id, (x) => { x.status = "confirmed"; x.closedAt = now(); x.citizenConfirmedAt = now(); const r = x.resolutions[x.resolutions.length - 1]; r.outcome = "confirmed"; r.respondedAt = now(); }, { type: "confirmed", note: "Reporter confirmed the repair is done." }); toast("Thanks. The complaint is closed as fixed."); });
  };
  if (n) n.onclick = () => { $("#vNoForm").classList.remove("hidden"); $("#vReason").focus(); };
  const send = $("#vNoSend");
  if (send) send.onclick = () => busy(send, async () => {
    if (!guardWrite()) return; const reason = $("#vReason").value.trim(); if (reason.length < 5) { toast("Say briefly what is still wrong."); return; }
    const media = []; for (const f of [...$("#vFiles").files].slice(0, 3)) media.push(await storeMedia(f));
    await patchComplaint(c._id, (x) => { x.status = "reopened"; x.reopenCount = (x.reopenCount || 0) + 1; x.dueAt = now() + sla(x.severity || 3) * DAY; delete x.verifyDeadline; const r = x.resolutions[x.resolutions.length - 1]; r.outcome = "disputed"; r.citizenNote = reason; r.citizenMedia = media; r.respondedAt = now(); },
      { type: "disputed", note: reason });
    toast("Complaint reopened. The department has been notified.");
  }, "Reopening…");
  const ct = $("#cContest");
  if (ct) ct.onclick = () => busy(ct, async () => {
    if (!guardWrite()) return; const reason = $("#cReason").value.trim(); if (reason.length < 5) { toast("Add a short explanation."); return; }
    await patchComplaint(c._id, (x) => { x.status = "reopened"; x.reopenCount = (x.reopenCount || 0) + 1; x.closedAt = null; x.dueAt = now() + sla(x.severity || 3) * DAY; }, { type: "reopened", note: reason });
    toast("Complaint reopened.");
  });
}

/* ----- government / staff panel ----- */
function staffPanel(c, lastRes) {
  const d = deptOf(c.dept); const teams = d.teams || [];
  const st = c.status; let body = "";
  const teamSel = `<select class="input" id="sTeam">${teams.map((x) => `<option ${c.team === x ? "selected" : ""}>${esc(x)}</option>`).join("")}<option value="__other">Other team…</option></select>`;
  if (st === "submitted") body = `<p class="small muted">Check the report is genuine and belongs to ${esc(d.name)}.</p><div class="row"><button class="btn primary" data-s="review">Accept for review</button><button class="btn" id="sRejectOpen">Reject…</button></div>`;
  else if (st === "review" || st === "reopened") body = `<label class="f">Assign a maintenance team${teamSel}</label><input class="input hidden" id="sTeamOther" placeholder="Team name" maxlength="80"><label class="f">Note for the citizen (optional)<input class="input" id="sNote" maxlength="300"></label><div class="row"><button class="btn primary" id="sAssign">Assign team</button>${st === "review" ? '<button class="btn" id="sRejectOpen">Reject…</button>' : ""}</div>`;
  else if (st === "assigned") body = `<p class="small muted">Assigned to ${esc(c.team || "a team")}.</p><button class="btn primary" data-s="progress">Mark work started</button>`;
  else if (st === "progress") body = `<p class="small">Upload after-repair photos and describe the fix. The status becomes <strong>Awaiting citizen verification</strong>; only the reporter can close it.</p>
    <label class="f">What was done? *<textarea class="input" id="sResNote" maxlength="1000" placeholder="e.g. Pothole cut, compacted and resurfaced with hot-mix asphalt."></textarea></label>
    <label class="f">After-repair photos * <span class="hint">At least one photo of the same spot.</span><input type="file" id="sResFiles" accept="image/*,video/*" multiple class="input"></label>
    <button class="btn primary" id="sResolve">Submit repair for citizen verification</button>`;
  else if (st === "awaiting") body = `<div class="banner warn">Waiting for the reporter to confirm. Departments can't close complaints themselves.</div>${isAdmin() && c.verifyDeadline && now() > c.verifyDeadline ? '<button class="btn" id="sLapse">Close as not verified (deadline passed)</button>' : ""}`;
  else body = `<p class="small muted">This complaint is closed (${esc(L2(STATUS[st]))}).</p>`;
  const disputed = lastRes && lastRes.outcome === "disputed" && st === "reopened";
  return `<div class="card stack" style="border-left:3px solid var(--blue)"><div class="row between"><div class="eyebrow" style="color:var(--blue)">Department actions</div><span class="tiny muted">${esc(d.name)}</span></div>
    ${disputed ? `<div class="banner danger small">The reporter disputed the last repair: "${esc(lastRes.citizenNote)}". Reply below and send a team again.</div>
      <label class="f">Reply to the reporter<textarea class="input" id="sDisp" maxlength="800"></textarea></label><button class="btn sm" id="sDispSend">Send reply</button><hr class="sep">` : ""}
    ${body}
    <div id="sRejectForm" class="stack hidden"><label class="f">Reason for rejection * <span class="hint">The citizen sees this and can contest it.</span><textarea class="input" id="sRejReason" maxlength="500"></textarea></label><button class="btn danger" id="sReject">Reject complaint</button></div>
    ${isOpen(c) ? `<details class="method"><summary>More actions</summary><div class="stack" style="margin-top:10px">
      <label class="f">Post a public update<input class="input" id="sUpd" maxlength="300"></label><button class="btn sm" id="sUpdSend">Post update</button>
      <label class="f">Move to another department<select class="input" id="sDept">${cfg().departments.map((x) => `<option value="${esc(x.id)}" ${x.id === c.dept ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></label><button class="btn sm" id="sDeptSend">Move</button>
      <label class="check"><input type="checkbox" id="sComm" ${c.needsCommunity ? "checked" : ""}>Ask nearby citizens to verify independently</label>
    </div></details>` : ""}</div>`;
}
function bindStaff(c) {
  const go = (status, entry, mut) => patchComplaint(c._id, (x) => { x.status = status; mut && mut(x); }, { type: status, ...entry });
  $$("[data-s]").forEach((b) => b.onclick = () => busy(b, () => go(b.dataset.s, { note: b.dataset.s === "review" ? "Verified as a valid complaint" : "Team is on site" })));
  const sel = $("#sTeam"); if (sel) sel.onchange = () => $("#sTeamOther").classList.toggle("hidden", sel.value !== "__other");
  const as = $("#sAssign"); if (as) as.onclick = () => busy(as, async () => {
    const team = sel.value === "__other" ? $("#sTeamOther").value.trim() : sel.value; if (!team) { toast("Choose or name a team."); return; }
    await go("assigned", { team, note: $("#sNote").value.trim() || null }, (x) => { x.team = team; });
  });
  const ro = $("#sRejectOpen"); if (ro) ro.onclick = () => $("#sRejectForm").classList.remove("hidden");
  const rj = $("#sReject"); if (rj) rj.onclick = () => busy(rj, async () => { const r = $("#sRejReason").value.trim(); if (r.length < 5) { toast("Give the citizen a reason."); return; } await go("rejected", { note: r }, (x) => { x.closedAt = now(); }); });
  const rs = $("#sResolve"); if (rs) rs.onclick = () => busy(rs, async () => {
    const note = $("#sResNote").value.trim(); const files = [...$("#sResFiles").files].slice(0, 4);
    if (note.length < 8) { toast("Describe what was done."); return; } if (!files.length) { toast("Add at least one after-repair photo."); return; }
    const media = []; for (const f of files) media.push(await storeMedia(f));
    await go("awaiting", { note }, (x) => { x.resolutions = [...(x.resolutions || []), { at: now(), by: S.uid, note, media, outcome: "pending" }]; x.verifyDeadline = now() + (cfg().verifyDays || 7) * DAY; });
    toast("Sent to the reporter for verification.");
  }, "Uploading…");
  const lp = $("#sLapse"); if (lp) lp.onclick = () => busy(lp, () => go("lapsed", { note: "Administrator closed after the verification deadline passed without a citizen response. Not counted as citizen-confirmed." }, (x) => { x.closedAt = now(); const r = x.resolutions[x.resolutions.length - 1]; if (r) r.outcome = "no_response"; }));
  const ds = $("#sDispSend"); if (ds) ds.onclick = () => busy(ds, async () => { const v = $("#sDisp").value.trim(); if (!v) return; await patchComplaint(c._id, () => {}, { type: "dispute_reply", note: v }); });
  const us = $("#sUpdSend"); if (us) us.onclick = () => busy(us, async () => { const v = $("#sUpd").value.trim(); if (!v) return; await patchComplaint(c._id, () => {}, { type: "note", note: v }); });
  const dp = $("#sDeptSend"); if (dp) dp.onclick = () => busy(dp, async () => { const v = $("#sDept").value; if (v === c.dept) return; await patchComplaint(c._id, (x) => { x.dept = v; x.team = null; if (x.status === "assigned" || x.status === "progress") x.status = "review"; }, { type: "dept", note: `Moved from ${deptOf(c.dept).name} to ${deptOf(v).name}` }); });
  const cm = $("#sComm"); if (cm) cm.onchange = () => patchComplaint(c._id, (x) => { x.needsCommunity = cm.checked; }, null).catch((e) => toast(dbErr(e)));
}

/* ----- community verification ----- */
function communityPanel(c, mine) {
  const vs = c.community || []; const exists = vs.filter((v) => v.verdict === "exists").length, fixed = vs.filter((v) => v.verdict === "fixed").length, notFixed = vs.filter((v) => v.verdict === "not_fixed").length;
  const disagree = (fixed && notFixed) || (fixed && (c.resolutions || []).some((r) => r.outcome === "disputed")) || (notFixed && c.status === "confirmed");
  const showForm = S.uid && !mine && (c.needsCommunity || c.status === "awaiting" || isOpen(c));
  if (!vs.length && !showForm) return "";
  return `<div class="card stack"><div class="row between"><h3>Community verification</h3>${c.needsCommunity ? '<span class="pill plain t-blue">Requested</span>' : ""}</div>
    <p class="small muted">Independent checks by other residents. ${c.needsCommunity ? `High-priority issues ask for at least ${cfg().communityMin} independent confirmations.` : ""}</p>
    <div class="row small"><span class="pill plain t-grey num">${exists} saw the problem</span><span class="pill plain t-green num">${fixed} say fixed</span><span class="pill plain t-red num">${notFixed} say not fixed</span></div>
    ${disagree ? '<div class="banner warn small">Verifications disagree. An administrator should review the evidence.</div>' : ""}
    ${vs.filter((v) => v.note).slice(-4).map((v) => `<div class="small"><span class="muted">${fmtDate(v.at)} · ${esc({ exists: "Saw the problem", fixed: "Says fixed", not_fixed: "Says not fixed" }[v.verdict])}:</span> ${esc(v.note)}</div>`).join("")}
    ${showForm ? `<div class="stack" id="cvForm"><div class="seg" id="cvV">${(c.status === "awaiting" || (c.resolutions || []).length ? [["fixed", "Repair looks done"], ["not_fixed", "Not fixed"]] : [["exists", "I can see this problem"], ["not_found", "Couldn't find it"]]).map(([k, l]) => `<button type="button" data-v="${k}">${l}</button>`).join("")}</div>
      <input class="input" id="cvNote" maxlength="300" placeholder="Optional note"><label class="f small">Photo (optional)<input type="file" id="cvFile" accept="image/*" class="input"></label><button class="btn sm" id="cvSend">Add my verification</button></div>` : ""}
  </div>`;
}
function bindCommunity(c) {
  let v = null; $$("#cvV button").forEach((b) => b.onclick = () => { v = b.dataset.v; $$("#cvV button").forEach((x) => x.classList.toggle("on", x === b)); });
  const s = $("#cvSend"); if (!s) return;
  s.onclick = () => busy(s, async () => {
    if (!guardWrite()) return; if (!v) { toast("Choose what you saw."); return; }
    const key = await myKey(c._id, "v:"); const f = $("#cvFile").files[0]; const media = f ? [await storeMedia(f)] : [];
    await patchComplaint(c._id, (x) => { x.community = [...(x.community || []).filter((y) => y.key !== key), { key, verdict: v, note: $("#cvNote").value.trim().slice(0, 300), media, at: now() }]; }, { type: "community", note: { exists: "A resident confirmed the problem exists", not_found: "A resident could not find the problem", fixed: "A resident says the repair looks done", not_fixed: "A resident says it is not fixed" }[v] });
    toast("Thanks for verifying.");
  });
}

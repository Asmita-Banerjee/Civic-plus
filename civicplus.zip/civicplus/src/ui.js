/* ============ UI primitives: icons, pills, items, maps, modals ============ */
const IC = {
  home: '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  map: '<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  grid: '<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/>',
  bell: '<path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10 20a2 2 0 0 0 4 0"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  people: '<path d="M16 19v-1a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v1M9 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM22 19v-1a4 4 0 0 0-3-3.9M16 4.1a3 3 0 0 1 0 5.8"/>',
  access: '<path d="M12 6a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM9 9h6M12 9v5l-3 6M12 14l4 6"/>',
  alert: '<path d="M12 3l10 18H2zM12 10v5M12 18h.01"/>',
  coin: '<path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM9 9h5a2 2 0 0 1 0 4h-4a2 2 0 0 0 0 4h5M12 6v2M12 17v1"/>',
  info: '<path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 11v5M12 8h.01"/>',
  mic: '<path d="M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3zM5 11a7 7 0 0 0 14 0M12 18v3"/>',
  speaker: '<path d="M4 9v6h4l5 4V5L8 9zM17 9a4 4 0 0 1 0 6"/>',
  camera: '<path d="M4 7h3l2-3h6l2 3h3v12H4zM12 17a4 4 0 1 0 0-8 4 4 0 0 0 0 8z"/>',
  pin: '<path d="M12 21s-7-6.2-7-12a7 7 0 0 1 14 0c0 5.8-7 12-7 12zM12 11a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/>',
  check: '<path d="M5 12l5 5 9-11"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>', pole: '<path d="M12 2v20M6 6h12M8 10h8M4 22l6-10"/>', hole: '<path d="M3 14c0-2.5 4-4 9-4s9 1.5 9 4-4 4-9 4-9-1.5-9-4zM7 14c0-1 2-2 5-2s5 1 5 2"/>',
  tree: '<path d="M12 22v-7M7 15h10l-5-12z"/>', wave: '<path d="M2 12c3 0 3-2 5-2s2 2 5 2 3-2 5-2 2 2 5 2M2 18c3 0 3-2 5-2s2 2 5 2 3-2 5-2 2 2 5 2M12 3v5"/>',
  sparkle: '<path d="M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2zM19 15l1 2 2 1-2 1-1 2-1-2-2-1 2-1z"/>',
};
const icon = (n, s = 20) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ""}</svg>`;
const LOGO = `<svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="9" fill="var(--primary)"/><path d="M5 17h5l2.5-6 4 11 3-7.5 1.5 2.5H27" fill="none" stroke="var(--on-primary)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

function statusPill(c) {
  const s = STATUS[c.status] || STATUS.submitted;
  let h = `<span class="pill t-${s.tone}">${esc(L2(s))}</span>`;
  if (isOpen(c) && (c.escalated || 0) > 0) h += ` <span class="pill t-red">Escalated${c.escalated > 1 ? " ×" + c.escalated : ""}</span>`;
  return h;
}
const sampleTag = (x) => (x && x.demo ? '<span class="sample" title="Illustrative sample record, not real data">SAMPLE</span>' : "");
const prioTone = (p) => (p >= 70 ? "t-red" : p >= 45 ? "t-amber" : "t-grey");
const prioPill = (c) => { const p = scores(c).priority; return `<span class="pill plain ${prioTone(p)} num" title="Priority score 0–100">P${p}</span>`; };
const cid = (c) => c.displayId || c._id;
function fmtDate(ts, withTime) { if (!ts) return "—"; const o = { day: "numeric", month: "short", year: "numeric" }; if (withTime) { o.hour = "numeric"; o.minute = "2-digit"; } return new Date(ts).toLocaleString(S.lang === "kn" ? "kn-IN" : "en-IN", o); }
function ago(ts) { const d = (now() - ts) / 1000; if (d < 60) return "just now"; if (d < 3600) return Math.floor(d / 60) + " min ago"; if (d < 86400) return Math.floor(d / 3600) + " h ago"; if (d < 86400 * 30) return Math.floor(d / 86400) + " d ago"; return fmtDate(ts); }
const locName = (id) => { const l = locOf(id); return l ? L2({ en: l.name, kn: l.kn }) : "Unknown area"; };
function reporterLabel(c) { if (c.anonymous || !c.reporterId) return "Anonymous citizen"; return nameOf(c.reporterId); }

function citem(c, extra = "") {
  const sc = scores(c);
  return `<a class="citem" href="#complaint-${esc(c._id)}">
    <span class="stripe s${sc.severity}"></span>
    <div><div class="ttl">${esc(c.title)} ${sampleTag(c)}</div>
      <div class="meta"><span class="num">${esc(cid(c))}</span><span>${esc(L2(catOf(c.cat)))}</span><span>${esc(locName(c.locality))}</span><span>${ago(c.createdAt)}</span>${c.supportCount ? `<span>${c.supportCount} affected</span>` : ""}${extra}</div></div>
    <div class="right">${statusPill(c)}${prioPill(c)}</div></a>`;
}
function tile(k, v, cls = "", sub = "") { return `<div class="tile ${cls}"><div class="k">${esc(k)}</div><div class="v">${v}</div>${sub ? `<div class="tiny muted">${sub}</div>` : ""}</div>`; }
const empty = (msg) => `<div class="empty">${msg}</div>`;

let toastT;
function toast(msg, ms = 3200) { let el = $("#toast"); if (!el) { el = document.createElement("div"); el.id = "toast"; el.className = "toast"; el.setAttribute("role", "status"); document.body.append(el); } el.textContent = msg; el.classList.remove("hidden"); clearTimeout(toastT); toastT = setTimeout(() => el.classList.add("hidden"), ms); }
function modal(inner, onMount) {
  const bg = document.createElement("div"); bg.className = "modal-bg";
  bg.innerHTML = `<div class="modal fade-in" role="dialog" aria-modal="true">${inner}</div>`;
  const close = () => bg.remove();
  bg.addEventListener("click", (e) => { if (e.target === bg || e.target.closest("[data-close]")) close(); });
  document.body.append(bg); onMount && onMount(bg.firstElementChild, close); return close;
}
function confirmBox(title, body, okLabel, danger) {
  return new Promise((res) => modal(`<h3>${esc(title)}</h3><p class="muted">${esc(body)}</p><div class="row" style="justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn ${danger ? "danger" : "primary"}" id="okb">${esc(okLabel)}</button></div>`,
    (m, close) => { $("#okb", m).onclick = () => { close(); res(true); }; m.parentElement.addEventListener("click", (e) => { if (e.target.closest("[data-close]") || e.target === m.parentElement) res(false); }); }));
}
const busy = async (btn, fn, label = "Saving…") => {
  if (btn.disabled) return; const old = btn.innerHTML; btn.disabled = true; btn.textContent = label;
  try { await fn(); S.dirty = false; scheduleRender(); } catch (e) { console.error(e); toast(dbErr(e), 5000); } finally { if (btn.isConnected) { btn.disabled = false; btn.innerHTML = old; } }
};
const guardWrite = () => { if (!S.db) { toast("Sign in to claude.ai to use CivicPulse."); return false; } if (S.readOnly) { toast("You have view-only access. Ask the owner for Contributor access to take part."); return false; } return true; };

/* ---------- maps (Leaflet, schematic locality base: map tiles cannot load in this host) ---------- */
let MAPS = [];
const cssVar = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const TONE_VAR = { grey: "--grey", slate: "--blue", blue: "--blue", teal: "--teal", amber: "--amber", green: "--primary", red: "--red" };
function makeMap(el, opts = {}) {
  if (typeof L === "undefined") { el.innerHTML = '<div class="empty" style="margin:20px">The map library could not load. Lists and forms still work.</div>'; return null; }
  const m = L.map(el, { zoomControl: true, attributionControl: false, minZoom: 11, maxZoom: 18, zoomSnap: 0.5 }).setView(opts.center || [12.965, 77.625], opts.zoom || 11.5);
  m.setMaxBounds([[12.78, 77.46], [13.17, 77.83]]);
  const land = cssVar("--map-land"), line = cssVar("--map-line");
  for (const l of LOC) {
    L.polygon(l.poly, { color: line, weight: 1.2, fillColor: land, fillOpacity: 1, interactive: false }).addTo(m);
    L.tooltip({ permanent: true, direction: "center", className: "loc-label", interactive: false }).setLatLng([l.lat, l.lng]).setContent(esc(L2({ en: l.name, kn: l.kn }))).addTo(m);
  }
  if (opts.onClick) m.on("click", (e) => opts.onClick(e.latlng));
  MAPS.push(m); setTimeout(() => { if (MAPS.includes(m)) try { m.invalidateSize(); } catch {} }, 50); return m;
}
function destroyMaps() { MAPS.forEach((m) => { try { m.stop(); m.off(); m.remove(); } catch {} }); MAPS = []; }
function issueMarker(c) {
  const col = cssVar(TONE_VAR[(STATUS[c.status] || STATUS.submitted).tone]);
  const sev = scores(c).severity;
  const mk = L.circleMarker([c.lat, c.lng], { radius: 5 + sev, color: cssVar("--card"), weight: 1.5, fillColor: col, fillOpacity: 0.95 });
  const img = (c.media || []).find((x) => x.kind === "image");
  mk.bindPopup(`<div style="max-width:220px">${img ? `<img src="${esc(img.src)}" alt="" style="width:100%;border-radius:8px;aspect-ratio:4/3;object-fit:cover;margin-bottom:6px">` : ""}
    <strong>${esc(c.title)}</strong> ${sampleTag(c)}<br><span class="muted">${esc(cid(c))} · ${esc(L2(catOf(c.cat)))}</span><br>${statusPill(c)}<br>
    <span class="muted">${esc(locName(c.locality))} · ${ago(c.createdAt)}</span><br><a href="#complaint-${esc(c._id)}">Open complaint →</a></div>`);
  return mk;
}
function legendHTML() { return `<div class="legend">${["submitted", "review", "progress", "awaiting", "confirmed", "reopened"].map((k) => `<span><i style="background:var(${TONE_VAR[STATUS[k].tone]})"></i>${esc(L2(STATUS[k]))}</span>`).join("")}</div>`; }

/* ============ Shell, router, home, report, map, complaint detail ============ */
const VIEWS = {};
let CURRENT = null;
function route() { const h = (location.hash || "#home").slice(1); if (h.startsWith("complaint-")) return { name: "complaint", id: h.slice(10), key: h }; return { name: VIEWS[h] ? h : "home", key: VIEWS[h] ? h : "home" }; }
function navItems() {
  const r = role().role;
  const items = [["home", "home"], ["map", "map"], ["report", "plus"]];
  if (r === "citizen") items.push(["my", "list"]);
  if (isStaff()) items.push(["gov", "grid"]);
  if (r === "admin") items.push(["admin", "shield"]);
  items.push(["insights", "chart"], ["community", "people"]);
  return items;
}
const MORE = [["sos", "alert"], ["access", "access"], ["transparency", "coin"], ["notif", "bell"], ["about", "info"]];
function renderChrome() {
  const r = route(); const nav = navItems(); const unread = unreadCount();
  const rr = role(); const roleLabel = rr.role === "official" || rr.role === "supervisor" ? `${rr.role === "supervisor" ? "Supervisor" : "Official"} · ${deptOf(rr.dept).name}` : rr.role === "admin" ? "Administrator" : "Citizen";
  $("#chrome").innerHTML = `<header class="top"><div class="wrap">
    <a class="brand" href="#home">${LOGO}<span>CivicPulse</span></a>
    <nav class="nav" aria-label="Main">${nav.map(([k]) => `<a href="#${k}" class="${r.name === k ? "on" : ""}">${esc(t(k))}</a>`).join("")}
      <a href="#sos" class="${r.name === "sos" ? "on" : ""}">${esc(t("sos"))}</a><a href="#access" class="${r.name === "access" ? "on" : ""}">${esc(t("access"))}</a><a href="#transparency" class="${r.name === "transparency" ? "on" : ""}">${esc(t("transparency"))}</a></nav>
    <div class="top-actions">
      ${S.isOwner ? `<button class="rolechip" id="rolePrev" title="Preview the app as each role"><span class="rc-long">Viewing as: </span>${esc(roleLabel)} ▾</button>` : S.uid ? `<span class="rolechip" style="cursor:default">${esc(roleLabel)}</span>` : ""}
      <button class="langbtn" id="langBtn" aria-label="Switch language">${S.lang === "en" ? "ಕನ್ನಡ" : "English"}</button>
      <a class="iconbtn" href="#notif" aria-label="Notifications">${icon("bell", 19)}${unread ? `<span class="dot num">${unread > 99 ? "99+" : unread}</span>` : ""}</a>
    </div></div></header>
    ${S.timedOut ? `<div class="wrap" style="padding-top:10px"><div class="banner warn">Data can't be reached yet. What you see may be out of date; it will update by itself.</div></div>` : ""}
    ${!S.db && S.started ? `<div class="wrap" style="padding-top:10px"><div class="banner info">${icon("info")}<div>Sign in to claude.ai and open this page there to report issues and see live data.</div></div></div>` : ""}
    ${S.readOnly && S.db ? `<div class="wrap" style="padding-top:10px"><div class="banner info">You have view-only access. Ask the owner to give you Contributor access to report and verify issues.</div></div>` : ""}`;
  const tabs = [["home", "home"], ["map", "map"], ["report", "plus"], [isStaff() ? "gov" : "my", isStaff() ? "grid" : "list"]];
  $("#tabbar").innerHTML = tabs.map(([k, ic]) => k === "report" ? `<a href="#report" aria-label="${esc(t("report"))}"><span class="plus">${icon("plus", 20)}</span></a>` : `<a href="#${k}" class="${r.name === k ? "on" : ""}">${icon(ic, 21)}<span>${esc(t(k))}</span></a>`).join("") + `<button id="moreBtn">${icon("grid", 21)}<span>${esc(t("more"))}</span>${unread ? "" : ""}</button>`;
  $("#langBtn").onclick = () => { S.lang = S.lang === "en" ? "kn" : "en"; lsSet("cp_lang", S.lang); document.documentElement.lang = S.lang; render(true); };
  $("#moreBtn").onclick = () => modal(`<div class="row between"><h3>${esc(t("more"))}</h3><button class="iconbtn" data-close aria-label="Close">${icon("x", 18)}</button></div>
    <div class="sheet-links">${[...navItems().slice(3), ...MORE].map(([k, ic]) => `<a href="#${k}" data-close>${icon(ic)}${esc(t(k))}${k === "notif" && unread ? ` <span class="pill plain t-red num">${unread}</span>` : ""}</a>`).join("")}</div>`);
  const rp = $("#rolePrev"); if (rp) rp.onclick = rolePreviewModal;
}
function rolePreviewModal() {
  const cur = role();
  modal(`<div class="row between"><h3>Preview as a role</h3><button class="iconbtn" data-close aria-label="Close">${icon("x", 18)}</button></div>
    <p class="small muted">You own this app, so you are its administrator. Use this to test what citizens and department officials see and can do. Actions you take in a preview are real and saved, and are recorded with the previewed role.</p>
    <div class="stack">
      <button class="btn ${cur.role === "citizen" ? "primary" : ""}" data-r="citizen">Citizen</button>
      <div class="row"><select class="input" id="pvDept" style="flex:1">${cfg().departments.map((d) => `<option value="${esc(d.id)}" ${cur.dept === d.id ? "selected" : ""}>${esc(d.name)}</option>`).join("")}</select>
      <button class="btn ${cur.role === "official" ? "primary" : ""}" data-r="official">Official</button></div>
      <button class="btn ${cur.role === "admin" ? "primary" : ""}" data-r="admin">Administrator</button>
    </div>`, (m, close) => {
    $$("[data-r]", m).forEach((b) => b.onclick = () => {
      const r = b.dataset.r; S.preview = r === "admin" ? null : r === "official" ? { role: "official", dept: $("#pvDept", m).value } : { role: "citizen" };
      lsSet("cp_preview", S.preview, true); autoRan = false; close(); render(true); toast("Now viewing as " + (r === "admin" ? "Administrator" : r === "official" ? "Official, " + deptOf(S.preview.dept).name : "Citizen"));
    });
  });
}

function render(force) {
  const r = route(); const v = VIEWS[r.name];
  if (!force && CURRENT === r.key) {
    if (v.refresh) { v.refresh(r); renderChrome(); return; }
    if (S.dirty) { renderChrome(); showUpdatesPill(); return; }
  }
  if (CURRENT !== r.key) window.scrollTo(0, 0);
  destroyMaps(); CURRENT = r.key; S.dirty = false; $("#updPill")?.remove();
  const view = $("#view");
  try { view.innerHTML = `<div class="fade-in">${v.html(r)}</div>`; v.after && v.after(r); }
  catch (e) { console.error(e); view.innerHTML = `<div class="wrap section">${empty("This page hit an error: " + esc(e.message))}</div>`; }
  renderChrome();
}
function showUpdatesPill() { if ($("#updPill")) return; const b = document.createElement("div"); b.id = "updPill"; b.className = "updates"; b.innerHTML = `<button class="btn sm primary">New activity · refresh</button>`; b.onclick = () => render(true); document.body.append(b); }
async function onData() {
  await refreshMine();
  ensureProfile();
  const ids = [...allC().map((c) => (c.anonymous ? null : c.reporterId)), ...S.profiles.keys(), ...S.events.flatMap((e) => [e.createdBy, ...(e.participants || []).map((p) => p.uid)])];
  await resolveNames(ids);
  render();
  runAutomation();
}
let profileWritten = false;
function ensureProfile() {
  if (profileWritten || !S.uid || !S.db || S.readOnly || !S.loaded.has("profiles")) return;
  profileWritten = true;
  if (!S.profiles.has(S.uid)) write(() => S.db.collection("profiles").doc(S.uid).set({ joined: now(), locality: null, lang: S.lang })).catch((e) => { if (e.code === "invalid_argument") S.readOnly = true; });
}
document.addEventListener("input", (e) => { if (e.target.closest("#view") && e.target.matches("input,textarea,select") && !e.target.closest("[data-live]")) S.dirty = true; });
window.addEventListener("hashchange", () => render(true));

/* ---------------- HOME ---------------- */
VIEWS.home = {
  html() {
    const list = allC(); const conf = list.filter((c) => c.status === "confirmed");
    const medDays = median(conf.map(resolutionDays).filter((x) => x != null));
    const hazards = list.filter((c) => c.sos && isOpen(c) && now() - c.createdAt < 3 * DAY);
    const featured = list.filter(isOpen).sort((a, b) => scores(b).priority - scores(a).priority).slice(0, 3);
    const vols = S.events.reduce((s, e) => s + (e.participants || []).filter((p) => p.attended).length, 0);
    const cv = list.reduce((s, c) => s + (c.community || []).length, 0);
    const hasDemo = list.some((c) => c.demo);
    return `
    <section class="hero"><div class="wrap hero-grid">
      <div>
        <div class="eyebrow">Civic issue reporting · Bengaluru</div>
        <h1 style="margin-top:10px">CivicPulse.<br><span class="tag">${esc(t("tagline"))}</span></h1>
        <p class="lead">${esc(t("heroSub"))}</p>
        <div class="row" style="margin-top:20px"><a class="btn primary lg" href="#report">${icon("plus", 18)}${esc(t("reportBtn"))}</a><a class="btn lg" href="#map">${icon("map", 18)}${esc(t("mapBtn"))}</a></div>
        <p class="tiny muted" style="margin-top:14px">Not an emergency service. In an emergency call <strong>112</strong>.</p>
      </div>
      <div class="pulse-card stack">
        <div class="row between"><h3>Live across the city</h3>${hasDemo ? '<span class="sample">INCLUDES SAMPLE DATA</span>' : ""}</div>
        <div class="grid g4" style="grid-template-columns:1fr 1fr">
          ${tile("Reports filed", list.length, "accent")}
          ${tile("Open now", list.filter(isOpen).length, "amber")}
          ${tile("Confirmed fixed by citizens", conf.length, "accent")}
          ${tile("Median days to a confirmed fix", medDays == null ? "—" : medDays.toFixed(1), "blue")}
        </div>
        <p class="tiny muted">"Confirmed fixed" only counts complaints the original reporter marked as fixed. Department claims alone are not counted.</p>
      </div></div></section>
    ${hazards.length ? `<div class="wrap"><div class="banner danger">${icon("alert")}<div><strong>${hazards.length} active hazard${hazards.length > 1 ? "s" : ""} reported in the last 3 days:</strong> ${hazards.slice(0, 3).map((c) => `<a href="#complaint-${esc(c._id)}">${esc(L2(catOf(c.cat)))} in ${esc(locName(c.locality))}</a>`).join(", ")}. Keep clear and call 112 if anyone is in danger.</div></div></div>` : ""}
    <section class="section"><div class="wrap stack-lg">
      <div><div class="eyebrow">How it works</div><h2 style="margin-top:6px">A complaint closes when you say it's fixed</h2></div>
      <div class="how">
        <div class="card flat stack"><h3>Report</h3><p class="muted small">Add a photo, pin the spot and say who is affected. CivicPulse checks for duplicates and scores priority.</p></div>
        <div class="card flat stack"><h3>Department acts</h3><p class="muted small">The responsible department reviews it, assigns a maintenance team and posts progress.</p></div>
        <div class="card flat stack"><h3>Proof of repair</h3><p class="muted small">The department uploads after-repair photos. The status becomes Awaiting citizen verification.</p></div>
        <div class="card flat stack"><h3>You decide</h3><p class="muted small">Choose Yes, fixed to close it, or No, not fixed to reopen it with fresh evidence. Earlier records are kept.</p></div>
      </div></div></section>
    <section class="section" style="padding-top:0"><div class="wrap stack">
      <div class="row between"><h2>Issues needing attention</h2><a href="#map" class="small">See all on the map →</a></div>
      <div class="card" style="padding:4px 16px">${featured.length ? `<div class="clist">${featured.map((c) => citem(c)).join("")}</div>` : empty("No open issues yet. Be the first to report one.")}</div>
    </div></section>
    <section class="section" style="padding-top:0"><div class="wrap stack">
      <h2>Community impact</h2>
      <div class="grid g4">
        ${tile("Repairs confirmed by residents", conf.length, "accent")}
        ${tile("Community verifications", cv, "blue")}
        ${tile("Volunteer attendances", vols, "accent")}
        ${tile("Neighbourhoods with reports", new Set(list.map((c) => c.locality)).size + " / " + LOC.length, "amber")}
      </div></div></section>
    ${footer()}`;
  },
};
function footer() {
  return `<footer class="foot"><div class="wrap grid g3">
    <div class="stack"><a class="brand" href="#home">${LOGO}<span>CivicPulse</span></a><p>${esc(t("tagline"))}</p></div>
    <div class="stack small"><strong style="color:var(--ink)">Important</strong><p>CivicPulse is an independent civic-tech platform and is not an official government service. Departments shown are working names for this platform. Records marked SAMPLE are illustrative.</p></div>
    <div class="stack small"><strong style="color:var(--ink)">Emergencies</strong><p>Police, fire, ambulance: 112 · Electricity (BESCOM): 1912 · BBMP helpline: 1533</p><a href="#about">Methodology and limitations</a></div>
  </div></footer>`;
}

/* ---------------- REPORT ---------------- */
const blankDraft = () => ({ title: "", desc: "", cat: "", sev: 0, vulnerable: 0, popBand: 0, locSens: 0, lat: null, lng: null, locality: "", address: "", landmark: "", anonymous: false, files: [], hashes: [], ai: null, linkTo: null, source: "app", sos: false });
let DRAFT = blankDraft();
VIEWS.report = {
  html() {
    const d = DRAFT; const cats = cfg().categories;
    return `<div class="wrap section"><div class="side">
    <form class="stack-lg" id="rf" novalidate>
      <div><div class="eyebrow">New complaint</div><h2 style="margin-top:6px">${esc(t("reportBtn"))}</h2>
        <p class="muted small" style="margin-top:6px">You can write in English or Kannada. Fields marked * are required.</p></div>
      <div class="card stack">
        <h3>${esc(t("fPhotos"))}</h3>
        <label class="drop" for="rfFiles">${icon("camera", 22)}<div class="small"><strong>Add photos or a short video</strong><br><span class="muted">Up to 3 files. Images under 15 MB, video under 20 MB.</span></div></label>
        <input type="file" id="rfFiles" accept="image/*,video/*" multiple class="hidden">
        <div class="thumbs" id="rfThumbs"></div>
        <div id="aiBox"></div>
      </div>
      <div class="card stack">
        <label class="f">${esc(t("fTitle"))} *<input class="input" id="rfTitle" maxlength="120" value="${esc(d.title)}" placeholder="e.g. Deep pothole outside the bus stop"></label>
        <label class="f"><span class="row between"><span>${esc(t("fDesc"))} *</span><span class="row" style="gap:6px"><button type="button" class="btn sm ghost hidden" id="micBtn">${icon("mic", 16)}<span>${esc(t("speak"))}</span></button><button type="button" class="btn sm ghost" id="aiText">${icon("sparkle", 16)}Suggest category</button></span></span>
          <textarea class="input" id="rfDesc" maxlength="2000" placeholder="What did you see? Since when? Any danger?">${esc(d.desc)}</textarea></label>
        <label class="f">${esc(t("fCat"))} *<select class="input" id="rfCat"><option value="">Choose a category</option>${cats.map((c) => `<option value="${esc(c.id)}" ${d.cat === c.id ? "selected" : ""}>${esc(L2(c))}</option>`).join("")}</select></label>
        <div class="f"><span class="small" style="font-weight:600">${esc(t("fSev"))}</span>
          <div class="seg" id="rfSev">${[1, 2, 3, 4, 5].map((n) => `<button type="button" data-v="${n}" class="${d.sev === n ? "on" : ""}">${["Minor", "Moderate", "Serious", "Dangerous", "Critical"][n - 1]}</button>`).join("")}</div></div>
      </div>
      <div class="card stack">
        <h3>${esc(t("fAffected"))}</h3>
        <div class="chips" id="rfVul">${VUL.map(([k, b]) => `<button type="button" class="chipbtn ${d.vulnerable & b ? "on" : ""}" data-b="${b}">${esc(t(k))}</button>`).join("")}</div>
        <div class="grid g2">
          <label class="f">How many people does it affect?<select class="input" id="rfPop">${POP.map((p, i) => `<option value="${i}" ${d.popBand === i ? "selected" : ""}>${esc(S.lang === "kn" ? p[1] : p[0])}</option>`).join("")}</select></label>
          <label class="f">Is it near a sensitive place?<select class="input" id="rfSens">${SENS.map((p, i) => `<option value="${i}" ${d.locSens === i ? "selected" : ""}>${esc(S.lang === "kn" ? p[1] : p[0])}</option>`).join("")}</select></label>
        </div>
      </div>
      <div class="card stack">
        <div class="row between"><h3>${esc(t("fLoc"))} *</h3><button type="button" class="btn sm" id="gpsBtn">${icon("pin", 16)}Use my location</button></div>
        <p class="small muted" id="locHint">${d.lat != null ? `Pinned in ${esc(locName(d.locality))}. Tap the map to move the pin.` : "Tap the map to pin the exact spot."}</p>
        <div class="map short" id="rfMap"></div>
        <div class="grid g2">
          <label class="f">${esc(t("fAddr"))}<input class="input" id="rfAddr" maxlength="200" value="${esc(d.address)}" placeholder="Street, house number"></label>
          <label class="f">${esc(t("fLandmark"))}<input class="input" id="rfLand" maxlength="120" value="${esc(d.landmark)}" placeholder="e.g. opposite Vidya School"></label>
        </div>
      </div>
      <div class="card stack">
        <label class="check"><input type="checkbox" id="rfAnon" ${d.anonymous ? "checked" : ""}><span>${esc(t("fAnon"))}<br><span class="small muted" style="font-weight:400">Your name is never shown publicly and is not stored on the complaint. Only you can verify the repair, through a private key on your account.</span></span></label>
        <div id="rfErr"></div>
        <button class="btn primary lg" id="rfSubmit" type="submit">${esc(t("fSubmit"))}</button>
      </div>
    </form>
    <aside class="stack" data-live>
      <div class="card stack" id="scoreBox"></div>
      <div class="card stack" id="dupBox"></div>
    </aside></div></div>`;
  },
  after() {
    const d = DRAFT;
    const map = makeMap($("#rfMap"), { center: d.lat != null ? [d.lat, d.lng] : undefined, zoom: d.lat != null ? 15 : 11.5, onClick: (ll) => setPin(ll.lat, ll.lng) });
    let pin = null;
    function setPin(lat, lng, pan) {
      d.lat = +lat.toFixed(6); d.lng = +lng.toFixed(6); const loc = nearestLocality(lat, lng); d.locality = loc.id;
      if (map) { if (pin) pin.setLatLng([lat, lng]); else pin = L.circleMarker([lat, lng], { radius: 9, color: cssVar("--card"), weight: 2, fillColor: cssVar("--primary"), fillOpacity: 1 }).addTo(map); if (pan) map.setView([lat, lng], 16); }
      $("#locHint").textContent = `Pinned in ${locName(d.locality)} (${d.lat}, ${d.lng}). Tap the map to move the pin.`;
      sideUpdate();
    }
    if (d.lat != null && map) setPin(d.lat, d.lng);
    $("#gpsBtn").onclick = () => {
      if (!navigator.geolocation) return toast("Location isn't available here. Tap the map to pin the spot.");
      $("#locHint").textContent = "Finding your location…";
      navigator.geolocation.getCurrentPosition((p) => setPin(p.coords.latitude, p.coords.longitude, true),
        () => { $("#locHint").textContent = "This page isn't allowed to read your device location. Tap the map to pin the spot instead."; }, { timeout: 8000 });
    };
    const bind = (id, key, num) => { const el = $(id); el.addEventListener("input", () => { d[key] = num ? +el.value : el.value; sideUpdate(); }); };
    bind("#rfTitle", "title"); bind("#rfDesc", "desc"); bind("#rfCat", "cat"); bind("#rfPop", "popBand", 1); bind("#rfSens", "locSens", 1); bind("#rfAddr", "address"); bind("#rfLand", "landmark");
    $("#rfAnon").onchange = (e) => (d.anonymous = e.target.checked);
    $$("#rfSev button").forEach((b) => b.onclick = () => { d.sev = d.sev === +b.dataset.v ? 0 : +b.dataset.v; $$("#rfSev button").forEach((x) => x.classList.toggle("on", +x.dataset.v === d.sev)); sideUpdate(); });
    $$("#rfVul button").forEach((b) => b.onclick = () => { d.vulnerable ^= +b.dataset.b; b.classList.toggle("on"); sideUpdate(); });
    $("#rfFiles").onchange = async (e) => {
      for (const f of [...e.target.files]) {
        if (d.files.length >= 3) { toast("You can add up to 3 files."); break; }
        if (!f.type.startsWith("image/") && !f.type.startsWith("video/")) { toast("Only photos and videos can be added."); continue; }
        if (f.type.startsWith("video/") && !S.assets) { toast("Video upload isn't available with your access level. Add a photo instead."); continue; }
        d.files.push(f); if (f.type.startsWith("image/")) { const h = await dHash(f); if (h) d.hashes.push(h); }
      }
      e.target.value = ""; drawThumbs(); sideUpdate();
    };
    function drawThumbs() {
      $("#rfThumbs").innerHTML = d.files.map((f, i) => `<div class="thumb">${f.type.startsWith("video/") ? `<video src="${URL.createObjectURL(f)}" muted></video>` : `<img src="${URL.createObjectURL(f)}" alt="Selected photo ${i + 1}">`}<button type="button" data-i="${i}" aria-label="Remove">×</button></div>`).join("");
      $$("#rfThumbs button").forEach((b) => b.onclick = () => { d.files.splice(+b.dataset.i, 1); d.hashes = []; Promise.all(d.files.filter((f) => f.type.startsWith("image/")).map(dHash)).then((h) => { d.hashes = h.filter(Boolean); sideUpdate(); }); drawThumbs(); });
      drawAI();
    }
    function drawAI() {
      const box = $("#aiBox"); const img = d.files.find((f) => f.type.startsWith("image/"));
      if (d.ai) {
        const c = catOf(d.ai.category);
        box.innerHTML = `<div class="ai stack"><div class="row between"><strong>${icon("sparkle", 16)} AI suggestion</strong><span class="tiny muted">Claude vision · ${Math.round((d.ai.confidence || 0) * 100)}% confident</span></div>
          ${d.ai.is_civic_issue === false ? `<div>This photo may not show a civic problem. You can still submit it.</div>` : `<div>Looks like <strong>${esc(L2(c))}</strong>${d.ai.severity ? `, severity ${d.ai.severity}/5` : ""}. ${esc(d.ai.description || "")}</div>`}
          <div class="row"><button type="button" class="btn sm primary" id="aiApply">Use suggestion</button><button type="button" class="btn sm ghost" id="aiDismiss">Dismiss</button></div><div class="tiny muted">Suggestions can be wrong. You choose the final category.</div></div>`;
        $("#aiApply").onclick = () => { if (d.ai.category && cfg().categories.some((x) => x.id === d.ai.category)) d.cat = d.ai.category; if (d.ai.severity) d.sev = clamp(Math.round(d.ai.severity), 1, 5); if (!d.title && d.ai.title) d.title = d.ai.title.slice(0, 120); (d.ai.hazards || []).forEach((h) => { if (HZ[h]) d.hazards = (d.hazards || 0) | HZ[h]; }); render(true); };
        $("#aiDismiss").onclick = () => { d.ai = null; drawAI(); };
      } else if (img && S.sample && S.sampleImages) {
        box.innerHTML = `<button type="button" class="btn sm" id="aiRun">${icon("sparkle", 16)}Identify the problem from the photo</button>`;
        $("#aiRun").onclick = (e) => busy(e.currentTarget, async () => { d.ai = await classifyImage(img, d.desc); drawAI(); }, "Analysing photo…");
      } else if (img) box.innerHTML = `<p class="tiny muted">Photo analysis needs Claude to be allowed for this page; it isn't available in this view.</p>`;
      else box.innerHTML = "";
    }
    drawThumbs();
    $("#aiText").onclick = (e) => {
      if (!d.desc && !d.title) return toast("Describe the problem first.");
      const guess = keywordCategory(d.title + " " + d.desc);
      if (!S.sample) { if (guess) { d.cat = guess; $("#rfCat").value = guess; sideUpdate(); toast("Matched by keywords: " + catOf(guess).en); } else toast("No category matched. Choose one from the list."); return; }
      busy(e.currentTarget, async () => { d.ai = await classifyText(d.title + "\n" + d.desc); drawAI(); }, "Thinking…");
    };
    setupMic($("#micBtn"), $("#rfDesc"), (v) => { d.desc = v; sideUpdate(); });
    $("#rf").onsubmit = (e) => { e.preventDefault(); busy($("#rfSubmit"), submitReport, "Submitting…"); };
    sideUpdate();
  },
  refresh() { sideUpdate(); },
};
function sideUpdate() {
  const d = DRAFT; const sb = $("#scoreBox"), db = $("#dupBox"); if (!sb) return;
  if (d.cat) {
    const sc = scores({ ...d, createdAt: now(), supportCount: 0 });
    const due = sla(sc.severity);
    sb.innerHTML = `<div class="row between"><h3>Priority preview</h3><span class="pill plain ${prioTone(sc.priority)} num">P${sc.priority}</span></div>
      <dl class="kv"><dt>Severity</dt><dd class="num">${sc.severity} / 5</dd><dt>Department</dt><dd>${esc(deptOf(catOf(d.cat).dept).name)}</dd><dt>Service target</dt><dd>${due} day${due > 1 ? "s" : ""}</dd>
      <dt>Community check</dt><dd>${sc.priority >= cfg().communityThreshold ? "Yes, neighbours can verify" : "Not required"}</dd></dl>
      <p class="tiny muted">Scored by the CivicPulse ${esc(E.kind)} engine from category risk, your severity estimate, who is affected and the location. <a href="#about">Method</a></p>`;
  } else sb.innerHTML = `<h3>Priority preview</h3><p class="small muted">Choose a category to see severity, the responsible department and the service target.</p>`;
  const dups = findDuplicates(d);
  if (d.lat == null) db.innerHTML = `<h3>Similar reports nearby</h3><p class="small muted">Pin the location to check whether someone already reported this.</p>`;
  else if (!dups.length) { d.linkTo = null; db.innerHTML = `<h3>Similar reports nearby</h3><p class="small muted">No similar open reports within ${cfg().dupRadius || 75} m.</p>`; }
  else {
    db.innerHTML = `<h3>Possibly already reported</h3><p class="small muted">Supporting an existing report adds weight to it. If yours is different, submit it anyway.</p>
      <div class="stack">${dups.map((o) => `<div class="card flat tight stack"><div class="row between"><strong class="small">${esc(o.c.title)}</strong>${statusPill(o.c)}</div>
        <div class="tiny muted num">${esc(cid(o.c))} · ${Math.round(o.d)} m away · ${o.sameCat ? "same category" : "different category"} · text match ${Math.round(o.text * 100)}%${o.img != null ? ` · photo match ${Math.round(o.img * 100)}%` : ""} · ${o.c.supportCount || 0} affected</div>
        <div class="row"><a class="btn sm" href="#complaint-${esc(o.c._id)}">View</a><button type="button" class="btn sm ${d.linkTo === o.c._id ? "primary" : ""}" data-link="${esc(o.c._id)}">${d.linkTo === o.c._id ? "Will be linked" : "Link mine to this"}</button></div></div>`).join("")}</div>`;
    $$("[data-link]", db).forEach((b) => b.onclick = () => { d.linkTo = d.linkTo === b.dataset.link ? null : b.dataset.link; sideUpdate(); });
  }
}
function keywordCategory(s) {
  s = s.toLowerCase();
  const K = [["open_manhole", /manhole|ಮ್ಯಾನ್‌ಹೋಲ್/], ["fallen_pole", /pole.*(fell|fallen|down)|fallen pole|ಕಂಬ/], ["electrical", /wire|electric|shock|transformer|spark|ತಂತಿ|ವಿದ್ಯುತ್/], ["fallen_tree", /tree|branch|ಮರ/], ["flooding", /flood|waterlog|water.?logg|ಜಲಾವೃತ|ಪ್ರವಾಹ/],
    ["pothole", /pothole|crater|ಗುಂಡಿ/], ["sewage", /sewage|sewer|ಒಳಚರಂಡಿ/], ["drainage", /drain|gutter|ಚರಂಡಿ/], ["water_leak", /leak|pipe|burst|ಸೋರಿಕೆ/], ["garbage", /garbage|trash|waste|dump|litter|ಕಸ/],
    ["streetlight", /street ?light|lamp|dark|ದೀಪ/], ["sanitation", /toilet|urinal|sanitation|ಶೌಚಾಲಯ/], ["accessibility", /wheelchair|ramp|disab|accessib/], ["pedestrian", /footpath|pavement|zebra|crossing|pedestrian|ಪಾದಚಾರಿ/], ["traffic", /signal|traffic|sign board|ಸಂಚಾರ/], ["road_damage", /road|ರಸ್ತೆ/]];
  for (const [c, re] of K) if (re.test(s)) return c; return null;
}
const CAT_PROMPT = () => cfg().categories.map((c) => `${c.id} = ${c.en}`).join("\n");
async function classifyImage(file, note) {
  const blob = await compressImage(file, 1200, 0.8);
  try {
    return await S.sample.json(`You are the photo triage step of CivicPulse, a civic complaints platform in Bengaluru, India. Look at the attached photo a citizen took and identify the civic problem.
Allowed category ids:\n${CAT_PROMPT()}\nCitizen note (may be empty): ${String(note || "").slice(0, 400)}
Reply with only JSON: {"is_civic_issue": boolean, "category": one id from the list, "confidence": number 0-1, "severity": integer 1-5 (5 = immediate danger to life), "hazards": array of any of "electrical","open_pit","flooding","traffic","health", "title": short title under 70 characters, "description": one plain sentence describing what is visible}`, { images: [blob], modelTier: "quick" });
  } catch (e) { throw new Error(sampleErr(e)); }
}
async function classifyText(text) {
  try {
    const r = await S.sample.json(`Classify this civic complaint from Bengaluru (English or Kannada) into one category.\nAllowed category ids:\n${CAT_PROMPT()}\nComplaint: ${String(text).slice(0, 1500)}\nReply with only JSON: {"is_civic_issue": boolean, "category": id, "confidence": 0-1, "severity": 1-5, "hazards": [], "description": "one sentence explaining the choice"}`, { modelTier: "quick" });
    return r;
  } catch (e) { throw new Error(sampleErr(e)); }
}
function sampleErr(e) {
  const m = { not_granted: "Claude isn't allowed on this page. You can still choose the category yourself.", rate_limited: "Claude is busy or you've reached a usage limit. Try again later.", image_rejected: "That photo couldn't be read. Try another photo.", images_unavailable: "Photo analysis isn't available in this view.", invalid_json: "The AI reply couldn't be read. Try again." };
  return m[e?.code] || "The AI suggestion failed. Choose the category yourself.";
}
function setupMic(btn, target, onText) {
  if (!S.dictation || !btn) return;
  btn.classList.remove("hidden"); let base = ""; let on = false;
  S.dictation.onPartial(({ text }) => { if (on) { target.value = (base + " " + text).trim(); } });
  S.dictation.onFinal(({ text }) => { if (on) { base = (base + " " + text).trim(); target.value = base; onText(base); } });
  S.dictation.onState(({ state }) => { on = state === "listening"; btn.querySelector("span").textContent = on ? t("listening") : t("speak"); btn.classList.toggle("primary", on); });
  btn.onclick = () => {
    if (on) { S.dictation.stop(); return; }
    base = target.value; S.dictation.start().catch((e) => { if (e?.code === "not_granted") { btn.classList.add("hidden"); toast("Microphone not allowed. You can keep typing."); } });
  };
}
async function submitReport() {
  if (!guardWrite()) return;
  const d = DRAFT; const err = (m) => { const b = $("#rfErr"); if (b) b.innerHTML = `<div class="banner danger">${esc(m)}</div>`; toast(m, 5000); throw Object.assign(new Error(m), { shown: true }); };
  try {
    if (d.title.trim().length < 4) err("Add a short title (at least 4 characters).");
    if (d.desc.trim().length < 10) err("Describe the problem in a sentence or two.");
    if (!d.cat) err("Choose a category.");
    if (d.lat == null) err("Pin the location on the map.");
    const recent = ((S.priv && S.priv.reports) || []).filter((x) => now() - x < 10 * 60000);
    if (recent.length >= (cfg().reportLimitPer10Min || 5)) err("You've filed several reports in the last 10 minutes. Please wait a few minutes before filing another.");
  } catch (e) { if (e.shown) return; throw e; }
  if ($("#rfErr")) $("#rfErr").innerHTML = `<div class="banner info">Uploading evidence and saving…</div>`;
  const id = "CP-" + uidGen(6);
  const media = []; for (const f of d.files) media.push(await storeMedia(f));
  const key = await myKey(id);
  const c = {
    displayId: id, title: d.title.trim().slice(0, 120), desc: d.desc.trim().slice(0, 2000), cat: d.cat, dept: catOf(d.cat).dept, sev: d.sev, vulnerable: d.vulnerable, popBand: d.popBand, locSens: d.locSens, hazards: d.hazards || 0,
    lat: d.lat, lng: d.lng, locality: d.locality, address: d.address.trim().slice(0, 200), landmark: d.landmark.trim().slice(0, 120), anonymous: d.anonymous, reporterId: d.anonymous ? null : S.uid, reporterKey: key,
    media, status: "submitted", createdAt: now(), supports: [], supportCount: 0, duplicates: [], resolutions: [], reopenCount: 0, escalated: 0, community: [], sos: !!d.sos, source: d.source, lang: S.lang,
    ai: d.ai ? { category: d.ai.category, confidence: d.ai.confidence, accepted: d.ai.category === d.cat } : null, groupId: d.linkTo || null,
    timeline: [{ type: "submitted", at: now(), by: d.anonymous ? null : S.uid, byRole: "citizen", note: d.linkTo ? `Filed and linked to existing report ${d.linkTo}` : "Complaint filed" }],
  };
  const sc = scores(c); c.severity = sc.severity; c.priority = sc.priority; c.dueAt = c.createdAt + sla(sc.severity) * DAY; c.needsCommunity = sc.priority >= cfg().communityThreshold;
  c._id = id; await saveComplaint(c);
  if (d.linkTo && S.complaints.get(d.linkTo)) {
    await patchComplaint(d.linkTo, (x) => { x.duplicates = [...new Set([...(x.duplicates || []), id])]; x.supportCount = (x.supports || []).length + x.duplicates.length; }, { type: "support", note: `Duplicate report ${id} linked; the individual report is kept.` });
  }
  savePriv({ reports: [...((S.priv && S.priv.reports) || []).filter((x) => now() - x < 3600000), now()] });
  DRAFT = blankDraft(); toast(`Complaint ${id} submitted.`); location.hash = "complaint-" + id;
}

/* ---------------- MAP ---------------- */
const MF = { cat: "", status: "open", locality: "", layer: "markers", mine: false };
let mapLayers = null;
VIEWS.map = {
  html() {
    return `<div class="wrap section stack">
      <div class="row between"><div><h2>Civic map</h2><p class="small muted">Every report, coloured by status. Tap a dot for details.</p></div><a class="btn primary" href="#report">${icon("plus", 18)}${esc(t("reportBtn"))}</a></div>
      <div class="card tight row" data-live>
        <select class="input" id="mfCat" style="width:auto">${[["", "All categories"], ...cfg().categories.map((c) => [c.id, L2(c)])].map(([v, l]) => `<option value="${esc(v)}" ${MF.cat === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>
        <select class="input" id="mfStatus" style="width:auto">${[["open", "Open issues"], ["", "All statuses"], ...Object.entries(STATUS).map(([k, v]) => [k, L2(v)]), ["escalated", "Escalated"]].map(([v, l]) => `<option value="${v}" ${MF.status === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>
        <select class="input" id="mfLoc" style="width:auto"><option value="">All neighbourhoods</option>${LOC.map((l) => `<option value="${l.id}" ${MF.locality === l.id ? "selected" : ""}>${esc(L2({ en: l.name, kn: l.kn }))}</option>`).join("")}</select>
        <div class="seg" id="mfLayer">${[["markers", "Markers"], ["heat", "Heatmap"], ["predict", "Predicted risk"]].map(([k, l]) => `<button type="button" data-v="${k}" class="${MF.layer === k ? "on" : ""}">${l}</button>`).join("")}</div>
        ${S.uid ? `<label class="check small"><input type="checkbox" id="mfMine" ${MF.mine ? "checked" : ""}>Only mine</label>` : ""}
      </div>
      <div class="map tall" id="bigMap"></div>
      <div class="row between">${legendHTML()}<span class="tiny muted">Schematic neighbourhood map. Street tiles can't load in this hosted version.</span></div>
      <div class="card" style="padding:4px 16px" id="mapList"></div>
    </div>`;
  },
  after() {
    const map = makeMap($("#bigMap")); if (map) mapLayers = L.layerGroup().addTo(map);
    const upd = () => { MF.cat = $("#mfCat").value; MF.status = $("#mfStatus").value; MF.locality = $("#mfLoc").value; MF.mine = !!$("#mfMine")?.checked; drawMap(map); };
    ["#mfCat", "#mfStatus", "#mfLoc", "#mfMine"].forEach((s) => $(s) && ($(s).onchange = upd));
    $$("#mfLayer button").forEach((b) => b.onclick = () => { MF.layer = b.dataset.v; $$("#mfLayer button").forEach((x) => x.classList.toggle("on", x === b)); drawMap(map); });
    $("#mfLoc").addEventListener("change", () => { const l = locOf(MF.locality); if (l && map) map.setView([l.lat, l.lng], 14); });
    drawMap(map);
  },
  refresh() { drawMap(MAPS[0]); },
};
function mapFiltered() {
  return allC().filter((c) => c.lat != null && (!MF.cat || c.cat === MF.cat) && (!MF.locality || c.locality === MF.locality) && (!MF.mine || isMine(c)) &&
    (MF.status === "" || (MF.status === "open" ? isOpen(c) : MF.status === "escalated" ? isOpen(c) && c.escalated > 0 : c.status === MF.status)));
}
function drawMap(map) {
  const list = mapFiltered().sort((a, b) => scores(b).priority - scores(a).priority);
  if (map && mapLayers) {
    mapLayers.clearLayers();
    if (MF.layer === "markers") list.forEach((c) => mapLayers.addLayer(issueMarker(c)));
    else if (MF.layer === "heat") list.forEach((c) => { const s = scores(c).severity; mapLayers.addLayer(L.circle([c.lat, c.lng], { radius: 260 + s * 60, stroke: false, fillColor: cssVar(s >= 4 ? "--red" : "--amber"), fillOpacity: 0.1 + s * 0.035, interactive: false })); });
    else {
      const pr = predictions();
      pr.forEach((p) => { const l = locOf(p.locality); if (!l) return; const c = L.circle([l.lat, l.lng], { radius: 500 + p.p * 1400, color: cssVar("--blue"), weight: 1.5, dashArray: "5 5", fillColor: cssVar("--blue"), fillOpacity: 0.08 + p.p * 0.2 });
        c.bindPopup(`<strong>PREDICTION, not a confirmed incident</strong><br>${esc(p.label)} risk in ${esc(locName(p.locality))}: ${Math.round(p.p * 100)}%<br><span class="muted">${esc(p.why)}</span>`); mapLayers.addLayer(c); });
    }
  }
  const box = $("#mapList"); if (!box) return;
  box.innerHTML = MF.layer === "predict" ? `<div style="padding:12px 0" class="small muted">Dashed circles are predictions from past reports and rain alerts. They are not confirmed incidents. See <a href="#insights">Insights</a> for the reasoning.</div>`
    : list.length ? `<div class="row between" style="padding:10px 0 4px"><strong class="small">${list.length} matching report${list.length > 1 ? "s" : ""}</strong><span class="tiny muted">Highest priority first</span></div><div class="clist">${list.slice(0, 40).map((c) => citem(c)).join("")}</div>` : empty("No reports match these filters.");
}

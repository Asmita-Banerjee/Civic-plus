/* ============ Analytics: duplicates, civic health, predictions, repeat locations ============ */

/* Duplicate detection: C engine proximity search + description similarity + image hash + category. */
function findDuplicates(d) {
  if (d.lat == null) return [];
  const cats = cfg().categories.map((c) => c.id);
  const pool = allC().filter((c) => c.lat != null && (isOpen(c) || (c.status === "confirmed" && now() - (c.closedAt || 0) < 14 * DAY)) && !c.groupId);
  const pts = pool.map((c) => ({ lat: c.lat, lng: c.lng, cat: cats.indexOf(c.cat) }));
  const radius = cfg().dupRadius || 75;
  const hits = E.near(pts, d.lat, d.lng, -1, radius * 1.4);
  const out = [];
  for (const h of hits) {
    const c = pool[h.i];
    const sameCat = c.cat === d.cat;
    const prox = clamp(1 - h.d / (radius * 1.4), 0, 1);
    const text = jaccard(d.title + " " + d.desc, c.title + " " + c.desc);
    let img = null;
    const hA = (d.hashes || [])[0], hB = (c.media || []).find((m) => m.hash)?.hash;
    if (hA && hB) img = 1 - E.hamming(hA, hB) / 64;
    let score = 0.45 * prox + 0.25 * text + (sameCat ? 0.2 : 0) + (img != null ? 0.1 * img : 0.05);
    if (!sameCat && text < 0.2) score *= 0.6;
    out.push({ c, d: h.d, score, sameCat, text, img });
  }
  return out.filter((o) => o.score >= 0.4).sort((a, b) => b.score - a.score).slice(0, 4);
}

/* Repeat locations: problems that return after a confirmed repair, or complaints reopened twice or more. */
function repeatLocations() {
  const res = [];
  const list = allC();
  for (const a of list) {
    if (a.status !== "confirmed" || !a.closedAt || a.lat == null) continue;
    const later = list.filter((b) => b._id !== a._id && b.cat === a.cat && b.lat != null && b.createdAt > a.closedAt && b.createdAt - a.closedAt < 150 * DAY && E.distance(a.lat, a.lng, b.lat, b.lng) < 100);
    if (later.length) res.push({ kind: "returned", base: a, later, locality: a.locality, cat: a.cat, days: Math.round((later[0].createdAt - a.closedAt) / DAY) });
  }
  for (const c of list) if ((c.reopenCount || 0) >= 2) res.push({ kind: "reopened", base: c, later: [], locality: c.locality, cat: c.cat, reopen: c.reopenCount });
  return res;
}

/* Civic Health Score per locality. Starts at 100; each factor subtracts up to its cap. */
const HEALTH_METHOD = [
  ["Unresolved backlog", 30, "Sum of severity of open complaints × 1.5"],
  ["Slow resolution", 20, "Median days to citizen-confirmed fix beyond the service target, × 2 per day"],
  ["Recurring problems", 15, "5 points per repeat location (problem came back after repair, or reopened twice)"],
  ["Open safety hazards", 15, "5 points per open complaint with severity 4–5 or Civic SOS"],
  ["Accessibility", 10, "3 points per open accessibility barrier or unresolved footpath obstacle"],
  ["Failed repairs", 10, "2 points per citizen dispute (reopening) in the last 180 days"],
];
function healthScores() {
  const list = allC(); const reps = repeatLocations();
  const counts = LOC.map((l) => list.filter((c) => c.locality === l.id).length);
  const med = median(counts.filter((x) => x > 0)) || 0;
  return LOC.map((l) => {
    const mine = list.filter((c) => c.locality === l.id);
    const open = mine.filter(isOpen);
    const res = mine.map(resolutionDays).filter((x) => x != null);
    const medRes = median(res);
    const target = 7;
    const f = {
      backlog: Math.min(30, open.reduce((s, c) => s + (c.severity || scores(c).severity), 0) * 1.5),
      slow: medRes == null ? 0 : Math.min(20, Math.max(0, medRes - target) * 2),
      recurring: Math.min(15, reps.filter((r) => r.locality === l.id).length * 5),
      safety: Math.min(15, open.filter((c) => (c.severity || scores(c).severity) >= 4 || c.sos).length * 5),
      access: Math.min(10, (open.filter((c) => c.cat === "accessibility").length + S.access.filter((a) => a.kind === "obstacle" && a.locality === l.id && !a.cleared).length) * 3),
      failed: Math.min(10, mine.reduce((s, c) => s + (c.timeline || []).filter((e) => e.type === "disputed" && now() - e.at < 180 * DAY).length, 0) * 2),
    };
    const score = Math.round(100 - Object.values(f).reduce((a, b) => a + b, 0));
    const lowData = mine.length < Math.max(2, med * 0.35);
    return { l, score, f, n: mine.length, open: open.length, medRes, lowData, confirmed: mine.filter((c) => c.status === "confirmed").length };
  });
}

/* Predictive civic intelligence: recurrence statistics per locality and category, weighted for the monsoon months. */
const PRED_CATS = { flooding: "Flooding", drainage: "Drain blockage", pothole: "Potholes", garbage: "Garbage accumulation", sewage: "Sewage overflow", road_damage: "Potholes" };
function predictions() {
  const list = allC(); const out = new Map(); const m = new Date().getMonth();
  const monsoon = [5, 6, 7, 8, 9, 10].includes(m) || [5, 6, 7, 8, 9, 10].includes((m + 1) % 12);
  for (const c of list) {
    const label = PRED_CATS[c.cat]; if (!label || !c.locality) continue;
    const key = c.locality + "|" + label;
    const o = out.get(key) || { locality: c.locality, label, n: 0, recent: 0, monsoonN: 0, months: new Set(), ids: [] };
    o.n++; o.ids.push(c._id); const age = now() - c.createdAt; if (age < 180 * DAY) o.recent++;
    const cm = new Date(c.createdAt).getMonth(); o.months.add(new Date(c.createdAt).getFullYear() * 12 + cm); if (cm >= 5 && cm <= 10) o.monsoonN++;
    out.set(key, o);
  }
  const rain = activeRainAlerts();
  return [...out.values()].filter((o) => o.n >= 2).map((o) => {
    let p = 0.18 * o.months.size + 0.12 * o.recent;
    const wet = ["Flooding", "Drain blockage", "Sewage overflow", "Potholes"].includes(o.label);
    if (wet && monsoon) p += 0.15 * (o.monsoonN / o.n);
    const alert = rain.find((a) => (a.localities || []).includes(o.locality) || (a.localities || []).length === 0);
    if (wet && alert) p += alert.level === "red" ? 0.3 : alert.level === "orange" ? 0.2 : 0.1;
    p = clamp(p, 0, 0.95);
    return { ...o, p, months: o.months.size, alert, why: `${o.n} past reports across ${o.months.size} month(s), ${o.recent} in the last 6 months${wet && monsoon ? ", monsoon season" : ""}${alert ? ", active rain alert" : ""}` };
  }).sort((a, b) => b.p - a.p);
}
function activeRainAlerts() { return S.alerts.filter((a) => a.until && a.until > now()); }

/* Unheard neighbourhoods: reporting activity relative to the city median. */
function reportingActivity() {
  const list = allC(); const yr = now() - 365 * DAY;
  const rows = LOC.map((l) => ({ l, n: list.filter((c) => c.locality === l.id && c.createdAt > yr).length, surveys: S.surveys.filter((s) => s.locality === l.id).length }));
  const med = median(rows.map((r) => r.n)) || 0;
  return rows.map((r) => ({ ...r, ratio: med ? r.n / med : 0, low: r.n < med * 0.5 || r.n <= 1 })).sort((a, b) => a.ratio - b.ratio);
}

/* Department performance. */
function deptStats(deptId) {
  const list = allC().filter((c) => !deptId || c.dept === deptId);
  const conf = list.filter((c) => c.status === "confirmed");
  const res = conf.map(resolutionDays).filter((x) => x != null);
  const closedByDept = list.filter((c) => (c.resolutions || []).length);
  const firstTime = closedByDept.filter((c) => c.status === "confirmed" && (c.reopenCount || 0) === 0).length;
  return {
    total: list.length, open: list.filter(isOpen).length, overdue: list.filter(overdue).length,
    reopened: list.filter((c) => (c.reopenCount || 0) > 0).length, confirmed: conf.length,
    lapsed: list.filter((c) => c.status === "lapsed").length,
    avgDays: res.length ? res.reduce((a, b) => a + b, 0) / res.length : null,
    firstTimeRate: closedByDept.length ? firstTime / closedByDept.length : null,
    awaiting: list.filter((c) => c.status === "awaiting").length,
    escalated: list.filter((c) => isOpen(c) && (c.escalated || 0) > 0).length,
  };
}

/* Civic Challenge: verified improvements per locality this month. */
function challengeBoard() {
  const start = new Date(); start.setDate(1); start.setHours(0, 0, 0, 0);
  const t0 = start.getTime();
  return LOC.map((l) => {
    const list = allC().filter((c) => c.locality === l.id);
    const fixes = list.filter((c) => c.status === "confirmed" && c.closedAt >= t0).length;
    const cv = list.reduce((s, c) => s + (c.community || []).filter((v) => v.at >= t0).length, 0);
    const reop = list.reduce((s, c) => s + (c.timeline || []).filter((e) => e.type === "disputed" && e.at >= t0).length, 0);
    const vol = S.events.filter((e) => e.locality === l.id && e.date >= t0 && e.date <= now()).reduce((s, e) => s + (e.participants || []).filter((p) => p.attended).length, 0);
    return { l, fixes, cv, reop, vol, points: fixes * 10 + cv * 3 + vol * 2 - reop * 5 };
  }).sort((a, b) => b.points - a.points);
}

/* Automatic escalation and verification deadlines. Runs on staff devices; each change is written once. */
let autoRan = false;
async function runAutomation() {
  if (autoRan || !isStaff() || S.readOnly || !S.db) return; autoRan = true;
  for (const c of allC()) {
    try {
      if (c.status === "awaiting" && c.verifyDeadline && now() > c.verifyDeadline && cfg().lapseAction === "close_unverified") {
        await patchComplaint(c._id, (x) => { x.status = "lapsed"; x.closedAt = now(); const r = x.resolutions?.[x.resolutions.length - 1]; if (r) r.outcome = "no_response"; },
          { type: "lapsed", auto: true, note: `The reporter did not respond within ${cfg().verifyDays} days. Closed without citizen confirmation; the record does not count as citizen-confirmed.` });
      } else if (overdue(c) && (!c.escalatedAt || now() - c.escalatedAt > sla(c.severity || 3) * DAY)) {
        const lvl = (c.escalated || 0) + 1;
        await patchComplaint(c._id, (x) => { x.escalated = lvl; x.escalatedAt = now(); },
          { type: "escalated", auto: true, note: `Overdue by ${Math.ceil((now() - c.dueAt) / DAY)} day(s). Escalated to level ${lvl}; department supervisor notified.` });
      }
    } catch (e) { console.warn("automation", e); }
  }
}

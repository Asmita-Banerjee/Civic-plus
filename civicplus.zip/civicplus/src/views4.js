/* ============ Insights, community, accessibility, SOS, transparency, about, boot ============ */
const ngoVerified = (n) => (cfg().verifiedNgos || []).includes(n._id);
const IF = { tab: "health" };
VIEWS.insights = {
  html() {
    const T = { health: "Civic Health Scores", predict: "Predictions", repeat: "Repeat locations", unheard: "Unheard neighbourhoods", perf: "Department performance" };
    return `<div class="wrap section stack-lg"><div><div class="eyebrow">Civic intelligence</div><h2 style="margin-top:6px">${esc(t("insights"))}</h2>
      <p class="small muted" style="margin-top:6px;max-width:70ch">Calculated live from every report in CivicPulse. Methods are shown in full. Predictions are estimates from past patterns and are always labelled; they are never treated as confirmed incidents.</p></div>
      ${activeRainAlerts().length ? `<div class="banner warn">${icon("wave")}<div><strong>Before-it-happens alert.</strong> ${activeRainAlerts().map((a) => `${esc(a.level)} rain warning${a.rainMm ? ` (${a.rainMm} mm)` : ""} until ${fmtDate(a.until, true)}, source: ${esc(a.source)}`).join("; ")}. Neighbourhoods with past flooding or drain reports are ranked under Predictions.</div></div>` : ""}
      <div class="tabs" id="iTabs">${Object.entries(T).map(([k, l]) => `<button data-k="${k}" class="${IF.tab === k ? "on" : ""}">${l}</button>`).join("")}</div>
      <div>${INS[IF.tab]()}</div></div>`;
  },
  after() { $$("#iTabs button").forEach((b) => b.onclick = () => { IF.tab = b.dataset.k; render(true); }); INS_BIND[IF.tab] && INS_BIND[IF.tab](); },
};
const INS = {
  health() {
    const hs = healthScores().sort((a, b) => (a.lowData - b.lowData) || a.score - b.score);
    const tone = (s) => (s >= 80 ? "var(--primary)" : s >= 60 ? "var(--amber)" : "var(--red)");
    return `<div class="stack-lg"><details class="method"><summary>How the Civic Health Score is calculated</summary><div class="stack small" style="margin-top:10px">
      <p>Each neighbourhood starts at 100. Six factors subtract points, each up to a cap:</p>
      <table class="tbl"><thead><tr><th>Factor</th><th>Max</th><th>Rule</th></tr></thead><tbody>${HEALTH_METHOD.map(([a, b, c]) => `<tr><td>${a}</td><td class="num">−${b}</td><td>${c}</td></tr>`).join("")}</tbody></table>
      <p><strong>Few reports do not mean a healthy area.</strong> Where a neighbourhood has under a third of the city's median report count, CivicPulse marks it "Not enough reports" instead of giving a score, and lists it under Unheard neighbourhoods.</p></div></details>
      <div class="grid g3">${hs.map((h) => `<div class="card tight stack"><div class="row between"><strong>${esc(L2({ en: h.l.name, kn: h.l.kn }))}</strong>${h.lowData ? '<span class="pill plain t-amber">Not enough reports</span>' : `<span class="score" style="color:${tone(h.score)}">${h.score}</span>`}</div>
        ${h.lowData ? `<p class="small muted">${h.n} report${h.n === 1 ? "" : "s"} on record. Low reporting may hide problems. <a href="#community">Run a survey</a>.</p>` : `<div class="bar-h"><span style="width:${h.score}%;background:${tone(h.score)}"></span></div>
        <div class="tiny muted">${h.open} open · ${h.confirmed} citizen-confirmed · median fix ${h.medRes != null ? h.medRes.toFixed(1) + " d" : "—"}</div>
        <div class="tiny">${Object.entries(h.f).filter(([, v]) => v > 0).map(([k, v]) => `${{ backlog: "Backlog", slow: "Slow fixes", recurring: "Recurring", safety: "Safety", access: "Accessibility", failed: "Failed repairs" }[k]} −${Math.round(v)}`).join(" · ") || "No deductions"}</div>`}</div>`).join("")}</div></div>`;
  },
  predict() {
    const pr = predictions();
    return `<div class="stack-lg"><div class="banner info small">${icon("info")}<div>These are <strong>predictions</strong>, not reported incidents. They estimate where a problem is likely to recur from the history of reports, the season (Bengaluru's monsoon months) and any active rain warning entered by an administrator.</div></div>
      <div class="card stack">${pr.length ? `<div class="scroll-x"><table class="tbl"><thead><tr><th>Neighbourhood</th><th>Likely problem</th><th>Estimated likelihood</th><th>Why</th></tr></thead><tbody>${pr.map((p) => `<tr><td><strong>${esc(locName(p.locality))}</strong></td><td>${esc(p.label)} <span class="pill plain t-blue">Prediction</span></td><td style="min-width:140px"><div class="row" style="gap:8px"><div class="bar-h" style="flex:1"><span style="width:${Math.round(p.p * 100)}%;background:var(--blue)"></span></div><span class="num small">${Math.round(p.p * 100)}%</span></div></td><td class="small muted">${esc(p.why)}</td></tr>`).join("")}</tbody></table></div>` : empty("Not enough history yet. Predictions need at least two past reports of the same kind in a neighbourhood.")}</div>
      <details class="method"><summary>Prediction method</summary><p class="small" style="margin-top:8px">Likelihood = 0.18 × distinct months with reports + 0.12 × reports in the last 6 months, + up to 0.15 for wet-weather categories in or before monsoon months (June to November), + 0.1 / 0.2 / 0.3 for an active yellow / orange / red rain warning covering the area. Capped at 95%. This is a transparent heuristic, not a trained model; it will be replaced by a trained model once enough history exists.</p></details></div>`;
  },
  repeat() {
    const reps = repeatLocations();
    return `<div class="card stack"><p class="small muted">Places where a problem came back within 150 days of a citizen-confirmed repair (within 100 m, same category), or where the reporter rejected the repair twice or more. These suggest temporary or ineffective fixes.</p>
      ${reps.length ? reps.map((r) => `<div class="card flat tight stack"><div class="row between"><strong>${esc(L2(catOf(r.cat)))} · ${esc(locName(r.locality))}</strong><span class="pill t-red">${r.kind === "returned" ? `Returned after ${r.days} days` : `Repair rejected ${r.reopen}×`}</span></div>
        <div class="small">Original: <a href="#complaint-${esc(r.base._id)}">${esc(cid(r.base))}</a> ${sampleTag(r.base)}${r.later.length ? ` · came back as ${r.later.map((l) => `<a href="#complaint-${esc(l._id)}">${esc(cid(l))}</a>`).join(", ")}` : ""}</div></div>`).join("") : empty("No repeat locations detected.")}</div>`;
  },
  unheard() {
    const rows = reportingActivity(); const low = rows.filter((r) => r.low);
    return `<div class="stack-lg"><div class="card stack"><h3>Low reporting activity</h3><p class="small muted">Reports in the last 12 months compared with the city median. Low numbers can mean fewer problems, or that residents aren't being heard. Community surveys and volunteer observations help tell the difference.</p>
      <div class="scroll-x"><table class="tbl"><thead><tr><th>Neighbourhood</th><th>Reports (12 mo)</th><th>vs median</th><th>Surveys</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${esc(L2({ en: r.l.name, kn: r.l.kn }))} ${r.low ? '<span class="pill plain t-amber">Low activity</span>' : ""}</td><td class="num">${r.n}</td><td class="num">${Math.round(r.ratio * 100)}%</td><td class="num">${r.surveys}</td></tr>`).join("")}</tbody></table></div></div>
      <form class="card stack" id="svForm"><h3>Neighbourhood survey</h3><p class="small muted">Takes a minute. Answers are stored without your name. Kannada or English is fine.</p>
        <label class="f">Neighbourhood<select class="input" id="svLoc">${(low.length ? low : rows).map((r) => `<option value="${r.l.id}">${esc(L2({ en: r.l.name, kn: r.l.kn }))}</option>`).join("")}</select></label>
        <div class="grid g3">${[["roads", "Roads & footpaths"], ["garbage", "Garbage collection"], ["water", "Water & drainage"], ["lights", "Street lighting"], ["safety", "Walking safety"]].map(([k, l]) => `<label class="f">${l}<select class="input" data-sv="${k}"><option value="">Skip</option><option value="1">1 · Very poor</option><option value="2">2 · Poor</option><option value="3">3 · OK</option><option value="4">4 · Good</option><option value="5">5 · Very good</option></select></label>`).join("")}</div>
        <label class="f">Biggest problem you see<textarea class="input" id="svNote" maxlength="800"></textarea></label>
        <label class="check"><input type="checkbox" id="svVol">I'm a volunteer recording an observation for residents who can't use the app</label>
        <button class="btn primary" style="align-self:flex-start">Submit survey</button></form></div>`;
  },
  perf() {
    const ds = cfg().departments; const st = ds.map((d) => ({ d, s: deptStats(d.id) }));
    return `<div class="stack-lg"><div class="card stack"><h3>Average days to a citizen-confirmed fix</h3><div style="height:${Math.max(220, ds.length * 32)}px"><canvas id="pChart"></canvas></div></div>
      <div class="card"><div class="scroll-x"><table class="tbl"><thead><tr><th>Department</th><th>Total</th><th>Open</th><th>Overdue</th><th>Citizen-confirmed</th><th>Reopened</th><th>Fixed first time</th><th>Avg days</th></tr></thead><tbody>
      ${st.map(({ d, s }) => `<tr><td>${esc(d.name)}</td><td class="num">${s.total}</td><td class="num">${s.open}</td><td class="num" style="${s.overdue ? "color:var(--red);font-weight:600" : ""}">${s.overdue}</td><td class="num">${s.confirmed}</td><td class="num">${s.reopened}</td><td class="num">${s.firstTimeRate != null ? Math.round(s.firstTimeRate * 100) + "%" : "—"}</td><td class="num">${s.avgDays != null ? s.avgDays.toFixed(1) : "—"}</td></tr>`).join("")}</tbody></table></div>
      <p class="tiny muted" style="margin-top:8px">Only repairs the reporter confirmed count as fixed. Complaints closed without a citizen response are excluded.</p></div></div>`;
  },
};
const INS_BIND = {
  perf() { const ds = cfg().departments; const c = $("#pChart"); if (c && typeof Chart !== "undefined") barChart(c, ds.map((d) => d.name), [{ label: "Average days", data: ds.map((d) => +(deptStats(d.id).avgDays || 0).toFixed(1)), color: cssVar("--primary") }], { horizontal: true }); },
  unheard() {
    $("#svForm").onsubmit = (e) => { e.preventDefault(); busy(e.target.querySelector("button"), async () => {
      if (!guardWrite()) return; const ratings = {}; $$("[data-sv]").forEach((s) => { if (s.value) ratings[s.dataset.sv] = +s.value; });
      const note = $("#svNote").value.trim(); if (!Object.keys(ratings).length && !note) { toast("Answer at least one question."); return; }
      await write(() => S.db.collection("surveys").add({ locality: $("#svLoc").value, ratings, note: note.slice(0, 800), volunteer: $("#svVol").checked, lang: S.lang, at: now() }));
      toast("Thank you. Survey recorded."); render(true);
    }); };
  },
};

/* ---------- community: volunteers, challenge, resources, verification ---------- */
const CF = { tab: "volunteer" };
VIEWS.community = {
  html() {
    const T = { volunteer: "Volunteer network", challenge: "Civic Challenge", resources: "Resource exchange", verify: "Verify near me" };
    return `<div class="wrap section stack-lg"><div><div class="eyebrow">Community</div><h2 style="margin-top:6px">${esc(t("community"))}</h2></div>
      <div class="tabs" id="coTabs">${Object.entries(T).map(([k, l]) => `<button data-k="${k}" class="${CF.tab === k ? "on" : ""}">${l}</button>`).join("")}</div><div>${COM[CF.tab]()}</div></div>`;
  },
  after() { $$("#coTabs button").forEach((b) => b.onclick = () => { CF.tab = b.dataset.k; render(true); }); COM_BIND[CF.tab] && COM_BIND[CF.tab](); },
};
const EV_TYPES = { cleanup: "Clean-up drive", trees: "Tree plantation", awareness: "Awareness walk", repair: "Community repair", other: "Other initiative" };
const RES_KINDS = { food: "Food", water: "Drinking water", clothes: "Clothes & blankets", shelter: "Shelter supplies", medical: "First aid & hygiene", other: "Other essentials" };
const COM = {
  volunteer() {
    const up = S.events.filter((e) => e.date >= now() - DAY).sort((a, b) => a.date - b.date), past = S.events.filter((e) => e.date < now() - DAY).sort((a, b) => b.date - a.date);
    const mineHours = S.events.reduce((s, e) => s + ((e.participants || []).find((p) => p.uid === S.uid && p.attended)?.hours || 0), 0);
    const ev = (e) => { const me = (e.participants || []).find((p) => p.uid === S.uid); const org = e.createdBy === S.uid || isAdmin(); const isPast = e.date < now();
      return `<div class="card tight stack"><div class="row between"><strong>${esc(e.title)}</strong>${sampleTag(e)}<span class="pill plain t-green">${esc(EV_TYPES[e.type] || "Initiative")}</span></div>
        <div class="small muted">${fmtDate(e.date, true)} · ${esc(locName(e.locality))} · organised by ${esc(e.organizer || nameOf(e.createdBy))} · ${(e.participants || []).length} joined</div>
        ${e.desc ? `<p class="small">${esc(e.desc)}</p>` : ""}
        <div class="row">${S.uid && !isPast ? `<button class="btn sm ${me ? "" : "primary"}" data-join="${esc(e._id)}">${me ? "Leave" : "Join"}</button>` : ""}
          ${me && me.attended ? `<button class="btn sm" data-cert="${esc(e._id)}">View certificate</button>` : ""}
          ${org && (e.participants || []).length ? `<button class="btn sm ghost" data-att="${esc(e._id)}">Record attendance</button>` : ""}</div></div>`; };
    return `<div class="side"><div class="stack"><h3>Upcoming</h3>${up.length ? up.map(ev).join("") : empty("No upcoming events. Start one.")}${past.length ? `<h3 style="margin-top:10px">Past</h3>${past.slice(0, 8).map(ev).join("")}` : ""}</div>
      <div class="stack">${S.uid ? `<div class="tile accent"><div class="k">My verified volunteer hours</div><div class="v">${mineHours}</div></div>` : ""}
      <form class="card stack" id="evForm"><h3>Organise an initiative</h3>
        <label class="f">Title *<input class="input" id="evTitle" maxlength="100" required></label>
        <label class="f">Type<select class="input" id="evType">${Object.entries(EV_TYPES).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></label>
        <label class="f">Neighbourhood<select class="input" id="evLoc">${LOC.map((l) => `<option value="${l.id}">${esc(l.name)}</option>`).join("")}</select></label>
        <label class="f">Date and time *<input class="input" type="datetime-local" id="evDate" required></label>
        <label class="f">Details<textarea class="input" id="evDesc" maxlength="600"></textarea></label>
        <button class="btn primary" style="align-self:flex-start">Publish initiative</button></form></div></div>`;
  },
  challenge() {
    const b = challengeBoard(); const m = new Date().toLocaleString("en-IN", { month: "long", year: "numeric" });
    return `<div class="card stack"><div class="row between"><h3>Neighbourhood leaderboard · ${m}</h3></div><p class="small muted">Points come only from verified improvements: 10 per citizen-confirmed fix, 3 per community verification, 2 per volunteer attendance, minus 5 per disputed repair.</p>
      <div class="scroll-x"><table class="tbl"><thead><tr><th>#</th><th>Neighbourhood</th><th>Confirmed fixes</th><th>Verifications</th><th>Volunteers</th><th>Disputes</th><th>Points</th></tr></thead><tbody>
      ${b.map((r, i) => `<tr><td class="num">${i + 1}</td><td><strong>${esc(L2({ en: r.l.name, kn: r.l.kn }))}</strong></td><td class="num">${r.fixes}</td><td class="num">${r.cv}</td><td class="num">${r.vol}</td><td class="num">${r.reop}</td><td class="num"><strong>${r.points}</strong></td></tr>`).join("")}</tbody></table></div></div>`;
  },
  resources() {
    const open = S.resources.filter((r) => r.status !== "matched").sort((a, b) => b.at - a.at);
    const matches = open.filter((r) => r.kind === "need").map((n) => ({ n, offers: open.filter((o) => o.kind === "offer" && o.item === n.item) })).filter((x) => x.offers.length);
    const row = (r) => { const ngo = S.ngos.find((n) => n._id === r.ngoId);
      return `<div class="card flat tight stack"><div class="row between"><strong>${esc(RES_KINDS[r.item] || r.item)}${r.qty ? " · " + esc(r.qty) : ""}</strong>${sampleTag(r)}<span class="pill plain ${r.kind === "need" ? "t-red" : "t-green"}">${r.kind === "need" ? (r.urgent ? "Urgent need" : "Need") : "Surplus offered"}</span></div>
        <div class="small muted">${esc(locName(r.locality))} · ${ngo ? `${esc(ngo.name)} ${ngoVerified(ngo) ? '<span class="pill plain t-green">Verified</span>' : '<span class="pill plain t-grey">Unverified</span>'}` : "Individual"} · ${ago(r.at)}</div>
        ${r.note ? `<div class="small">${esc(r.note)}</div>` : ""}${r.contact ? `<div class="small">Contact: ${esc(r.contact)}</div>` : ""}
        ${r.by === S.uid || isAdmin() ? `<button class="btn sm ghost" data-match="${esc(r._id)}" style="align-self:flex-start">Mark fulfilled</button>` : ""}</div>`; };
    return `<div class="stack-lg"><div class="banner info small">Connects surplus with urgent needs. Coordinate handovers directly; CivicPulse doesn't handle deliveries or money. Prefer verified organisations.</div>
      ${matches.length ? `<div class="card stack"><h3>Possible matches</h3>${matches.map((m) => `<div class="small">${esc(RES_KINDS[m.n.item])} needed in ${esc(locName(m.n.locality))} ↔ ${m.offers.map((o) => `offer in ${esc(locName(o.locality))}`).join(", ")}</div>`).join("")}</div>` : ""}
      <div class="side"><div class="stack"><h3>Open listings</h3>${open.length ? open.map(row).join("") : empty("No open listings.")}</div>
      <div class="stack"><form class="card stack" id="rsForm"><h3>Post a listing</h3>
        <div class="seg" id="rsKind"><button type="button" data-v="need" class="on">We need</button><button type="button" data-v="offer">We can give</button></div>
        <label class="f">What<select class="input" id="rsItem">${Object.entries(RES_KINDS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></label>
        <label class="f">Quantity<input class="input" id="rsQty" maxlength="60" placeholder="e.g. 50 meals, 20 blankets"></label>
        <label class="f">Neighbourhood<select class="input" id="rsLoc">${LOC.map((l) => `<option value="${l.id}">${esc(l.name)}</option>`).join("")}</select></label>
        <label class="f">On behalf of<select class="input" id="rsNgo"><option value="">Myself</option>${S.ngos.filter((n) => n.createdBy === S.uid || isAdmin()).map((n) => `<option value="${esc(n._id)}">${esc(n.name)}</option>`).join("")}</select></label>
        <label class="f">Public contact <span class="hint">shown to everyone; an organisation number is best</span><input class="input" id="rsContact" maxlength="80"></label>
        <label class="f">Note<input class="input" id="rsNote" maxlength="200"></label>
        <label class="check"><input type="checkbox" id="rsUrg">Urgent</label>
        <button class="btn primary" style="align-self:flex-start">Post</button></form>
      <form class="card stack" id="ngoForm"><h3>Register an organisation</h3><label class="f">Name *<input class="input" id="ngName" maxlength="100" required></label><label class="f">Focus<input class="input" id="ngFocus" maxlength="100" placeholder="e.g. food relief, shelter"></label><label class="f">Registration ID <span class="hint">e.g. NGO Darpan ID; an administrator checks it</span><input class="input" id="ngReg" maxlength="60"></label><button class="btn" style="align-self:flex-start">Submit for verification</button></form></div></div></div>`;
  },
  verify() {
    const myLoc = S.profiles.get(S.uid)?.locality;
    const list = allC().filter((c) => !isMine(c) && (c.needsCommunity || c.status === "awaiting") && isOpen(c) && (!myLoc || c.locality === myLoc)).sort((a, b) => scores(b).priority - scores(a).priority);
    return `<div class="card stack"><p class="small muted">High-priority problems and repairs waiting for confirmation${myLoc ? ` in ${esc(locName(myLoc))}` : " across the city (set your neighbourhood in My reports to narrow this)"}. Open one to add an independent check.</p>
      ${list.length ? `<div class="clist">${list.map((c) => citem(c, `<span>${(c.community || []).length} checks</span>`)).join("")}</div>` : empty("Nothing needs verifying right now.")}</div>`;
  },
};
const COM_BIND = {
  volunteer() {
    $("#evForm").onsubmit = (e) => { e.preventDefault(); busy(e.target.querySelector("button"), async () => {
      if (!guardWrite()) return; const date = new Date($("#evDate").value).getTime(); if (!date) { toast("Choose a date."); return; }
      await write(() => S.db.collection("events").add({ title: $("#evTitle").value.trim(), type: $("#evType").value, locality: $("#evLoc").value, date, desc: $("#evDesc").value.trim(), createdBy: S.uid, participants: [], at: now() }));
      toast("Initiative published.");
    }); };
    $$("[data-join]").forEach((b) => b.onclick = () => busy(b, async () => {
      if (!guardWrite()) return; const e = S.events.find((x) => x._id === b.dataset.join); const ps = e.participants || [];
      const next = ps.some((p) => p.uid === S.uid) ? ps.filter((p) => p.uid !== S.uid) : [...ps, { uid: S.uid, at: now(), attended: false, hours: 0 }];
      await write(() => S.db.collection("events").doc(e._id).update({ participants: next }));
    }));
    $$("[data-att]").forEach((b) => b.onclick = () => { const e = S.events.find((x) => x._id === b.dataset.att);
      modal(`<h3>Attendance · ${esc(e.title)}</h3><p class="small muted">Only mark people you saw take part. Certificates are issued from this record.</p><div class="stack">${(e.participants || []).map((p, i) => `<div class="row between"><label class="check"><input type="checkbox" data-pa="${i}" ${p.attended ? "checked" : ""}>${esc(nameOf(p.uid))}</label><label class="row small">Hours <input class="input num" type="number" min="0" max="24" step="0.5" data-ph="${i}" value="${p.hours || 2}" style="width:80px"></label></div>`).join("")}</div><div class="row" style="justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="attSave">Save</button></div>`,
        (m, close) => { $("#attSave", m).onclick = (ev) => busy(ev.currentTarget, async () => { const ps = e.participants.map((p, i) => ({ ...p, attended: $(`[data-pa="${i}"]`, m).checked, hours: +$(`[data-ph="${i}"]`, m).value || 0 })); await write(() => S.db.collection("events").doc(e._id).update({ participants: ps })); close(); toast("Attendance saved."); }); }); });
    $$("[data-cert]").forEach((b) => b.onclick = () => { const e = S.events.find((x) => x._id === b.dataset.cert); const p = e.participants.find((x) => x.uid === S.uid);
      modal(`<div class="cert stack">${LOGO}<div class="eyebrow">Certificate of civic participation</div><h2>${esc(nameOf(S.uid))}</h2><p>took part in <strong>${esc(e.title)}</strong>, ${esc(EV_TYPES[e.type] || "")}, in ${esc(locName(e.locality))} on ${fmtDate(e.date)}, contributing <strong>${p.hours} hour${p.hours === 1 ? "" : "s"}</strong>.</p><p class="tiny muted">Attendance recorded by the organiser on CivicPulse · ref ${esc(e._id.slice(0, 8))}-${esc((S.uid || "").slice(0, 6))}</p></div><div class="row" style="justify-content:flex-end"><button class="btn" data-close>Close</button></div>`); });
  },
  resources() {
    let kind = "need"; $$("#rsKind button").forEach((b) => b.onclick = () => { kind = b.dataset.v; $$("#rsKind button").forEach((x) => x.classList.toggle("on", x === b)); });
    $("#rsForm").onsubmit = (e) => { e.preventDefault(); busy(e.target.querySelector("button"), async () => {
      if (!guardWrite()) return;
      await write(() => S.db.collection("resources").add({ kind, item: $("#rsItem").value, qty: $("#rsQty").value.trim(), locality: $("#rsLoc").value, ngoId: $("#rsNgo").value || null, contact: $("#rsContact").value.trim(), note: $("#rsNote").value.trim(), urgent: $("#rsUrg").checked, status: "open", by: S.uid, at: now() }));
      toast("Listing posted.");
    }); };
    $("#ngoForm").onsubmit = (e) => { e.preventDefault(); busy(e.target.querySelector("button"), async () => {
      if (!guardWrite()) return; await write(() => S.db.collection("ngos").add({ name: $("#ngName").value.trim(), focus: $("#ngFocus").value.trim(), regId: $("#ngReg").value.trim(), createdBy: S.uid, at: now() })); toast("Submitted. An administrator will verify it.");
    }); };
    $$("[data-match]").forEach((b) => b.onclick = () => busy(b, () => write(() => S.db.collection("resources").doc(b.dataset.match).update({ status: "matched", matchedAt: now() }))));
  },
};

/* ---------- accessibility navigator ---------- */
const AX = { mode: "view", a: null, b: null, kind: "ramp" };
VIEWS.access = {
  html() {
    const pts = S.access; const verified = pts.filter(axVerified);
    return `<div class="wrap section stack-lg"><div><div class="eyebrow">Accessibility navigator</div><h2 style="margin-top:6px">Step-free routes, ramps and obstacles</h2>
      <p class="small muted" style="margin-top:6px;max-width:70ch">Points are added by residents and count as verified once at least two other people confirm them. Use the route check to see what's along a straight-line path between two places.</p></div>
      <div class="card tight row" data-live><div class="seg" id="axMode">${[["view", "Browse"], ["add", "Add a point"], ["route", "Check a route"]].map(([k, l]) => `<button type="button" data-v="${k}" class="${AX.mode === k ? "on" : ""}">${l}</button>`).join("")}</div>
        <select class="input ${AX.mode === "add" ? "" : "hidden"}" id="axKind" style="width:auto">${Object.entries(ACCESS_KINDS).map(([k, [l]]) => `<option value="${k}" ${AX.kind === k ? "selected" : ""}>${l}</option>`).join("")}</select>
        <span class="small muted" id="axHint">${AX.mode === "add" ? "Tap the map where the feature is." : AX.mode === "route" ? (AX.a ? "Now tap your destination." : "Tap your starting point.") : `${verified.length} verified of ${pts.length} points`}</span></div>
      <div class="map tall" id="axMap"></div>
      <div class="legend">${Object.entries(ACCESS_KINDS).map(([k, [l, c]]) => `<span><i style="background:${c}"></i>${l}</span>`).join("")}<span><i style="background:transparent;border:2px dashed var(--muted)"></i>Unverified</span></div>
      <div id="axRoute"></div></div>`;
  },
  after() {
    const map = makeMap($("#axMap"), { onClick: axClick }); if (!map) return; const layer = L.layerGroup().addTo(map);
    function draw() {
      layer.clearLayers();
      for (const p of S.access) {
        const v = axVerified(p); const [lab, col] = ACCESS_KINDS[p.kind] || ["Point", "#666"];
        const mk = L.circleMarker([p.lat, p.lng], { radius: 8, color: v ? cssVar("--card") : col, weight: 2, dashArray: v ? null : "3 3", fillColor: col, fillOpacity: v ? 0.95 : 0.35 });
        mk.bindPopup(`<strong>${esc(lab)}</strong> ${sampleTag(p)}<br>${esc(p.note || "")}<br><span class="muted">${(p.confirms || []).length} confirm · ${(p.disputes || []).length} dispute · ${v ? "verified" : "not yet verified"}</span>${p.kind === "obstacle" && p.cleared ? "<br>Reported cleared" : ""}<br>
          ${S.uid ? `<button class="btn sm" data-axc="${esc(p._id)}">Confirm</button> <button class="btn sm ghost" data-axd="${esc(p._id)}">It's not there</button>` : ""}`);
        mk.on("popupopen", (e) => { const el = e.popup.getElement(); el.querySelector("[data-axc]")?.addEventListener("click", () => axVote(p, "confirms")); el.querySelector("[data-axd]")?.addEventListener("click", () => axVote(p, "disputes")); });
        layer.addLayer(mk);
      }
      if (AX.a) layer.addLayer(L.circleMarker(AX.a, { radius: 7, color: cssVar("--ink"), fillColor: cssVar("--ink"), fillOpacity: 1 }));
      if (AX.a && AX.b) { layer.addLayer(L.polyline([AX.a, AX.b], { color: cssVar("--primary"), weight: 4, dashArray: "8 6" })); layer.addLayer(L.circleMarker(AX.b, { radius: 7, color: cssVar("--primary"), fillColor: cssVar("--primary"), fillOpacity: 1 })); }
    }
    VIEWS.access._draw = draw; draw(); axRouteReport();
    $$("#axMode button").forEach((b) => b.onclick = () => { AX.mode = b.dataset.v; if (AX.mode === "route") { AX.a = AX.b = null; } render(true); });
    const k = $("#axKind"); if (k) k.onchange = () => (AX.kind = k.value);
  },
  refresh() { VIEWS.access._draw && VIEWS.access._draw(); axRouteReport(); },
};
const axVerified = (p) => (p.confirms || []).length >= 2 && (p.confirms || []).length > (p.disputes || []).length;
async function axVote(p, field) {
  if (!guardWrite()) return; const k = await myKey(p._id, "ax:"); if (p.byKey === k) { toast("You added this point; others need to confirm it."); return; }
  const other = field === "confirms" ? "disputes" : "confirms";
  try { await write(() => S.db.collection("access").doc(p._id).update({ [field]: [...new Set([...(p[field] || []), k])], [other]: (p[other] || []).filter((x) => x !== k) })); toast("Thanks."); } catch (e) { toast(dbErr(e)); }
}
function axClick(ll) {
  if (AX.mode === "add") {
    if (!guardWrite()) return;
    modal(`<h3>Add ${esc(ACCESS_KINDS[AX.kind][0].toLowerCase())}</h3><label class="f">Describe it<input class="input" id="axNote" maxlength="200" placeholder="e.g. Ramp at the metro exit, gentle slope"></label><div class="row" style="justify-content:flex-end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="axSave">Add point</button></div>`,
      (m, close) => { $("#axSave", m).onclick = (e) => busy(e.currentTarget, async () => { const id = "AX-" + uidGen(6); const byKey = await myKey(id, "ax:");
        await write(() => S.db.collection("access").doc(id).set({ kind: AX.kind, lat: +ll.lat.toFixed(6), lng: +ll.lng.toFixed(6), locality: nearestLocality(ll.lat, ll.lng).id, note: $("#axNote", m).value.trim(), confirms: [], disputes: [], byKey, at: now() })); close(); toast("Point added. It shows as verified after two confirmations."); }); });
  } else if (AX.mode === "route") {
    if (!AX.a || AX.b) { AX.a = [ll.lat, ll.lng]; AX.b = null; } else AX.b = [ll.lat, ll.lng];
    $("#axHint").textContent = AX.b ? "Route checked. Tap to start again." : "Now tap your destination.";
    VIEWS.access._draw(); axRouteReport();
  }
}
function segDist(p, a, b) {
  const kx = 111320 * Math.cos((a[0] * Math.PI) / 180), ky = 110540;
  const ax = 0, ay = 0, bx = (b[1] - a[1]) * kx, by = (b[0] - a[0]) * ky, px = (p[1] - a[1]) * kx, py = (p[0] - a[0]) * ky;
  const l2 = bx * bx + by * by; const tt = l2 ? clamp((px * bx + py * by) / l2, 0, 1) : 0; return Math.hypot(px - tt * bx, py - tt * by);
}
function axRouteReport() {
  const box = $("#axRoute"); if (!box) return; if (!AX.a || !AX.b) { box.innerHTML = ""; return; }
  const len = E.distance(AX.a[0], AX.a[1], AX.b[0], AX.b[1]);
  const near = S.access.map((p) => ({ p, d: segDist([p.lat, p.lng], AX.a, AX.b) })).filter((x) => x.d < 80);
  const obs = near.filter((x) => x.p.kind === "obstacle" && !x.p.cleared), good = near.filter((x) => x.p.kind !== "obstacle" && axVerified(x.p));
  const issues = allC().filter((c) => isOpen(c) && ["accessibility", "pedestrian", "open_manhole", "pothole", "fallen_tree", "flooding"].includes(c.cat) && segDist([c.lat, c.lng], AX.a, AX.b) < 60);
  box.innerHTML = `<div class="card stack"><div class="row between"><h3>Route check · ${(len / 1000).toFixed(2)} km straight line</h3><span class="pill ${obs.length || issues.length ? "t-red" : "t-green"}">${obs.length || issues.length ? `${obs.length + issues.length} barrier${obs.length + issues.length > 1 ? "s" : ""} on the way` : "No known barriers"}</span></div>
    <p class="small muted">Checks reported obstacles and open complaints within 60–80 m of the straight line. Without street data this can't plan turn-by-turn routes; use it to spot known barriers.</p>
    ${obs.map((x) => `<div class="small">• Obstacle: ${esc(x.p.note || "footpath obstacle")} (${axVerified(x.p) ? "verified" : "unverified"})</div>`).join("")}
    ${issues.map((c) => `<div class="small">• Open complaint: <a href="#complaint-${esc(c._id)}">${esc(c.title)}</a></div>`).join("")}
    ${good.length ? `<div class="small muted">Verified accessible features nearby: ${good.map((x) => esc(ACCESS_KINDS[x.p.kind][0])).join(", ")}</div>` : ""}</div>`;
}

/* ---------- Civic SOS ---------- */
const SOSD = { cat: null, locality: "", lat: null, lng: null };
VIEWS.sos = {
  html() {
    const active = allC().filter((c) => c.sos && isOpen(c)).sort((a, b) => b.createdAt - a.createdAt);
    return `<div class="wrap section stack-lg">
      <div class="banner danger">${icon("alert")}<div><strong>CivicPulse does not replace emergency services.</strong> If anyone is hurt or in immediate danger, call <strong>112</strong>. For live electrical hazards also call BESCOM on <strong>1912</strong>.</div></div>
      <div><div class="eyebrow">Civic SOS</div><h2 style="margin-top:6px">Report a dangerous hazard in one tap</h2><p class="small muted" style="margin-top:6px">Creates a top-priority complaint for the right department and alerts residents of that neighbourhood.</p></div>
      <div class="sos-grid">${SOS_TYPES.map((s) => `<button class="sos-btn ${SOSD.cat === s.cat ? "on" : ""}" data-sos="${s.cat}">${icon(s.icon, 30)}${esc(L2(s))}</button>`).join("")}</div>
      <div class="card stack" data-live><h3>Where is it?</h3>
        <div class="grid g2"><select class="input" id="sosLoc"><option value="">Choose neighbourhood</option>${LOC.map((l) => `<option value="${l.id}" ${SOSD.locality === l.id ? "selected" : ""}>${esc(L2({ en: l.name, kn: l.kn }))}</option>`).join("")}</select>
        <button class="btn" id="sosGps">${icon("pin", 16)}Use my location</button></div>
        <p class="small muted" id="sosHint">${SOSD.lat ? "Pinned. Tap the map to adjust." : "Pick a neighbourhood or tap the map for the exact spot."}</p>
        <div class="map short" id="sosMap"></div>
        <input class="input" id="sosNote" maxlength="200" placeholder="Optional: landmark or detail">
        <button class="btn danger lg" id="sosSend" ${SOSD.cat ? "" : "disabled"}>Send hazard report</button></div>
      <div class="card stack"><h3>Active hazards</h3>${active.length ? `<div class="clist">${active.map((c) => citem(c)).join("")}</div>` : '<p class="small muted">No active hazards reported.</p>'}</div></div>`;
  },
  after() {
    let pin = null;
    const map = makeMap($("#sosMap"), { center: SOSD.lat ? [SOSD.lat, SOSD.lng] : undefined, zoom: SOSD.lat ? 15 : 11.5, onClick: (ll) => setP(ll.lat, ll.lng) });
    function setP(lat, lng, pan) { SOSD.lat = lat; SOSD.lng = lng; SOSD.locality = nearestLocality(lat, lng).id; $("#sosLoc").value = SOSD.locality; $("#sosHint").textContent = `Pinned in ${locName(SOSD.locality)}.`;
      if (map) { pin ? pin.setLatLng([lat, lng]) : (pin = L.circleMarker([lat, lng], { radius: 9, color: cssVar("--card"), weight: 2, fillColor: cssVar("--red"), fillOpacity: 1 }).addTo(map)); if (pan) map.setView([lat, lng], 16); } }
    if (SOSD.lat) setP(SOSD.lat, SOSD.lng);
    $$("[data-sos]").forEach((b) => b.onclick = () => { SOSD.cat = b.dataset.sos; $$("[data-sos]").forEach((x) => x.classList.toggle("on", x === b)); $("#sosSend").disabled = false; });
    $("#sosLoc").onchange = (e) => { const l = locOf(e.target.value); if (l) { SOSD.locality = l.id; if (!SOSD.lat || nearestLocality(SOSD.lat, SOSD.lng).id !== l.id) setP(l.lat, l.lng, true); } };
    $("#sosGps").onclick = () => navigator.geolocation ? navigator.geolocation.getCurrentPosition((p) => setP(p.coords.latitude, p.coords.longitude, true), () => ($("#sosHint").textContent = "This page can't read your device location. Pick the neighbourhood or tap the map."), { timeout: 8000 }) : null;
    $("#sosSend").onclick = (e) => busy(e.currentTarget, async () => {
      if (!guardWrite()) return; if (!SOSD.cat) return toast("Choose the hazard type.");
      if (!SOSD.lat) { toast("Pick a neighbourhood or tap the map."); return; }
      const s = SOS_TYPES.find((x) => x.cat === SOSD.cat); const note = $("#sosNote").value.trim();
      DRAFT = { ...blankDraft(), title: s.en + (note ? " · " + note.slice(0, 60) : ""), desc: `Civic SOS hazard report: ${s.en}.${note ? " " + note : ""}`, cat: s.cat, sev: 5, vulnerable: 8 | 16, popBand: 2, locSens: 3, lat: SOSD.lat, lng: SOSD.lng, locality: SOSD.locality, landmark: note, sos: true, source: "sos" };
      await submitReportDirect(); Object.assign(SOSD, { cat: null, lat: null, lng: null });
    }, "Sending…");
  },
};
async function submitReportDirect() { await submitReport(); }

/* ---------- public money transparency ---------- */
VIEWS.transparency = {
  html() {
    const ps = [...S.projects].sort((a, b) => (b.at || 0) - (a.at || 0));
    return `<div class="wrap section stack-lg"><div><div class="eyebrow">Public money transparency</div><h2 style="margin-top:6px">Infrastructure projects and what residents report</h2>
      <p class="small muted" style="margin-top:6px;max-width:70ch">Only projects with a published, linked source are listed. CivicPulse never estimates or invents budget figures. Each project shows open complaints in the same neighbourhood and department so residents can compare spending with conditions on the ground.</p></div>
      ${ps.length ? `<div class="grid g2">${ps.map((p) => { const rel = allC().filter((c) => c.dept === p.dept && (!p.locality || c.locality === p.locality) && isOpen(c));
        return `<div class="card stack"><div class="row between"><h3>${esc(p.name)}</h3><span class="pill plain ${p.status === "Stalled" ? "t-red" : p.status === "Completed" ? "t-green" : "t-blue"}">${esc(p.status)}</span></div>
          <div class="small muted">${esc(deptOf(p.dept).name)} · ${p.locality ? esc(locName(p.locality)) : "City-wide"}</div>
          <dl class="kv"><dt>Published budget</dt><dd class="num">₹${Number(p.budget).toLocaleString("en-IN")} lakh</dd><dt>Spent to date</dt><dd class="num">${p.spent == null ? "Not published" : `₹${Number(p.spent).toLocaleString("en-IN")} lakh`}</dd>
          <dt>Timeline</dt><dd>${p.start ? esc(p.start) : "—"} → ${p.due ? esc(p.due) : "—"}${p.due && p.status !== "Completed" && new Date(p.due).getTime() < now() ? ' <span class="pill plain t-red">Past target date</span>' : ""}</dd><dt>Source</dt><dd><a href="${esc(p.sourceUrl)}" target="_blank" rel="noopener">${esc(p.sourceName)}</a></dd></dl>
          ${p.spent != null && p.budget ? `<div class="bar-h"><span style="width:${clamp((p.spent / p.budget) * 100, 0, 100)}%"></span></div>` : ""}
          <div class="small"><strong>${rel.length}</strong> open related complaint${rel.length === 1 ? "" : "s"}${rel.length ? ": " + rel.slice(0, 3).map((c) => `<a href="#complaint-${esc(c._id)}">${esc(cid(c))}</a>`).join(", ") : ""}</div></div>`; }).join("")}</div>`
      : `<div class="card stack" style="max-width:640px"><h3>No verified project data published yet</h3><p class="small muted">Budgets and expenditure must come from official public records such as municipal budget books, tender portals or RTI responses. An administrator can add them from Admin → Public projects with a source link for each figure.</p>${isAdmin() ? '<a class="btn primary" href="#admin" id="toProj" style="align-self:flex-start">Add a project</a>' : ""}</div>`}</div>`;
  },
  after() { const b = $("#toProj"); if (b) b.onclick = () => (AF.tab = "projects"); },
};

/* ---------- about / methodology ---------- */
VIEWS.about = {
  html() {
    return `<div class="wrap section stack-lg" style="max-width:880px">
      <div><div class="eyebrow">Methodology</div><h2 style="margin-top:6px">How CivicPulse works</h2></div>
      <div class="card stack"><h3>Citizen-verified resolution</h3><p class="small">A department can never close a complaint by marking it resolved. After uploading after-repair photos and a description, the status becomes <em>Awaiting citizen verification</em> and the original reporter is notified. Only the reporter can choose <strong>Yes, fixed</strong> (closes it, with the date recorded) or <strong>No, not fixed</strong> (reopens it with their reason and photos; earlier repair records are kept). If the reporter doesn't respond by the administrator's deadline, the complaint is either kept waiting or closed as "not verified by citizen", depending on the setting. It is never counted as citizen-confirmed.</p>
        <p class="small">Anonymous reporters keep this power: the complaint stores only a one-way key derived from the reporter's account and the complaint ID, so the reporter's device can prove ownership without the name being stored.</p></div>
      <div class="card stack"><h3>Priority and severity (C engine)</h3><p class="small">Severity (1–5) = category base risk, plus hazards (exposed electricity +1.5, open pit +1, flooding +0.8, traffic or health +0.3 each), plus support (3+ people +0.5, 10+ +1), blended 70/30 with the reporter's own estimate.</p>
        <p class="small">Priority (0–100) = severity × 9, + 4 per vulnerable group affected (+3 more if emergency access is blocked), + 3 × population band, + 3 × location sensitivity, + 0.2 per day waiting (max 30 days), + 0.25 per supporter (max 20), + 2 per failed repair (max 3).</p>
        <p class="small">These run in C compiled to WebAssembly in your browser. Engine in use right now: <strong>${esc(E.kind)}</strong>.</p>
        <details class="method"><summary>View the C source</summary><pre class="code">${esc(C_SOURCE)}</pre></details></div>
      <div class="card stack"><h3>Duplicate detection</h3><p class="small">When you pin a location, the C engine finds reports within ${cfg().dupRadius || 75}–${Math.round((cfg().dupRadius || 75) * 1.4)} m. Each is scored on distance (45%), wording overlap (25%), same category (20%) and photo similarity from a 64-bit perceptual hash (10%). You choose whether to link; every individual report is kept and counts as support.</p></div>
      <div class="card stack"><h3>AI features</h3><p class="small">Photo classification, text classification and before/after repair comparison use Claude through this page, on the viewer's own Claude account, and ask for permission the first time. They only suggest; a person always makes the decision. If AI isn't available, keyword matching suggests a category instead. Civic Health Scores, predictions and repeat-location detection are transparent statistical rules, shown in full on the Insights page.</p></div>
      <div class="card stack"><h3>Roles</h3><p class="small"><strong>Citizens</strong> report, support, verify and volunteer. <strong>Officials</strong> see their department's queue and move complaints through review, assignment, work and repair evidence. <strong>Administrators</strong> manage people, departments, categories, settings, published projects, rain alerts and NGO verification. Sign-in uses your claude.ai account. Configuration, roles and published projects can only be changed by the owner and Editors; this is enforced by the data store.</p></div>
      <div class="card stack"><h3>What isn't connected</h3><ul class="small" style="margin:0;padding-left:18px">
        <li>No official government system is connected. Departments are working names; complaints are not forwarded to BBMP, BWSSB or BESCOM.</li>
        <li>Street map tiles can't load in this host, so the map shows a schematic of neighbourhood boundaries (approximate).</li>
        <li>Device GPS is usually blocked inside this page; pin locations on the map.</li>
        <li>Weather data isn't fetched automatically. Administrators enter official rain warnings.</li>
        <li>Notifications are in-app only. Email, SMS and push need a messaging service.</li>
        <li>Voice input and read-aloud depend on your browser and app; on phones they may be unavailable.</li>
        <li>Department-level permissions (an official acting only on their own department) are enforced by the app, not by the data store.</li></ul></div>
      ${footer()}</div>`;
  },
};

/* ---------- boot ---------- */
async function boot() {
  document.documentElement.lang = S.lang;
  render(true);
  await initEngine();
  if (!window.claude || !claude.use) { S.started = true; render(true); return; }
  const [db, user] = await Promise.all([claude.use("db"), claude.use("user")]);
  S.db = db; S.user = user; S.started = true;
  if (user) { try { S.isOwner = !!(await user.isOwner()); } catch {} try { S.uid = await user.id(); } catch {} try { const cw = await user.can("data.write"); S.canWrite = cw; if (cw === false) S.readOnly = true; } catch {} }
  if (!S.isOwner) { S.preview = null; }
  if (S.db) startData(); else render(true);
  claude.use("assets").then((a) => (S.assets = a)).catch(() => {});
  claude.use("sample").then(async (s) => { S.sample = s; if (s) { try { const l = await s.limits(); S.sampleImages = !!l.images; } catch {} } render(); }).catch(() => {});
  claude.use("dictation").then((d) => { S.dictation = d; if (route().name === "report") render(true); }).catch(() => {});
  claude.use("tts").then((x) => (S.tts = x)).catch(() => {});
}
boot();

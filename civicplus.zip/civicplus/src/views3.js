/* ============ Dashboards: citizen, department, administrator ============ */
const MYF = { tab: "all" };
VIEWS.my = {
  html() {
    if (!S.uid) return `<div class="wrap section">${empty("Sign in to claude.ai to see your reports.")}</div>`;
    const mine = allC().filter(isMine).sort((a, b) => b.createdAt - a.createdAt);
    const awaiting = mine.filter((c) => c.status === "awaiting");
    const prof = S.profiles.get(S.uid) || {};
    const groups = { all: mine, pending: mine.filter((c) => ["submitted", "review"].includes(c.status)), ongoing: mine.filter((c) => ["assigned", "progress", "awaiting"].includes(c.status)), resolved: mine.filter((c) => c.status === "confirmed"), reopened: mine.filter((c) => (c.reopenCount || 0) > 0) };
    const notes = notifications().slice(0, 6);
    const hazards = prof.locality ? allC().filter((c) => c.sos && isOpen(c) && c.locality === prof.locality) : [];
    return `<div class="wrap section stack-lg">
      <div class="row between"><div><div class="eyebrow">Citizen dashboard</div><h2 style="margin-top:6px">${esc(t("my"))}</h2></div><a class="btn primary" href="#report">${icon("plus", 18)}${esc(t("reportBtn"))}</a></div>
      <div class="grid g4">${tile(t("total"), groups.all.length, "accent")}${tile(t("pending"), groups.pending.length, "amber")}${tile(t("ongoing"), groups.ongoing.length, "blue")}${tile(t("resolved"), groups.resolved.length, "accent")}${tile(t("reopened"), groups.reopened.length, "red")}</div>
      ${awaiting.length ? `<div class="banner warn">${icon("alert")}<div><strong>${awaiting.length} repair${awaiting.length > 1 ? "s need" : " needs"} your confirmation.</strong> ${awaiting.map((c) => `<a href="#complaint-${esc(c._id)}">${esc(cid(c))}</a>`).join(", ")}</div></div>` : ""}
      ${hazards.length ? `<div class="banner danger">${icon("alert")}<div><strong>Hazards near you:</strong> ${hazards.map((c) => `<a href="#complaint-${esc(c._id)}">${esc(L2(catOf(c.cat)))}</a>`).join(", ")}</div></div>` : ""}
      <div class="side">
        <div class="card stack"><div class="tabs" data-live id="myTabs">${Object.keys(groups).map((k) => `<button data-k="${k}" class="${MYF.tab === k ? "on" : ""}">${esc(t(k))} <span class="muted num">${groups[k].length}</span></button>`).join("")}</div>
          ${groups[MYF.tab].length ? `<div class="clist">${groups[MYF.tab].map((c) => citem(c)).join("")}</div>` : empty(mine.length ? "Nothing in this group." : "You haven't reported anything yet. <a href='#report'>Report an issue</a>.")}</div>
        <div class="stack">
          <div class="card stack"><div class="row between"><h3>Recent notifications</h3><a href="#notif" class="small">All</a></div>${notes.length ? notes.map(notifRow).join("") : '<p class="small muted">No notifications yet.</p>'}</div>
          <div class="card stack" data-live><h3>My neighbourhood</h3><p class="small muted">Used for nearby hazard alerts and community verification requests.</p>
            <select class="input" id="myLoc"><option value="">Choose…</option>${LOC.map((l) => `<option value="${l.id}" ${prof.locality === l.id ? "selected" : ""}>${esc(L2({ en: l.name, kn: l.kn }))}</option>`).join("")}</select></div>
        </div>
      </div></div>`;
  },
  after() {
    $$("#myTabs button").forEach((b) => b.onclick = () => { MYF.tab = b.dataset.k; render(true); });
    const ml = $("#myLoc"); if (ml) ml.onchange = () => { if (!guardWrite()) return; write(() => S.db.collection("profiles").doc(S.uid).set({ joined: (S.profiles.get(S.uid) || {}).joined || now(), locality: ml.value || null, lang: S.lang })).then(() => toast("Neighbourhood saved.")).catch((e) => toast(dbErr(e))); };
  },
};
function notifRow(n) { const unread = n.at > ((S.priv && S.priv.lastSeen) || 0); return `<a class="citem" href="#complaint-${esc(n.c._id)}" style="grid-template-columns:4px 1fr auto"><span class="stripe ${unread ? "s4" : ""}"></span><div><div class="small ${unread ? "ttl" : ""}">${esc(notifText(n))}</div>${n.e.note && n.e.type !== "submitted" ? `<div class="tiny muted">${esc(String(n.e.note).slice(0, 120))}</div>` : ""}</div><span class="tiny muted">${ago(n.at)}</span></a>`; }
VIEWS.notif = {
  html() {
    const ns = notifications();
    return `<div class="wrap section stack"><div class="row between"><h2>${esc(t("notif"))}</h2><span class="small muted">Updates on your complaints${isStaff() ? ", your department's queue" : ""} and hazards near you</span></div>
      <div class="card" style="padding:4px 16px">${ns.length ? `<div class="clist">${ns.map(notifRow).join("")}</div>` : empty("You're all caught up.")}</div>
      <p class="tiny muted">Notifications appear here and on the bell in real time. Email, SMS and push delivery would need an external messaging service, which isn't connected.</p></div>`;
  },
  after() { setTimeout(() => savePriv({ lastSeen: now() }), 1500); },
};

/* ---------- government department dashboard ---------- */
const GF = { dept: null, tab: "new" };
VIEWS.gov = {
  html() {
    if (!isStaff()) return `<div class="wrap section">${empty("The department dashboard is for government officials. An administrator assigns this role.")}</div>`;
    const r = role(); const dept = isAdmin() ? GF.dept : r.dept;
    if (!dept && !isAdmin()) return `<div class="wrap section">${empty("No department is assigned to your account yet. Ask an administrator.")}</div>`;
    const list = allC().filter((c) => !dept || c.dept === dept);
    const st = deptStats(dept);
    const tabs = {
      new: list.filter((c) => ["submitted", "review"].includes(c.status)), active: list.filter((c) => ["assigned", "progress"].includes(c.status)),
      awaiting: list.filter((c) => c.status === "awaiting"), reopened: list.filter((c) => c.status === "reopened"),
      escalated: list.filter((c) => isOpen(c) && c.escalated > 0), closed: list.filter((c) => CLOSED.includes(c.status)),
    };
    const rows = tabs[GF.tab].sort((a, b) => scores(b).priority - scores(a).priority);
    return `<div class="wrap section stack-lg">
      <div class="row between"><div><div class="eyebrow">Government portal</div><h2 style="margin-top:6px">${esc(dept ? deptOf(dept).name : "All departments")}</h2></div>
        ${isAdmin() ? `<select class="input" id="gDept" data-live style="width:auto"><option value="">All departments</option>${cfg().departments.map((d) => `<option value="${esc(d.id)}" ${dept === d.id ? "selected" : ""}>${esc(d.name)}</option>`).join("")}</select>` : ""}</div>
      <div class="grid g4">${tile("New to review", tabs.new.length, "amber")}${tile("Work in progress", tabs.active.length, "blue")}${tile("Awaiting citizen", st.awaiting, "amber", "You can't close these")}${tile("Overdue", st.overdue, "red")}${tile("Reopened by citizens", tabs.reopened.length, "red")}${tile("Citizen-confirmed fixes", st.confirmed, "accent", st.avgDays != null ? `avg ${st.avgDays.toFixed(1)} days` : "")}</div>
      <div class="card stack"><div class="tabs" id="gTabs">${Object.entries({ new: "New", active: "Active", awaiting: "Awaiting citizen", reopened: "Reopened", escalated: "Escalated", closed: "Closed" }).map(([k, l]) => `<button data-k="${k}" class="${GF.tab === k ? "on" : ""}">${l} <span class="muted num">${tabs[k].length}</span></button>`).join("")}</div>
        ${rows.length ? `<div class="scroll-x"><table class="tbl"><thead><tr><th>Priority</th><th>Complaint</th><th>Where</th><th>Status</th><th>Due</th><th>Affected</th></tr></thead><tbody>
          ${rows.map((c) => `<tr><td>${prioPill(c)}</td><td><a href="#complaint-${esc(c._id)}"><strong>${esc(c.title)}</strong></a> ${sampleTag(c)}<div class="tiny muted num">${esc(cid(c))} · ${esc(L2(catOf(c.cat)))}${c.reopenCount ? ` · reopened ${c.reopenCount}×` : ""}</div></td><td class="small">${esc(locName(c.locality))}</td><td>${statusPill(c)}</td><td class="small num ${overdue(c) ? "" : "muted"}" style="${overdue(c) ? "color:var(--red);font-weight:600" : ""}">${isOpen(c) && c.dueAt ? fmtDate(c.dueAt) : "—"}</td><td class="num">${c.supportCount || 0}</td></tr>`).join("")}</tbody></table></div>` : empty("Nothing here.")}
      </div>
      <div class="grid g2"><div class="card stack"><h3>Received vs citizen-confirmed, last 6 months</h3><div style="height:230px"><canvas id="gChart"></canvas></div></div>
        <div class="card stack"><h3>Accountability</h3><dl class="kv">
          <dt>Average days to a confirmed fix</dt><dd class="num">${st.avgDays != null ? st.avgDays.toFixed(1) : "—"}</dd>
          <dt>Fixed first time</dt><dd class="num">${st.firstTimeRate != null ? Math.round(st.firstTimeRate * 100) + "%" : "—"}</dd>
          <dt>Repairs disputed by citizens</dt><dd class="num">${st.reopened}</dd>
          <dt>Closed without citizen response</dt><dd class="num">${st.lapsed}</dd>
          <dt>Currently escalated</dt><dd class="num">${st.escalated}</dd></dl>
          <p class="tiny muted">Overdue complaints escalate automatically to the department supervisor when a staff member opens CivicPulse.</p></div></div>
    </div>`;
  },
  after() {
    $$("#gTabs button").forEach((b) => b.onclick = () => { GF.tab = b.dataset.k; render(true); });
    const gd = $("#gDept"); if (gd) gd.onchange = () => { GF.dept = gd.value || null; render(true); };
    monthlyChart($("#gChart"), allC().filter((c) => !(isAdmin() ? GF.dept : role().dept) || c.dept === (isAdmin() ? GF.dept : role().dept)));
  },
};
const CHARTS = [];
function monthlyChart(canvas, list) {
  if (!canvas || typeof Chart === "undefined") return;
  const labels = [], rec = [], conf = []; const d = new Date(); d.setDate(1);
  for (let i = 5; i >= 0; i--) { const m = new Date(d.getFullYear(), d.getMonth() - i, 1), n = new Date(d.getFullYear(), d.getMonth() - i + 1, 1);
    labels.push(m.toLocaleString("en-IN", { month: "short" })); rec.push(list.filter((c) => c.createdAt >= m && c.createdAt < n).length); conf.push(list.filter((c) => c.status === "confirmed" && c.closedAt >= m && c.closedAt < n).length); }
  barChart(canvas, labels, [{ label: "Received", data: rec, color: cssVar("--map-line") }, { label: "Citizen-confirmed", data: conf, color: cssVar("--primary") }]);
}
function barChart(canvas, labels, sets, opts = {}) {
  const ink = cssVar("--muted"), grid = cssVar("--line");
  const ch = new Chart(canvas, { type: "bar", data: { labels, datasets: sets.map((s) => ({ label: s.label, data: s.data, backgroundColor: s.color, borderRadius: 4, maxBarThickness: 26 })) },
    options: { indexAxis: opts.horizontal ? "y" : "x", responsive: true, maintainAspectRatio: false, animation: { duration: 300 }, plugins: { legend: { labels: { color: ink, boxWidth: 10, font: { size: 12 } } } },
      scales: { x: { ticks: { color: ink }, grid: { color: opts.horizontal ? grid : "transparent" } }, y: { beginAtZero: true, ticks: { color: ink, precision: 0 }, grid: { color: opts.horizontal ? "transparent" : grid } } } } });
  CHARTS.push(ch);
}

/* ---------- administrator ---------- */
const AF = { tab: "overview" };
VIEWS.admin = {
  html() {
    if (!isAdmin()) return `<div class="wrap section">${empty("Administrator access only.")}</div>`;
    const T = { overview: "Overview", people: "People & roles", depts: "Departments", cats: "Categories", settings: "Settings", projects: "Public projects", alerts: "Rain alerts", ngos: "NGOs", audit: "Audit log" };
    return `<div class="wrap section stack-lg"><div><div class="eyebrow">Administrator</div><h2 style="margin-top:6px">Platform administration</h2></div>
      ${!S.config ? `<div class="banner warn"><div class="stack"><strong>The platform hasn't been set up yet.</strong><span class="small">Save the default departments, categories and service targets so officials and citizens share one configuration.</span><button class="btn primary sm" id="initCfg" style="align-self:flex-start">Save default configuration</button></div></div>` : ""}
      <div class="tabs" id="aTabs">${Object.entries(T).map(([k, l]) => `<button data-k="${k}" class="${AF.tab === k ? "on" : ""}">${l}</button>`).join("")}</div>
      <div id="aBody">${ADMIN[AF.tab]()}</div></div>`;
  },
  after() {
    $$("#aTabs button").forEach((b) => b.onclick = () => { AF.tab = b.dataset.k; render(true); });
    const ic = $("#initCfg"); if (ic) ic.onclick = () => busy(ic, async () => { await write(() => S.db.collection("config").doc("main").set(DEFAULT_CONFIG)); audit("config.init", "Default configuration saved"); });
    ADMIN_BIND[AF.tab] && ADMIN_BIND[AF.tab]();
  },
};
async function saveConfig(mut, what) { if (!guardWrite()) return; const c = JSON.parse(JSON.stringify(cfg())); delete c._id; mut(c); await write(() => S.db.collection("config").doc("main").set(c)); S.config = { ...c, _id: "main" }; audit("config", what); toast("Saved."); }
const ADMIN = {
  overview() {
    const st = deptStats(null); const esc_ = allC().filter((c) => isOpen(c) && c.escalated > 0).sort((a, b) => b.escalated - a.escalated);
    const disputes = allC().filter((c) => { const v = c.community || []; return (v.some((x) => x.verdict === "fixed") && v.some((x) => x.verdict === "not_fixed")) || (c.status === "confirmed" && v.some((x) => x.verdict === "not_fixed")); });
    return `<div class="stack-lg"><div class="grid g4">${tile("All complaints", st.total, "accent")}${tile("Open", st.open, "amber")}${tile("Overdue", st.overdue, "red")}${tile("Escalated", st.escalated, "red")}${tile("Citizen-confirmed", st.confirmed, "accent")}${tile("Closed unverified", st.lapsed, "amber")}${tile("People", S.profiles.size, "blue")}${tile("Officials", [...S.roles.values()].filter((r) => r.role !== "citizen").length, "blue")}</div>
      <div class="grid g2"><div class="card stack"><h3>Escalations</h3>${esc_.length ? `<div class="clist">${esc_.slice(0, 10).map((c) => citem(c, `<span>level ${c.escalated}</span>`)).join("")}</div>` : '<p class="small muted">No escalated complaints.</p>'}</div>
      <div class="card stack"><h3>Verification disagreements</h3>${disputes.length ? `<div class="clist">${disputes.map((c) => citem(c)).join("")}</div>` : '<p class="small muted">No conflicting verifications.</p>'}</div></div>
      <div class="card stack"><h3>Department comparison</h3><div style="height:${Math.max(220, cfg().departments.length * 34)}px"><canvas id="aChart"></canvas></div></div></div>`;
  },
  people() {
    const ids = [...new Set([...S.profiles.keys(), ...S.roles.keys()])];
    return `<div class="card stack"><p class="small muted">Everyone who has opened CivicPulse appears here. Assign the official role and a department to give someone the government portal. Administrators also need Editor access in this page's Share menu to change settings.</p>
      <div class="scroll-x"><table class="tbl"><thead><tr><th>Person</th><th>Joined</th><th>Role</th><th>Department</th><th></th></tr></thead><tbody>
      ${ids.map((id) => { const r = S.roles.get(id) || {}; const p = S.profiles.get(id) || {}; const owner = id === S.uid && S.isOwner;
        return `<tr><td><strong>${esc(nameOf(id) || "Unnamed")}</strong>${owner ? ' <span class="pill plain t-green">Owner</span>' : ""}<div class="tiny muted">${esc(p.locality ? locName(p.locality) : "")}</div></td><td class="small">${p.joined ? fmtDate(p.joined) : "—"}</td>
        <td>${owner ? "Administrator" : `<select class="input" data-role="${esc(id)}" style="width:auto">${["citizen", "official", "supervisor", "admin"].map((x) => `<option ${(r.role || "citizen") === x ? "selected" : ""}>${x}</option>`).join("")}</select>`}</td>
        <td>${owner ? "" : `<select class="input" data-dept="${esc(id)}" style="width:auto"><option value="">—</option>${cfg().departments.map((d) => `<option value="${esc(d.id)}" ${r.dept === d.id ? "selected" : ""}>${esc(d.name)}</option>`).join("")}</select>`}</td>
        <td>${owner ? "" : `<button class="btn sm" data-save="${esc(id)}">Save</button>`}</td></tr>`; }).join("") || `<tr><td colspan="5">${empty("Nobody else has opened the app yet. Share it from the Share menu with Contributor access.")}</td></tr>`}</tbody></table></div></div>`;
  },
  depts() {
    return `<div class="stack">${cfg().departments.map((d, i) => `<div class="card tight grid g3" style="align-items:end"><label class="f">Name<input class="input" data-dn="${i}" value="${esc(d.name)}" maxlength="80"></label><label class="f">Kannada name<input class="input" data-dk="${i}" value="${esc(d.kn || "")}" maxlength="80"></label><label class="f">Maintenance teams <span class="hint">comma separated</span><input class="input" data-dt="${i}" value="${esc((d.teams || []).join(", "))}"></label></div>`).join("")}
      <div class="row"><button class="btn primary" id="dSave">Save departments</button><button class="btn" id="dAdd">Add department</button></div></div>`;
  },
  cats() {
    return `<div class="card stack"><div class="scroll-x"><table class="tbl"><thead><tr><th>Category</th><th>Kannada</th><th>Department</th><th>Base risk 1–5</th></tr></thead><tbody>
      ${cfg().categories.map((c, i) => `<tr><td><input class="input" data-cn="${i}" value="${esc(c.en)}"></td><td><input class="input" data-ck="${i}" value="${esc(c.kn || "")}"></td><td><select class="input" data-cd="${i}">${cfg().departments.map((d) => `<option value="${esc(d.id)}" ${c.dept === d.id ? "selected" : ""}>${esc(d.name)}</option>`).join("")}</select></td><td><input class="input num" type="number" min="1" max="5" data-cr="${i}" value="${c.risk}" style="width:80px"></td></tr>`).join("")}</tbody></table></div>
      <div class="row"><button class="btn primary" id="cSave">Save categories</button><input class="input" id="cNew" placeholder="New category name" style="max-width:260px"><button class="btn" id="cAdd">Add</button></div></div>`;
  },
  settings() {
    const c = cfg();
    return `<div class="card stack" style="max-width:640px"><h3>Service targets (days to fix, by severity)</h3><div class="grid g4">${[1, 2, 3, 4, 5].map((s) => `<label class="f">Severity ${s}<input class="input num" type="number" min="1" max="90" id="sla${s}" value="${c.slaDays[s]}"></label>`).join("")}</div>
      <hr class="sep"><h3>Citizen verification</h3>
      <label class="f">Days the reporter has to respond<input class="input num" type="number" min="1" max="60" id="vDays" value="${c.verifyDays}"></label>
      <label class="f">When the deadline passes<select class="input" id="vLapse"><option value="close_unverified" ${c.lapseAction === "close_unverified" ? "selected" : ""}>Close as "not verified by citizen" (never counted as confirmed)</option><option value="keep_waiting" ${c.lapseAction === "keep_waiting" ? "selected" : ""}>Keep waiting; an administrator closes it manually</option></select></label>
      <hr class="sep"><h3>Community verification and duplicates</h3>
      <div class="grid g3"><label class="f">Request community checks from priority<input class="input num" type="number" min="0" max="100" id="cThr" value="${c.communityThreshold}"></label><label class="f">Independent confirmations wanted<input class="input num" type="number" min="1" max="10" id="cMin" value="${c.communityMin}"></label><label class="f">Duplicate search radius (m)<input class="input num" type="number" min="10" max="500" id="dRad" value="${c.dupRadius}"></label></div>
      <label class="f">Reports allowed per person per 10 minutes<input class="input num" type="number" min="1" max="50" id="rLim" value="${c.reportLimitPer10Min}"></label>
      <button class="btn primary" id="setSave" style="align-self:flex-start">Save settings</button></div>`;
  },
  projects() {
    return `<div class="stack-lg"><div class="banner info small">Only publish projects from a verifiable public source, such as a budget document, tender notice or government dashboard. A source link is required and is shown to the public.</div>
      <form class="card stack" id="pForm"><h3>Add a published project</h3><div class="grid g2">
        <label class="f">Project name *<input class="input" id="pName" required maxlength="140"></label>
        <label class="f">Department<select class="input" id="pDept">${cfg().departments.map((d) => `<option value="${esc(d.id)}">${esc(d.name)}</option>`).join("")}</select></label>
        <label class="f">Neighbourhood<select class="input" id="pLoc"><option value="">City-wide</option>${LOC.map((l) => `<option value="${l.id}">${esc(l.name)}</option>`).join("")}</select></label>
        <label class="f">Status<select class="input" id="pStatus"><option>Sanctioned</option><option>Tendered</option><option>In progress</option><option>Completed</option><option>Stalled</option></select></label>
        <label class="f">Published budget (₹ lakh) *<input class="input num" type="number" min="0" step="0.01" id="pBudget" required></label>
        <label class="f">Expenditure to date (₹ lakh) <span class="hint">leave blank if not published</span><input class="input num" type="number" min="0" step="0.01" id="pSpent"></label>
        <label class="f">Start date<input class="input" type="date" id="pStart"></label><label class="f">Target completion<input class="input" type="date" id="pDue"></label>
        <label class="f">Source link *<input class="input" type="url" id="pUrl" required placeholder="https://"></label><label class="f">Source name *<input class="input" id="pSrc" required maxlength="120" placeholder="e.g. BBMP Budget 2026–27, p. 41"></label></div>
        <button class="btn primary" style="align-self:flex-start">Publish project</button></form>
      <div class="card stack"><h3>Published projects</h3>${S.projects.length ? S.projects.map((p) => `<div class="row between"><span>${esc(p.name)} · <span class="muted small">${esc(p.sourceName)}</span></span><button class="btn sm ghost" data-delp="${esc(p._id)}">Remove</button></div>`).join("") : '<p class="small muted">None yet.</p>'}</div></div>`;
  },
  alerts() {
    return `<div class="stack-lg"><div class="banner info small">CivicPulse can't fetch weather data from here. Enter rain warnings from an official source (for example the IMD Bengaluru forecast or KSNDMC). They feed the Before-It-Happens risk alerts.</div>
      <form class="card stack" id="alForm"><div class="grid g2">
        <label class="f">Warning level<select class="input" id="alLevel"><option value="yellow">Yellow: heavy rain possible</option><option value="orange">Orange: very heavy rain</option><option value="red">Red: extremely heavy rain</option></select></label>
        <label class="f">Forecast rainfall (mm, 24 h)<input class="input num" type="number" min="0" id="alMm"></label>
        <label class="f">Valid until *<input class="input" type="datetime-local" id="alUntil" required></label>
        <label class="f">Source *<input class="input" id="alSrc" required maxlength="140" placeholder="e.g. IMD district forecast, 13 Nov"></label></div>
        <label class="f">Neighbourhoods <span class="hint">none selected = whole city</span><div class="chips" id="alLocs">${LOC.map((l) => `<button type="button" class="chipbtn" data-l="${l.id}">${esc(l.name)}</button>`).join("")}</div></label>
        <button class="btn primary" style="align-self:flex-start">Publish alert</button></form>
      <div class="card stack"><h3>Alerts</h3>${S.alerts.length ? S.alerts.sort((a, b) => b.at - a.at).map((a) => `<div class="row between small"><span><span class="pill plain ${a.level === "red" ? "t-red" : "t-amber"}">${esc(a.level)}</span> ${a.rainMm ? a.rainMm + " mm · " : ""}until ${fmtDate(a.until, true)} · ${esc(a.source)}${a.until < now() ? " · expired" : ""}</span><button class="btn sm ghost" data-dela="${esc(a._id)}">Remove</button></div>`).join("") : '<p class="small muted">No alerts.</p>'}</div></div>`;
  },
  ngos() {
    return `<div class="card stack"><p class="small muted">Verify organisations after checking their registration (for example their NGO Darpan ID or society registration). Only verified organisations get the verified badge.</p>
      ${S.ngos.length ? S.ngos.map((n) => `<div class="row between"><span><strong>${esc(n.name)}</strong> ${sampleTag(n)} <span class="small muted">${esc(n.focus || "")} · ${esc(n.regId || "no registration ID given")}</span></span><button class="btn sm ${ngoVerified(n) ? "" : "primary"}" data-ver="${esc(n._id)}">${ngoVerified(n) ? "Remove verification" : "Mark verified"}</button></div>`).join("") : '<p class="small muted">No organisations registered yet.</p>'}</div>`;
  },
  audit() {
    return `<div class="card stack"><p class="small muted">Administrative actions. Each complaint also keeps its own full timeline.</p><div class="scroll-x"><table class="tbl"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Detail</th></tr></thead><tbody>${S.audit.map((a) => `<tr><td class="small num">${fmtDate(a.at, true)}</td><td class="small">${esc(nameOf(a.by))} (${esc(a.role)})</td><td class="small">${esc(a.action)}</td><td class="small">${esc(a.detail)}</td></tr>`).join("") || `<tr><td colspan="4" class="muted small">No entries.</td></tr>`}</tbody></table></div></div>`;
  },
};
const ADMIN_BIND = {
  overview() {
    const ds = cfg().departments; const stats = ds.map((d) => deptStats(d.id));
    const c = $("#aChart"); if (c && typeof Chart !== "undefined") barChart(c, ds.map((d) => d.name), [{ label: "Open", data: stats.map((s) => s.open), color: cssVar("--amber") }, { label: "Overdue", data: stats.map((s) => s.overdue), color: cssVar("--red") }, { label: "Citizen-confirmed", data: stats.map((s) => s.confirmed), color: cssVar("--primary") }], { horizontal: true });
  },
  people() {
    $$("[data-save]").forEach((b) => b.onclick = () => busy(b, async () => {
      if (!guardWrite()) return; const id = b.dataset.save; const r = $(`[data-role="${id}"]`).value, d = $(`[data-dept="${id}"]`).value || null;
      if ((r === "official" || r === "supervisor") && !d) { toast("Choose a department for an official."); return; }
      if (r === "citizen") await write(() => S.db.collection("roles").doc(id).delete()); else await write(() => S.db.collection("roles").doc(id).set({ role: r, dept: d, by: S.uid, at: now() }));
      audit("role", `${nameOf(id)} → ${r}${d ? " (" + deptOf(d).name + ")" : ""}`); toast("Role saved.");
    }));
  },
  depts() {
    $("#dSave").onclick = (e) => busy(e.currentTarget, () => saveConfig((c) => { c.departments.forEach((d, i) => { d.name = $(`[data-dn="${i}"]`).value.trim() || d.name; d.kn = $(`[data-dk="${i}"]`).value.trim(); d.teams = $(`[data-dt="${i}"]`).value.split(",").map((x) => x.trim()).filter(Boolean); }); }, "Departments updated"));
    $("#dAdd").onclick = (e) => busy(e.currentTarget, () => saveConfig((c) => { c.departments.push({ id: "d" + uidGen(4).toLowerCase(), name: "New department", kn: "", teams: ["Team 1"] }); }, "Department added"));
  },
  cats() {
    $("#cSave").onclick = (e) => busy(e.currentTarget, () => saveConfig((c) => { c.categories.forEach((x, i) => { x.en = $(`[data-cn="${i}"]`).value.trim() || x.en; x.kn = $(`[data-ck="${i}"]`).value.trim(); x.dept = $(`[data-cd="${i}"]`).value; x.risk = clamp(+$(`[data-cr="${i}"]`).value || 1, 1, 5); }); }, "Categories updated"));
    $("#cAdd").onclick = (e) => { const n = $("#cNew").value.trim(); if (!n) return; busy(e.currentTarget, () => saveConfig((c) => { c.categories.splice(c.categories.length - 1, 0, { id: n.toLowerCase().replace(/[^a-z0-9]+/g, "_").slice(0, 30) + "_" + uidGen(3).toLowerCase(), en: n, kn: "", dept: "ward", risk: 2, hz: 0 }); }, "Category added: " + n)); };
  },
  settings() {
    $("#setSave").onclick = (e) => busy(e.currentTarget, () => saveConfig((c) => {
      [1, 2, 3, 4, 5].forEach((s) => (c.slaDays[s] = clamp(+$("#sla" + s).value || c.slaDays[s], 1, 90)));
      c.verifyDays = clamp(+$("#vDays").value || 7, 1, 60); c.lapseAction = $("#vLapse").value; c.communityThreshold = clamp(+$("#cThr").value, 0, 100); c.communityMin = clamp(+$("#cMin").value || 2, 1, 10); c.dupRadius = clamp(+$("#dRad").value || 75, 10, 500); c.reportLimitPer10Min = clamp(+$("#rLim").value || 5, 1, 50);
    }, "Settings updated"));
  },
  projects() {
    $("#pForm").onsubmit = (e) => { e.preventDefault(); const b = e.target.querySelector("button"); busy(b, async () => {
      const url = $("#pUrl").value.trim(); if (!/^https?:\/\//.test(url)) { toast("Add a valid source link starting with http."); return; }
      const p = { name: $("#pName").value.trim(), dept: $("#pDept").value, locality: $("#pLoc").value || null, status: $("#pStatus").value, budget: +$("#pBudget").value, spent: $("#pSpent").value === "" ? null : +$("#pSpent").value, start: $("#pStart").value || null, due: $("#pDue").value || null, sourceUrl: url, sourceName: $("#pSrc").value.trim(), at: now(), by: S.uid };
      if (!p.name || !p.sourceName) { toast("Fill in the required fields."); return; }
      await write(() => S.db.collection("projects").add(p)); audit("project", p.name); toast("Project published.");
    }); };
    $$("[data-delp]").forEach((b) => b.onclick = async () => { if (await confirmBox("Remove project?", "It will no longer be shown publicly.", "Remove", true)) busy(b, async () => { await write(() => S.db.collection("projects").doc(b.dataset.delp).delete()); audit("project.remove", b.dataset.delp); }); });
  },
  alerts() {
    $$("#alLocs .chipbtn").forEach((b) => b.onclick = () => b.classList.toggle("on"));
    $("#alForm").onsubmit = (e) => { e.preventDefault(); busy(e.target.querySelector("button"), async () => {
      const until = new Date($("#alUntil").value).getTime(); if (!until || until < now()) { toast("Choose a future end time."); return; }
      const a = { level: $("#alLevel").value, rainMm: +$("#alMm").value || null, until, source: $("#alSrc").value.trim(), localities: $$("#alLocs .chipbtn.on").map((b) => b.dataset.l), at: now(), by: S.uid };
      if (!a.source) { toast("Add the source of the warning."); return; }
      await write(() => S.db.collection("alerts").add(a)); audit("alert", `${a.level} until ${fmtDate(until, true)}`); toast("Alert published.");
    }); };
    $$("[data-dela]").forEach((b) => b.onclick = () => busy(b, () => write(() => S.db.collection("alerts").doc(b.dataset.dela).delete())));
  },
  ngos() { $$("[data-ver]").forEach((b) => b.onclick = () => busy(b, async () => { const n = S.ngos.find((x) => x._id === b.dataset.ver); const on = !ngoVerified(n); await saveConfig((c) => { const set = new Set(c.verifiedNgos || []); on ? set.add(n._id) : set.delete(n._id); c.verifiedNgos = [...set]; }, `NGO ${n.name}: ${on ? "verified" : "unverified"}`); })); },
};

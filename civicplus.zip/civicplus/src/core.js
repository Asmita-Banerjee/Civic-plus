"use strict";
/* ============ CivicPulse core: helpers, i18n, config, engine, data layer ============ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const DAY = 86400000;
const now = () => Date.now();
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const median = (a) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
const uidGen = (n = 6) => { const A = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; const b = crypto.getRandomValues(new Uint8Array(n)); return [...b].map((x) => A[x % A.length]).join(""); };
async function sha(s) { const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)); return [...new Uint8Array(d)].slice(0, 16).map((b) => b.toString(16).padStart(2, "0")).join(""); }
function lsGet(k, d) { try { const v = sessionStorage.getItem(k) ?? localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } }
function lsSet(k, v, session) { try { (session ? sessionStorage : localStorage).setItem(k, JSON.stringify(v)); } catch {} }

/* ---------- i18n (English / Kannada) ---------- */
const I = {
  en: {
    home: "Home", map: "Map", report: "Report", my: "My reports", gov: "Department", admin: "Admin", insights: "Insights", community: "Community",
    access: "Accessibility", sos: "Civic SOS", transparency: "Public money", about: "How it works", more: "More", notif: "Notifications",
    tagline: "Better Cities Begin With Us.",
    heroSub: "Report a civic problem, follow every step of the repair, and see it closed only when the person who reported it confirms it is fixed.",
    reportBtn: "Report an issue", mapBtn: "Explore map",
    fTitle: "Short title", fDesc: "What is the problem?", fCat: "Category", fSev: "How serious does it look?", fPhotos: "Photos or video",
    fLoc: "Location", fAddr: "Address", fLandmark: "Nearby landmark", fAnon: "Hide my identity from public listings",
    fAffected: "Who is affected?", fSubmit: "Submit complaint", speak: "Speak", listening: "Listening…",
    yes: "Yes, fixed", no: "No, not fixed",
    total: "Total", pending: "Pending", ongoing: "Ongoing", resolved: "Resolved", reopened: "Reopened",
    seniors: "Senior citizens", children: "Children or school route", disabled: "People with disabilities", pedestrians: "Pedestrians", emergency: "Blocks emergency access",
    readAloud: "Read aloud",
  },
  kn: {
    home: "ಮುಖಪುಟ", map: "ನಕ್ಷೆ", report: "ದೂರು ನೀಡಿ", my: "ನನ್ನ ದೂರುಗಳು", gov: "ಇಲಾಖೆ", admin: "ನಿರ್ವಹಣೆ", insights: "ಒಳನೋಟಗಳು", community: "ಸಮುದಾಯ",
    access: "ಪ್ರವೇಶಸಾಧ್ಯತೆ", sos: "ನಾಗರಿಕ ತುರ್ತು", transparency: "ಸಾರ್ವಜನಿಕ ಹಣ", about: "ಇದು ಹೇಗೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ", more: "ಇನ್ನಷ್ಟು", notif: "ಅಧಿಸೂಚನೆಗಳು",
    tagline: "ಉತ್ತಮ ನಗರಗಳು ನಮ್ಮಿಂದಲೇ ಆರಂಭ.",
    heroSub: "ನಾಗರಿಕ ಸಮಸ್ಯೆಯನ್ನು ವರದಿ ಮಾಡಿ, ದುರಸ್ತಿಯ ಪ್ರತಿ ಹಂತವನ್ನು ಗಮನಿಸಿ. ದೂರು ನೀಡಿದವರು ಸರಿಯಾಗಿದೆ ಎಂದು ದೃಢಪಡಿಸಿದಾಗ ಮಾತ್ರ ದೂರು ಮುಚ್ಚಲಾಗುತ್ತದೆ.",
    reportBtn: "ಸಮಸ್ಯೆ ವರದಿ ಮಾಡಿ", mapBtn: "ನಕ್ಷೆ ನೋಡಿ",
    fTitle: "ಸಂಕ್ಷಿಪ್ತ ಶೀರ್ಷಿಕೆ", fDesc: "ಸಮಸ್ಯೆ ಏನು?", fCat: "ವರ್ಗ", fSev: "ಇದು ಎಷ್ಟು ಗಂಭೀರವಾಗಿದೆ?", fPhotos: "ಫೋಟೋ ಅಥವಾ ವೀಡಿಯೊ",
    fLoc: "ಸ್ಥಳ", fAddr: "ವಿಳಾಸ", fLandmark: "ಹತ್ತಿರದ ಹೆಗ್ಗುರುತು", fAnon: "ಸಾರ್ವಜನಿಕ ಪಟ್ಟಿಯಲ್ಲಿ ನನ್ನ ಗುರುತನ್ನು ಮರೆಮಾಡಿ",
    fAffected: "ಯಾರಿಗೆ ತೊಂದರೆ?", fSubmit: "ದೂರು ಸಲ್ಲಿಸಿ", speak: "ಮಾತನಾಡಿ", listening: "ಆಲಿಸುತ್ತಿದೆ…",
    yes: "ಹೌದು, ಸರಿಯಾಗಿದೆ", no: "ಇಲ್ಲ, ಸರಿಯಾಗಿಲ್ಲ",
    total: "ಒಟ್ಟು", pending: "ಬಾಕಿ", ongoing: "ಪ್ರಗತಿಯಲ್ಲಿ", resolved: "ಪರಿಹಾರ", reopened: "ಮರು ತೆರೆದ",
    seniors: "ಹಿರಿಯ ನಾಗರಿಕರು", children: "ಮಕ್ಕಳು ಅಥವಾ ಶಾಲಾ ಮಾರ್ಗ", disabled: "ಅಂಗವಿಕಲರು", pedestrians: "ಪಾದಚಾರಿಗಳು", emergency: "ತುರ್ತು ವಾಹನ ಮಾರ್ಗಕ್ಕೆ ಅಡ್ಡಿ",
    readAloud: "ಓದಿ ಹೇಳಿ",
  },
};
const t = (k) => (I[S.lang] && I[S.lang][k]) || I.en[k] || k;
const L2 = (o) => (S.lang === "kn" && o?.kn ? o.kn : o?.en || o?.name || "");

/* ---------- static reference data ---------- */
const LOC = __LOCALITIES__;
const C_SOURCE = __C_SOURCE__;
const STATUS = {
  submitted: { en: "Submitted", kn: "ಸಲ್ಲಿಸಲಾಗಿದೆ", tone: "grey" },
  review: { en: "Under review", kn: "ಪರಿಶೀಲನೆಯಲ್ಲಿದೆ", tone: "slate" },
  assigned: { en: "Assigned", kn: "ನಿಯೋಜಿಸಲಾಗಿದೆ", tone: "blue" },
  progress: { en: "In progress", kn: "ಪ್ರಗತಿಯಲ್ಲಿದೆ", tone: "teal" },
  awaiting: { en: "Awaiting citizen verification", kn: "ನಾಗರಿಕರ ದೃಢೀಕರಣಕ್ಕೆ ಕಾಯುತ್ತಿದೆ", tone: "amber" },
  confirmed: { en: "Citizen confirmed resolved", kn: "ನಾಗರಿಕರು ಪರಿಹಾರ ದೃಢಪಡಿಸಿದ್ದಾರೆ", tone: "green" },
  rejected: { en: "Rejected", kn: "ತಿರಸ್ಕರಿಸಲಾಗಿದೆ", tone: "grey" },
  reopened: { en: "Reopened", kn: "ಮರು ತೆರೆಯಲಾಗಿದೆ", tone: "red" },
  lapsed: { en: "Closed, not verified by citizen", kn: "ನಾಗರಿಕ ದೃಢೀಕರಣವಿಲ್ಲದೆ ಮುಚ್ಚಲಾಗಿದೆ", tone: "grey" },
};
const OPEN = ["submitted", "review", "assigned", "progress", "awaiting", "reopened"];
const CLOSED = ["confirmed", "rejected", "lapsed"];
const STEPS = ["submitted", "review", "assigned", "progress", "awaiting", "confirmed"];
const HZ = { electrical: 1, open_pit: 2, flooding: 4, traffic: 8, health: 16 };
const VUL = [["seniors", 1], ["children", 2], ["disabled", 4], ["pedestrians", 8], ["emergency", 16]];
const POP = [["One street or a few houses", "ಒಂದು ಬೀದಿ"], ["A block or apartment complex", "ಒಂದು ಬ್ಲಾಕ್"], ["The whole neighbourhood", "ಇಡೀ ಬಡಾವಣೆ"], ["A main road used by thousands", "ಮುಖ್ಯ ರಸ್ತೆ"]];
const SENS = [["No special location", "ವಿಶೇಷವಿಲ್ಲ"], ["Market, bus stop or metro", "ಮಾರುಕಟ್ಟೆ / ಬಸ್ ನಿಲ್ದಾಣ"], ["School, hospital or care home", "ಶಾಲೆ / ಆಸ್ಪತ್ರೆ"], ["Emergency route or junction", "ತುರ್ತು ಮಾರ್ಗ"]];

const DEFAULT_CONFIG = {
  version: 1,
  departments: [
    { id: "roads", name: "Roads & Footpaths", kn: "ರಸ್ತೆ ಮತ್ತು ಪಾದಚಾರಿ ಮಾರ್ಗ", teams: ["Road crew A", "Road crew B", "Footpath crew"] },
    { id: "swm", name: "Solid Waste Management", kn: "ಘನ ತ್ಯಾಜ್ಯ ನಿರ್ವಹಣೆ", teams: ["Ward collection team", "Black-spot clearance"] },
    { id: "water", name: "Water Supply & Sewerage", kn: "ನೀರು ಸರಬರಾಜು ಮತ್ತು ಒಳಚರಂಡಿ", teams: ["Leak response", "Sewer line crew"] },
    { id: "drains", name: "Stormwater Drains", kn: "ಮಳೆನೀರು ಚರಂಡಿ", teams: ["Desilting team", "Flood response"] },
    { id: "electrical", name: "Street Lighting & Electrical", kn: "ಬೀದಿ ದೀಪ ಮತ್ತು ವಿದ್ಯುತ್", teams: ["Lighting crew", "Hazard response"] },
    { id: "traffic", name: "Traffic & Pedestrian Safety", kn: "ಸಂಚಾರ ಮತ್ತು ಪಾದಚಾರಿ ಸುರಕ್ಷತೆ", teams: ["Signals & signage", "Crossing works"] },
    { id: "health", name: "Public Health & Sanitation", kn: "ಸಾರ್ವಜನಿಕ ಆರೋಗ್ಯ ಮತ್ತು ನೈರ್ಮಲ್ಯ", teams: ["Sanitation inspectors"] },
    { id: "ward", name: "Ward Office (General)", kn: "ವಾರ್ಡ್ ಕಚೇರಿ", teams: ["Ward engineer", "Tree & horticulture"] },
  ],
  categories: [
    { id: "pothole", en: "Pothole", kn: "ರಸ್ತೆ ಗುಂಡಿ", dept: "roads", risk: 3, hz: 8 },
    { id: "road_damage", en: "Road damage", kn: "ರಸ್ತೆ ಹಾನಿ", dept: "roads", risk: 2, hz: 8 },
    { id: "garbage", en: "Garbage dumping", kn: "ಕಸ ಸುರಿಯುವಿಕೆ", dept: "swm", risk: 2, hz: 16 },
    { id: "water_leak", en: "Water leakage", kn: "ನೀರಿನ ಸೋರಿಕೆ", dept: "water", risk: 2, hz: 0 },
    { id: "drainage", en: "Blocked drain", kn: "ಚರಂಡಿ ಕಟ್ಟಿಕೊಂಡಿದೆ", dept: "drains", risk: 3, hz: 4 },
    { id: "sewage", en: "Sewage overflow", kn: "ಒಳಚರಂಡಿ ಉಕ್ಕಿ ಹರಿಯುವಿಕೆ", dept: "water", risk: 3, hz: 16 },
    { id: "streetlight", en: "Broken streetlight", kn: "ಬೀದಿ ದೀಪ ಕೆಟ್ಟಿದೆ", dept: "electrical", risk: 2, hz: 0 },
    { id: "sanitation", en: "Public toilet / sanitation", kn: "ಸಾರ್ವಜನಿಕ ಶೌಚಾಲಯ / ನೈರ್ಮಲ್ಯ", dept: "health", risk: 2, hz: 16 },
    { id: "traffic", en: "Traffic signal or signage", kn: "ಸಂಚಾರ ದೀಪ / ಫಲಕ", dept: "traffic", risk: 2, hz: 8 },
    { id: "pedestrian", en: "Pedestrian safety", kn: "ಪಾದಚಾರಿ ಸುರಕ್ಷತೆ", dept: "traffic", risk: 3, hz: 8 },
    { id: "accessibility", en: "Accessibility barrier", kn: "ಪ್ರವೇಶಸಾಧ್ಯತೆ ಅಡಚಣೆ", dept: "roads", risk: 3, hz: 0 },
    { id: "electrical", en: "Exposed wires / electrical hazard", kn: "ತೆರೆದ ತಂತಿ / ವಿದ್ಯುತ್ ಅಪಾಯ", dept: "electrical", risk: 5, hz: 1 },
    { id: "fallen_pole", en: "Fallen electric pole", kn: "ಬಿದ್ದ ವಿದ್ಯುತ್ ಕಂಬ", dept: "electrical", risk: 5, hz: 9 },
    { id: "open_manhole", en: "Open manhole", kn: "ತೆರೆದ ಮ್ಯಾನ್‌ಹೋಲ್", dept: "water", risk: 5, hz: 2 },
    { id: "fallen_tree", en: "Fallen tree", kn: "ಬಿದ್ದ ಮರ", dept: "ward", risk: 4, hz: 8 },
    { id: "flooding", en: "Flooded road", kn: "ಜಲಾವೃತ ರಸ್ತೆ", dept: "drains", risk: 4, hz: 4 },
    { id: "other", en: "Other civic problem", kn: "ಇತರೆ ನಾಗರಿಕ ಸಮಸ್ಯೆ", dept: "ward", risk: 1, hz: 0 },
  ],
  slaDays: { 1: 14, 2: 10, 3: 7, 4: 3, 5: 1 },
  verifyDays: 7,
  lapseAction: "close_unverified",
  communityThreshold: 65,
  communityMin: 2,
  dupRadius: 75,
  reportLimitPer10Min: 5,
};
const SOS_TYPES = [
  { cat: "electrical", en: "Exposed wires", kn: "ತೆರೆದ ತಂತಿಗಳು", icon: "bolt" },
  { cat: "fallen_pole", en: "Fallen electric pole", kn: "ಬಿದ್ದ ವಿದ್ಯುತ್ ಕಂಬ", icon: "pole" },
  { cat: "open_manhole", en: "Open manhole", kn: "ತೆರೆದ ಮ್ಯಾನ್‌ಹೋಲ್", icon: "hole" },
  { cat: "fallen_tree", en: "Fallen tree", kn: "ಬಿದ್ದ ಮರ", icon: "tree" },
  { cat: "flooding", en: "Flooded road", kn: "ಜಲಾವೃತ ರಸ್ತೆ", icon: "wave" },
];
const ACCESS_KINDS = { ramp: ["Ramp", "#21604A"], crossing: ["Accessible crossing", "#2F5F80"], facility: ["Accessible facility", "#1F6D70"], toilet: ["Accessible toilet", "#1F6D70"], obstacle: ["Footpath obstacle", "#A9392F"] };

/* ---------- state ---------- */
const S = {
  db: null, user: null, uid: null, isOwner: false, canWrite: null, readOnly: false,
  assets: null, sample: null, sampleImages: false, dictation: null, tts: null,
  config: null, complaints: new Map(), profiles: new Map(), roles: new Map(),
  projects: [], events: [], ngos: [], resources: [], access: [], alerts: [], surveys: [], audit: [],
  mine: new Set(), keyCache: new Map(), priv: null, privVersion: 0,
  lang: lsGet("cp_lang", "en"), preview: lsGet("cp_preview", null), loaded: new Set(), timedOut: false, dirty: false, names: {}, started: false,
};
const cfg = () => S.config || DEFAULT_CONFIG;
const catOf = (id) => cfg().categories.find((c) => c.id === id) || { id, en: id, risk: 1, hz: 0, dept: "ward" };
const deptOf = (id) => cfg().departments.find((d) => d.id === id) || { id, name: id || "Unassigned" };
const locOf = (id) => LOC.find((l) => l.id === id);
function nearestLocality(lat, lng) { let best = null, bd = 1e18; for (const l of LOC) { const d = E.distance(lat, lng, l.lat, l.lng); if (d < bd) { bd = d; best = l; } } return best; }
function realRole() { if (S.isOwner) return { role: "admin" }; const r = S.roles.get(S.uid); return r && r.role ? { role: r.role, dept: r.dept || null } : { role: "citizen" }; }
function role() { const r = realRole(); if (S.isOwner && S.preview) return S.preview; return r; }
const isAdmin = () => role().role === "admin";
const isOfficial = () => ["official", "supervisor"].includes(role().role);
const isStaff = () => isAdmin() || isOfficial();

/* ---------- C engine (WebAssembly) with identical JavaScript fallback ---------- */
const WASM_B64 = "__WASM__";
const E = {
  kind: "JavaScript port (WebAssembly unavailable)", x: null,
  distance(a, b, c, d) {
    if (this.x) return this.x.cp_distance_m(a, b, c, d);
    const p1 = (a * Math.PI) / 180, p2 = (c * Math.PI) / 180;
    const dx = ((d - b) * Math.PI) / 180 * Math.cos((p1 + p2) / 2), dy = p2 - p1;
    return 6371000 * Math.sqrt(dx * dx + dy * dy);
  },
  severity(risk, hz, supports, userSev) {
    if (this.x) return this.x.cp_severity(risk, hz, supports, userSev);
    let s = risk; if (hz & 1) s += 1.5; if (hz & 2) s += 1; if (hz & 4) s += 0.8;
    s += 0.3 * (((hz & 8) ? 1 : 0) + ((hz & 16) ? 1 : 0)); if (supports >= 10) s += 1; else if (supports >= 3) s += 0.5;
    if (userSev > 0) s = 0.7 * s + 0.3 * userSev; return clamp(Math.floor(s + 0.5), 1, 5);
  },
  priority(sev, vul, pop, sens, age, supports, reopen) {
    if (this.x) return this.x.cp_priority(sev, vul, pop, sens, age, supports, reopen);
    const pc = (v) => { let c = 0; while (v) { c += v & 1; v >>= 1; } return c; };
    let s = sev * 9 + pc(vul) * 4 + ((vul & 16) ? 3 : 0) + pop * 3 + sens * 3 + clamp(age, 0, 30) * 0.2 + Math.min(supports, 20) * 0.25 + Math.min(reopen, 3) * 2;
    return Math.min(100, s);
  },
  near(points, lat, lng, catIdx, radius) {
    if (this.x && points.length <= 4096) {
      const n = points.length, buf = this.x.memory.buffer;
      const la = new Float64Array(buf, this.x.cp_lat_ptr(), n), lo = new Float64Array(buf, this.x.cp_lon_ptr(), n), ca = new Int32Array(buf, this.x.cp_cat_ptr(), n);
      points.forEach((p, i) => { la[i] = p.lat; lo[i] = p.lng; ca[i] = p.cat; });
      const k = this.x.cp_find_duplicates(n, lat, lng, catIdx, radius);
      const out = new Int32Array(this.x.memory.buffer, this.x.cp_out_ptr(), k), dist = new Float64Array(this.x.memory.buffer, this.x.cp_dist_ptr(), k);
      return [...out].map((idx, j) => ({ i: idx, d: dist[j] }));
    }
    const r = []; points.forEach((p, i) => { if (catIdx >= 0 && p.cat !== catIdx) return; const d = this.distance(lat, lng, p.lat, p.lng); if (d <= radius) r.push({ i, d }); }); return r;
  },
  hamming(a, b) {
    if (!a || !b) return 64;
    const hi1 = parseInt(a.slice(0, 8), 16) >>> 0, lo1 = parseInt(a.slice(8), 16) >>> 0, hi2 = parseInt(b.slice(0, 8), 16) >>> 0, lo2 = parseInt(b.slice(8), 16) >>> 0;
    if (this.x) return this.x.cp_hamming64(hi1, lo1, hi2, lo2);
    const pc = (v) => { let c = 0; v >>>= 0; while (v) { c += v & 1; v >>>= 1; } return c; }; return pc(hi1 ^ hi2) + pc(lo1 ^ lo2);
  },
};
async function initEngine() {
  try {
    const bytes = Uint8Array.from(atob(WASM_B64), (c) => c.charCodeAt(0));
    const { instance } = await WebAssembly.instantiate(bytes, {});
    E.x = instance.exports; E.kind = "C compiled to WebAssembly";
  } catch (e) { console.warn("WASM engine unavailable, using JS port", e); }
}
function scores(c) {
  const cat = catOf(c.cat); const hz = (c.hazards || 0) | (cat.hz || 0);
  const sup = c.supportCount || 0;
  const severity = E.severity(cat.risk || 1, hz, sup, c.sev || 0);
  const age = Math.max(0, ((c.closedAt || now()) - (c.createdAt || now())) / DAY);
  const priority = Math.round(E.priority(severity, c.vulnerable || 0, c.popBand || 0, c.locSens || 0, age, sup, c.reopenCount || 0));
  return { severity, priority, age };
}

/* ---------- text + image similarity ---------- */
const STOP = new Set("the and for with this that near from have has are was were there here road street very also into onto been just main cross".split(" "));
const toks = (s) => new Set(String(s || "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((w) => w.length > 2 && !STOP.has(w)));
function jaccard(a, b) { const A = toks(a), B = toks(b); if (!A.size || !B.size) return 0; let n = 0; for (const x of A) if (B.has(x)) n++; return n / (A.size + B.size - n); }
async function dHash(blob) {
  try {
    const bmp = await createImageBitmap(blob); const c = document.createElement("canvas"); c.width = 9; c.height = 8;
    const x = c.getContext("2d"); x.drawImage(bmp, 0, 0, 9, 8); const d = x.getImageData(0, 0, 9, 8).data; let bits = "";
    for (let y = 0; y < 8; y++) for (let i = 0; i < 8; i++) { const p = (y * 9 + i) * 4, q = p + 4; const g1 = d[p] * 0.3 + d[p + 1] * 0.59 + d[p + 2] * 0.11, g2 = d[q] * 0.3 + d[q + 1] * 0.59 + d[q + 2] * 0.11; bits += g1 > g2 ? "1" : "0"; }
    let hex = ""; for (let i = 0; i < 64; i += 4) hex += parseInt(bits.slice(i, i + 4), 2).toString(16); return hex;
  } catch { return null; }
}
async function compressImage(file, max = 1280, q = 0.78) {
  let bmp; try { bmp = await createImageBitmap(file); } catch { throw new Error("This photo couldn't be read. Try a JPEG or PNG photo."); } const s = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas"); c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
  c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
  return await new Promise((r) => c.toBlob(r, "image/jpeg", q));
}
const blobToDataURL = (b) => new Promise((r) => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(b); });
/* Upload one media file. Uses the artifact's asset store when available, otherwise embeds a small compressed copy. */
async function storeMedia(file) {
  const isVideo = file.type.startsWith("video/");
  if (isVideo) {
    if (!S.assets) throw new Error("Video uploads need asset storage, which is not available for your access level here. Add a photo instead.");
    if (file.size > 20 * 1024 * 1024) throw new Error("Videos must be under 20 MB.");
    const r = await S.assets.upload(file); return { src: r.url, id: r.id, kind: "video" };
  }
  if (!file.type.startsWith("image/")) throw new Error("Only images and videos can be uploaded.");
  if (file.size > 15 * 1024 * 1024) throw new Error("Images must be under 15 MB.");
  const hash = await dHash(file);
  if (S.assets) { try { const big = await compressImage(file, 1600, 0.82); const r = await S.assets.upload(big); return { src: r.url, id: r.id, kind: "image", hash }; } catch (e) { console.warn("asset upload failed, embedding", e); } }
  const small = await compressImage(file, 520, 0.62); return { src: await blobToDataURL(small), kind: "image", hash, embedded: true };
}

/* ---------- data layer ---------- */
const COLS = ["config", "complaints", "profiles", "roles", "projects", "events", "ngos", "resources", "access", "alerts", "surveys", "audit"];
let renderTimer = null;
function scheduleRender() { clearTimeout(renderTimer); renderTimer = setTimeout(() => onData(), 60); }
async function startData() {
  const timer = setTimeout(() => { S.timedOut = true; scheduleRender(); }, 10000);
  for (const col of COLS) {
    let q = S.db.collection(col);
    if (col === "audit") q = q.orderBy("at", "desc").limit(300);
    q.onSnapshot((snap) => {
      if (!snap.metadata.fromCache) { S.loaded.add(col); if (S.loaded.size >= COLS.length) { clearTimeout(timer); S.timedOut = false; } }
      const docs = snap.docs.map((d) => ({ ...d.data(), _id: d.id }));
      if (col === "config") S.config = docs.find((d) => d._id === "main") || null;
      else if (col === "complaints") { S.complaints = new Map(docs.map((d) => [d._id, d])); }
      else if (col === "profiles") S.profiles = new Map(docs.map((d) => [d._id, d]));
      else if (col === "roles") S.roles = new Map(docs.map((d) => [d._id, d]));
      else S[col] = docs;
      scheduleRender();
    }, (e) => { console.warn(col, e); S.loaded.add(col); if (e.code === "revoked") S.readOnly = true; scheduleRender(); });
  }
  if (S.uid) {
    S.db.doc(`data/users/${S.uid}/state`).onSnapshot((d) => { S.priv = d.exists ? d.data() : { lastSeen: 0, reports: [] }; scheduleRender(); }, () => {});
  }
}
async function refreshMine() {
  if (!S.uid) return;
  const jobs = [];
  for (const c of S.complaints.values()) {
    if (!c.reporterKey || S.keyCache.has(c._id)) continue;
    jobs.push(sha(S.uid + ":" + c._id).then((k) => S.keyCache.set(c._id, k === c.reporterKey)));
  }
  await Promise.all(jobs);
  S.mine = new Set([...S.complaints.keys()].filter((id) => S.keyCache.get(id)));
}
const isMine = (c) => S.mine.has(c._id);
const myKey = (cid, salt = "") => sha(S.uid + ":" + salt + cid);

/* Writes are funnelled through one queue so each document gets one write at a time. */
let wq = Promise.resolve();
function write(fn) { const p = wq.then(fn); wq = p.catch(() => {}); return p; }
function dbErr(e) {
  if (e && e.code === "invalid_argument") { S.readOnly = true; return "Your access level can't save changes here. Ask the owner for Contributor access."; }
  if (e && e.code === "quota_exceeded") return "Storage is full for this app. An administrator needs to remove old records.";
  if (e && e.code === "resource_exhausted") return "Too many changes too quickly. Wait a moment and try again.";
  return (e && e.message) || "Something went wrong saving that. Try again.";
}
async function saveComplaint(c) {
  const { _id, ...body } = c; body.updatedAt = now();
  await write(() => S.db.collection("complaints").doc(_id).set(JSON.parse(JSON.stringify(body))));
  S.complaints.set(_id, { ...body, _id });
}
async function patchComplaint(id, mutate, entry) {
  const cur = S.complaints.get(id); if (!cur) throw new Error("Complaint not found.");
  const c = JSON.parse(JSON.stringify(cur));
  mutate(c);
  if (entry) c.timeline = [...(c.timeline || []), { at: now(), by: S.uid || null, byRole: role().role, ...entry }];
  const sc = scores(c); c.severity = sc.severity; c.priority = sc.priority;
  await saveComplaint(c); return c;
}
async function audit(action, detail) { try { await write(() => S.db.collection("audit").add({ at: now(), by: S.uid, role: role().role, action, detail })); } catch {} }
async function savePriv(patch) {
  if (!S.uid || !S.db) return;
  const next = { ...(S.priv || {}), ...patch }; S.priv = next;
  try { await write(() => S.db.doc(`data/users/${S.uid}/state`).set(next)); } catch (e) { console.warn(e); }
}
async function resolveNames(ids) {
  ids = [...new Set(ids.filter(Boolean))].filter((id) => !(id in S.names));
  if (!ids.length || !S.user) return;
  try { const ps = await S.user.profiles(ids); for (const id of ids) S.names[id] = (ps[id] && ps[id].name) || ""; } catch { for (const id of ids) S.names[id] = ""; }
}
const nameOf = (id) => (id && S.names[id]) || (id === S.uid ? "You" : "Citizen");

/* ---------- derived lists ---------- */
const allC = () => [...S.complaints.values()];
const isOpen = (c) => OPEN.includes(c.status);
const sla = (sev) => (cfg().slaDays || DEFAULT_CONFIG.slaDays)[sev] || 7;
const overdue = (c) => isOpen(c) && c.status !== "awaiting" && c.dueAt && now() > c.dueAt;
function resolutionDays(c) { if (c.status !== "confirmed" || !c.closedAt) return null; return (c.closedAt - c.createdAt) / DAY; }

/* ---------- notifications derived from complaint timelines ---------- */
function notifications() {
  const out = []; const me = S.uid; const r = role();
  for (const c of allC()) {
    const mine = isMine(c);
    const deptMatch = isOfficial() && r.dept && c.dept === r.dept;
    const watched = mine || deptMatch || isAdmin();
    if (!watched) continue;
    for (const e of c.timeline || []) {
      if (e.by && e.by === me && !(isAdmin() && e.auto)) continue;
      if (!mine && !deptMatch && isAdmin() && !["escalated", "disputed", "lapsed"].includes(e.type)) continue;
      if (mine && !["review", "assigned", "progress", "awaiting", "rejected", "escalated", "lapsed", "note", "dispute_reply", "community"].includes(e.type)) continue;
      if (!mine && deptMatch && !["submitted", "disputed", "confirmed", "escalated", "support", "community"].includes(e.type)) continue;
      out.push({ at: e.at, c, e });
    }
  }
  /* nearby hazard alerts: SOS reports in my locality during the last 48 hours */
  const myLoc = S.profiles.get(S.uid)?.locality;
  if (myLoc) for (const c of allC()) if (c.sos && c.locality === myLoc && isOpen(c) && now() - c.createdAt < 2 * DAY && !isMine(c)) out.push({ at: c.createdAt, c, e: { type: "hazard", note: "Hazard reported near you" } });
  return out.sort((a, b) => b.at - a.at).slice(0, 60);
}
function notifText(n) {
  const id = n.c.displayId || n.c._id; const e = n.e;
  const map = {
    submitted: `New complaint ${id} for your department`, review: `${id} is under review`, assigned: `${id} was assigned to ${e.team || "a team"}`,
    progress: `Work started on ${id}`, awaiting: `${id}: the department says it is fixed. Please confirm.`, confirmed: `Citizen confirmed ${id} is fixed`,
    disputed: `Citizen disputed the repair on ${id}: reopened`, rejected: `${id} was rejected`, escalated: `${id} escalated: overdue`, lapsed: `${id} closed without citizen confirmation`,
    note: `Update on ${id}`, dispute_reply: `Department replied to your dispute on ${id}`, support: `Another citizen supported ${id}`, community: `Community verification added on ${id}`, hazard: `Hazard near you: ${catOf(n.c.cat).en} (${id})`,
  };
  return map[e.type] || `Update on ${id}`;
}
const unreadCount = () => notifications().filter((n) => n.at > ((S.priv && S.priv.lastSeen) || 0)).length;

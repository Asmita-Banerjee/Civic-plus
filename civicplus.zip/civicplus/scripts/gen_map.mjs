import { Delaunay } from "d3-delaunay";
import fs from "fs";
const L=[["Koramangala","ಕೋರಮಂಗಲ",12.9352,77.6245],["Indiranagar","ಇಂದಿರಾನಗರ",12.9784,77.6408],["Jayanagar","ಜಯನಗರ",12.9250,77.5938],["Malleshwaram","ಮಲ್ಲೇಶ್ವರಂ",13.0035,77.5709],["Whitefield","ವೈಟ್‌ಫೀಲ್ಡ್",12.9698,77.7500],["HSR Layout","ಎಚ್‌ಎಸ್‌ಆರ್ ಲೇಔಟ್",12.9116,77.6474],["BTM Layout","ಬಿಟಿಎಂ ಲೇಔಟ್",12.9166,77.6101],["Rajajinagar","ರಾಜಾಜಿನಗರ",12.9910,77.5550],["Hebbal","ಹೆಬ್ಬಾಳ",13.0358,77.5970],["Yelahanka","ಯಲಹಂಕ",13.1007,77.5963],["Electronic City","ಎಲೆಕ್ಟ್ರಾನಿಕ್ ಸಿಟಿ",12.8452,77.6602],["Banashankari","ಬನಶಂಕರಿ",12.9255,77.5468],["Marathahalli","ಮಾರತಹಳ್ಳಿ",12.9569,77.7011],["Shivajinagar","ಶಿವಾಜಿನಗರ",12.9857,77.6057],["Basavanagudi","ಬಸವನಗುಡಿ",12.9406,77.5738],["Yeshwanthpur","ಯಶವಂತಪುರ",13.0285,77.5400],["KR Puram","ಕೆ.ಆರ್. ಪುರಂ",13.0080,77.6950],["Bellandur","ಬೆಳ್ಳಂದೂರು",12.9260,77.6762],["JP Nagar","ಜೆ.ಪಿ. ನಗರ",12.9063,77.5857],["Vijayanagar","ವಿಜಯನಗರ",12.9719,77.5300]];
const box=[77.50,12.82,77.79,13.13];
const d=Delaunay.from(L.map(l=>[l[3],l[2]]));const v=d.voronoi(box);
const out=L.map((l,i)=>({id:l[0].toLowerCase().replace(/[^a-z]+/g,"-"),name:l[0],kn:l[1],lat:l[2],lng:l[3],poly:v.cellPolygon(i).map(p=>[+p[1].toFixed(4),+p[0].toFixed(4)])}));
fs.writeFileSync(new URL("../src/localities.json", import.meta.url),JSON.stringify(out));console.log(out.length);

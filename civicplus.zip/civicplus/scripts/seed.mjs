import fs from "fs";
const src=fs.readFileSync(new URL("../src/core.js", import.meta.url),"utf8");
const cfg=eval("("+src.split("const DEFAULT_CONFIG = ")[1].split("};\nconst SOS_TYPES")[0]+"})");
const LOC=JSON.parse(fs.readFileSync(new URL("../src/localities.json", import.meta.url)));
const DAY=864e5, NOW=Date.parse("2026-11-13T18:00:00Z");
const rk=()=>[...crypto.getRandomValues(new Uint8Array(16))].map(b=>b.toString(16).padStart(2,"0")).join("");
const L=id=>LOC.find(l=>l.name===id);
const dept=c=>cfg.categories.find(x=>x.id===c).dept;
const team=d=>cfg.departments.find(x=>x.id===d).teams[0];
let n=0;
function C(title,desc,cat,loc,daysAgo,status,o={}){
  const l=L(loc), id="CP-S"+String(++n).padStart(5,"0"); const created=NOW-daysAgo*DAY; const d=dept(cat);
  const jit=()=> (Math.random()-.5)*0.006;
  const tl=[{type:"submitted",at:created,by:null,byRole:"citizen",note:"Complaint filed"}];
  const st=["submitted","review","assigned","progress","awaiting"]; let t=created; const res=[];
  const stages={submitted:0,review:1,assigned:2,progress:3,awaiting:4,reopened:4,confirmed:4,lapsed:4,rejected:1};
  const upto=stages[status];
  for(let i=1;i<=upto;i++){ t+= (o.step||1.2)*DAY; const s=st[i]; if(status==="rejected"&&i===1){tl.push({type:"rejected",at:t,by:null,byRole:"official",note:"Private property; outside municipal responsibility. Forwarded to the resident welfare association."});break;}
    const e={type:s,at:t,by:null,byRole:"official",note:{review:"Verified as a valid complaint",assigned:null,progress:"Team is on site",awaiting:"Repair completed"}[s]}; if(s==="assigned")e.team=team(d); if(s==="awaiting"){res.push({at:t,by:null,note:o.fix||"Repair completed by the maintenance team.",media:[],outcome:"pending"});} tl.push(e);}
  let closedAt=null, reopenCount=0;
  if(status==="reopened"){ t+=1*DAY; res[0].outcome="disputed"; res[0].citizenNote=o.dispute||"Still not fixed."; res[0].respondedAt=t; tl.push({type:"disputed",at:t,by:null,byRole:"citizen",note:res[0].citizenNote}); reopenCount=1; }
  if(status==="confirmed"){ t+=0.8*DAY; res[0].outcome="confirmed"; res[0].respondedAt=t; closedAt=t; tl.push({type:"confirmed",at:t,by:null,byRole:"citizen",note:"Reporter confirmed the repair is done."}); }
  if(status==="lapsed"){ t+=7*DAY; res[0].outcome="no_response"; closedAt=t; tl.push({type:"lapsed",at:t,auto:true,by:null,byRole:"admin",note:"The reporter did not respond within 7 days. Closed without citizen confirmation."}); }
  if(status==="rejected") closedAt=t;
  const sev=o.sev||3; const sla=cfg.slaDays[sev];
  return {path:"complaints/"+id,data:{displayId:id,title,desc,cat,dept:d,sev,vulnerable:o.vul||0,popBand:o.pop||1,locSens:o.sens||0,hazards:0,lat:+(l.lat+jit()).toFixed(6),lng:+(l.lng+jit()).toFixed(6),locality:l.id,address:o.addr||"",landmark:o.land||"",anonymous:true,reporterId:null,reporterKey:rk(),media:[],
    status:status==="awaiting"?"awaiting":status,createdAt:created,updatedAt:t,dueAt:created+sla*DAY,supports:[],supportCount:o.sup||0,duplicates:[],resolutions:res,reopenCount,escalated:o.esc||0,escalatedAt:o.esc?NOW-DAY:null,community:[],sos:!!o.sos,source:"app",lang:"en",ai:null,groupId:null,
    timeline:o.esc?[...tl,{type:"escalated",at:NOW-DAY,auto:true,by:null,byRole:"admin",note:"Overdue. Escalated to level 1; department supervisor notified."}]:tl,needsCommunity:!!o.comm,verifyDeadline:status==="awaiting"?t+7*DAY:null,closedAt,severity:sev,priority:0,demo:true}};
}
const cs=[
 C("Deep pothole outside Forum mall bus stop","Two-wheelers swerve into traffic to avoid it, worse after rain.","pothole","Koramangala",170,"confirmed",{sev:4,vul:8,pop:3,fix:"Cut and patched with cold mix."}),
 C("Pothole back at Forum bus stop","Same pothole that was patched in spring has opened up again.","pothole","Koramangala",40,"reopened",{sev:4,vul:8,pop:3,sup:6,dispute:"Patch washed out within a week of rain.",comm:true}),
 C("Garbage black spot near 12th Main","Mixed waste dumped every night on the corner, dogs scattering it.","garbage","Indiranagar",9,"progress",{sev:3,pop:2,sup:4,esc:1}),
 C("Streetlights out on 80 Feet Road stretch","Five lamps dark for a week; women avoid walking here after 7 pm.","streetlight","HSR Layout",6,"assigned",{sev:3,vul:8,pop:2,sup:3}),
 C("Water main leaking for three days","Clean water flowing into the drain beside the temple.","water_leak","Jayanagar",5,"awaiting",{sev:2,fix:"Joint replaced on the 150 mm line."}),
 C("Storm drain choked with silt","Water collects knee-deep at the junction after every rain.","drainage","Bellandur",320,"confirmed",{sev:3,pop:2,fix:"Desilted 120 m of drain."}),
 C("Flooded underpass after rain","Underpass floods; buses turning back.","flooding","Bellandur",150,"confirmed",{sev:4,pop:3,fix:"Pumps deployed, inlet cleared."}),
 C("Drain overflowing onto road again","Same junction flooding again, smells of sewage.","drainage","Bellandur",12,"review",{sev:3,pop:2,sup:5}),
 C("Open manhole near school gate","Cover missing outside the government primary school.","open_manhole","Shivajinagar",1,"submitted",{sev:5,vul:2|8,sens:2,sos:true,comm:true}),
 C("Broken footpath slabs, no ramp at crossing","Wheelchair users cannot reach the bus stop; slabs tilted.","accessibility","Malleshwaram",14,"progress",{sev:3,vul:4|1,sens:1,esc:1}),
 C("Sewage overflow in lane","Sewage backing up from manhole into houses.","sewage","BTM Layout",3,"assigned",{sev:4,vul:1|2,pop:1,sup:2}),
 C("Tree branch hanging over road","Large branch cracked after storm, hanging over two-wheeler lane.","fallen_tree","Basavanagudi",2,"review",{sev:4,pop:2}),
 C("Signal not working at junction","Traffic signal blinking amber all day, near-misses.","traffic","Marathahalli",8,"lapsed",{sev:3,pop:3,fix:"Controller board replaced."}),
 C("Garbage burning on vacant plot","Smoke every evening affecting children with asthma.","garbage","Yelahanka",20,"rejected",{sev:2,vul:2}),
 C("Potholes on service road","Series of potholes along the service road, 300 m.","pothole","Electronic City",60,"confirmed",{sev:3,pop:3,fix:"Resurfaced with hot mix."}),
 C("Waterlogging at underpass","Underpass impassable for an hour after rain.","flooding","Hebbal",100,"confirmed",{sev:4,pop:3,fix:"Inlets cleared."}),
 C("Waterlogging at underpass, again","Flooded again this week.","flooding","Hebbal",25,"progress",{sev:4,pop:3,sup:3}),
];
// fix confirmed pothole closedAt order so the return happens after closure
const ops=[{op:"set",path:"config/main",data:cfg},...cs.map(c=>({op:"set",path:c.path,data:c.data}))];
const ev=[{path:"events/sample-cleanup",data:{title:"Lake bund clean-up",type:"cleanup",locality:L("Bellandur").id,date:NOW+2*DAY,desc:"Bring gloves; bags provided. Meet at the east gate.",organizer:"Sample residents' group",createdBy:null,participants:[],at:NOW,demo:true}},
 {path:"events/sample-trees",data:{title:"Tree plantation on school route",type:"trees",locality:L("Jayanagar").id,date:NOW+9*DAY,desc:"Planting 40 native saplings along the school walking route.",organizer:"Sample volunteers",createdBy:null,participants:[],at:NOW,demo:true}}];
const ng=[{path:"ngos/sample-food",data:{name:"Sample Food Bank Collective",focus:"Food relief",regId:"",createdBy:null,at:NOW,demo:true}}];
const rs=[{path:"resources/s1",data:{kind:"need",item:"food",qty:"60 meals",locality:L("Shivajinagar").id,ngoId:"sample-food",contact:"",note:"Night shelter, daily",urgent:true,status:"open",by:null,at:NOW-DAY,demo:true}},
 {path:"resources/s2",data:{kind:"offer",item:"food",qty:"40 meals surplus",locality:L("Indiranagar").id,ngoId:null,contact:"",note:"Restaurant surplus after 10 pm",urgent:false,status:"open",by:null,at:NOW-2*DAY,demo:true}},
 {path:"resources/s3",data:{kind:"need",item:"clothes",qty:"30 blankets",locality:L("KR Puram").id,ngoId:null,contact:"",note:"",urgent:false,status:"open",by:null,at:NOW-3*DAY,demo:true}}];
const ax=[["ramp","Malleshwaram",0.001,"Ramp at metro exit",2],["crossing","Malleshwaram",-0.002,"Signal crossing with audio",3],["obstacle","Malleshwaram",0.0015,"Transformer box blocking footpath",2],["toilet","Jayanagar",0.001,"Accessible public toilet, 4th Block complex",2],["ramp","Koramangala",-0.001,"Ramp at bus stop",0],["obstacle","Indiranagar",0.002,"Parked vendors block footpath",1]]
 .map(([k,loc,d,note,cn],i)=>({path:"access/AX-S"+i,data:{kind:k,lat:+(L(loc).lat+d).toFixed(6),lng:+(L(loc).lng+d).toFixed(6),locality:L(loc).id,note,confirms:Array.from({length:cn},rk),disputes:[],byKey:rk(),at:NOW-i*DAY,demo:true}}));
for(const x of [...ev,...ng,...rs,...ax]) ops.push({op:"set",path:x.path,data:x.data});
fs.writeFileSync(new URL("../data/seed.json", import.meta.url),JSON.stringify(ops)); console.log(ops.length);
